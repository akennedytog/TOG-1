'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Chat } from '@/components/Chat';
import { InsuranceDocumentAnalyzer } from '@/components/InsuranceDocumentAnalyzer';
import { HospitalBagPlanner } from '@/components/HospitalBagPlanner';
import { PregnancyTracker } from '@/components/PregnancyTracker';
import { VaccinationTracker } from '@/components/VaccinationTracker';
import { BirthPlanBuilder } from '@/components/BirthPlanBuilder';
import { SavingsGoals } from '@/components/SavingsGoals';
import { BabyCostCalculator } from '@/components/BabyCostCalculator';
import { BudgetTracker } from '@/components/BudgetTracker';
import { RegistryTracker } from '@/components/RegistryTracker';
import { supabase, getProfile, Profile } from '@/lib/supabase';
import { Skeleton } from '@/components/ui/skeleton';
import { hasCompletedOnboarding } from '@/lib/onboarding';
import { cn } from '@/lib/utils';
import {
  Calendar,
  CalendarRange,
  Baby,
  Backpack,
  Syringe,
  Heart,
  FileText,
  Shield,
  ShieldCheck,
  Wallet,
  Clock,
  PiggyBank,
  Calculator,
  Receipt,
  Users,
  ChevronRight,
  ArrowRight,
  Gift,
  MessageCircle,
  Sparkles,
  Target,
  AlertCircle,
  CheckCircle2,
  Zap,
  Plus,
  Activity,
  X,
  DollarSign,
  Lightbulb,
} from 'lucide-react';

// Import Task Components
import { SmartTaskManager } from '@/components/SmartTaskManager';
import { groupTasksByCategory } from '@/lib/ai-task-categorizer';

import { StaggerContainer, StaggerItem } from '@/components/animations/StaggerContainer';
import { GlassCard, ColoredGlassCard } from '@/components/ui/GlassCard';
import { motion } from 'framer-motion';
import { AnimatedBackground } from '@/components/animations/AnimatedBackground';

// Loading skeleton for stat cards
function StatCardSkeleton() {
  return (
    <GlassCard className="h-full">
      <div className="p-4 flex items-center gap-4">
        <Skeleton className="w-12 h-12 rounded-xl shrink-0" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-3 w-20" />
        </div>
      </div>
    </GlassCard>
  );
}

// Animated stat card with glassmorphism
interface AnimatedStatCardProps {
  icon: React.ComponentType<{ className?: string }>;
  iconClassName: string;
  label: string;
  primaryValue: string;
  secondaryValue?: string;
  color: 'amber' | 'blue' | 'primary' | 'emerald' | 'rose';
  onClick?: () => void;
  delay?: number;
}

function AnimatedStatCard({
  icon: Icon,
  iconClassName,
  label,
  primaryValue,
  secondaryValue,
  color,
  onClick,
  delay = 0,
}: AnimatedStatCardProps) {
  return (
    <StaggerItem delay={delay}>
      <ColoredGlassCard
        color={color}
        hover
        className="h-full cursor-pointer"
        onClick={onClick}
      >
        <div className="flex items-center gap-4">
          <motion.div
            className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${iconClassName}`}
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ duration: 0.2 }}
          >
            <Icon className="w-6 h-6" />
          </motion.div>
          <div className="flex-1">
            <p className="text-sm text-warm-500">{label}</p>
            <motion.p
              className="font-bold text-lg text-warm-900"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: delay + 0.2, duration: 0.3 }}
            >
              {primaryValue}
            </motion.p>
            {secondaryValue && (
              <p className="text-xs text-warm-500">{secondaryValue}</p>
            )}
          </div>
        </div>
      </ColoredGlassCard>
    </StaggerItem>
  );
}

interface Task {
  id: string;
  title: string;
  dueDate?: string;
  priority: 'urgent' | 'high' | 'medium';
}

interface UrgentTask {
  id: string;
  title: string;
  dueDate?: string;
  priority?: string;
}

interface AITaskCategory {
  urgent: number;
  thisWeek: number;
  quickWins: number;
  financialImpact: number;
  planning: number;
  later: number;
}

interface StageRecommendation {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  tab: string;
}

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('tasks');
  const [planningOpen, setPlanningOpen] = useState(false);
  const [trackingOpen, setTrackingOpen] = useState(false);
  const [financeOpen, setFinanceOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [completedVaccines, setCompletedVaccines] = useState<string[]>([]);
  const [urgentTasks, setUrgentTasks] = useState<UrgentTask[]>([]);
  const [tasksLoading, setTasksLoading] = useState(true);
  const [aiCategories, setAiCategories] = useState<AITaskCategory>({
    urgent: 0,
    thisWeek: 0,
    quickWins: 0,
    financialImpact: 0,
    planning: 0,
    later: 0
  });

  // Real stats from Supabase
  const [savingsStats, setSavingsStats] = useState<{ totalSaved: number; totalTarget: number; goalCount: number } | null>(null);
  const [budgetStats, setBudgetStats] = useState<{ spent: number; budget: number; expenseCount: number } | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);

  // Selected task for scrolling
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        router.push('/auth/signin');
        return;
      }

      setUser(user);

      // Check onboarding
      const completed = await hasCompletedOnboarding(user.id);
      if (!completed) {
        router.push('/onboarding');
        return;
      }

      // Get profile
      const profileData = await getProfile(user.id);
      if (profileData?.profile) {
        setProfile(profileData.profile);
      } else {
        setProfile(null);
      }

      setLoading(false);
    };

    checkUser();
  }, [router]);

  // Hydrate completed vaccines from localStorage on mount (client-only)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const raw = window.localStorage.getItem('completedVaccines');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setCompletedVaccines(parsed.filter((id): id is string => typeof id === 'string'));
        }
      }
    } catch {
      /* ignore corrupt localStorage */
    }
  }, []);

  // Persist completed vaccines whenever they change
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      window.localStorage.setItem('completedVaccines', JSON.stringify(completedVaccines));
    } catch {
      /* localStorage full or disabled */
    }
  }, [completedVaccines]);

  // Pull tasks from Supabase and categorize with AI to match SmartTaskManager
  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;
    (async () => {
      setTasksLoading(true);
      try {
        const { data, error } = await supabase
          .from('tasks')
          .select('id, title, description, due_date, priority, status, category')
          .eq('user_id', user.id)
          .neq('status', 'completed')
          .order('priority_weight', { ascending: false })
          .order('due_date', { ascending: true, nullsFirst: false })
          ;
        if (cancelled) return;
        if (error) {
          console.error('Failed to load tasks:', error);
          setUrgentTasks([]);
          setAiCategories({ urgent: 0, thisWeek: 0, quickWins: 0, financialImpact: 0, planning: 0, later: 0 });
        } else {
          // Use AI categorization to group tasks (matches SmartTaskManager)
          const grouped = groupTasksByCategory(data || []);

          // Set AI category counts for dashboard display
          setAiCategories({
            urgent: grouped.urgent?.tasks?.length || 0,
            thisWeek: grouped['this-week']?.tasks?.length || 0,
            quickWins: grouped['quick-wins']?.tasks?.length || 0,
            financialImpact: grouped['financial-impact']?.tasks?.length || 0,
            planning: grouped.planning?.tasks?.length || 0,
            later: grouped.later?.tasks?.length || 0,
          });

          // Get top urgent tasks for the dashboard preview (showing all AI-urgent tasks)
          const now = Date.now();
          const urgentTaskList = (grouped.urgent?.tasks || []).slice(0, 4).map((t: any) => {
            let dueLabel: string | undefined;
            if (t.due_date) {
              const diffDays = Math.ceil(
                (new Date(t.due_date).getTime() - now) / (1000 * 60 * 60 * 24)
              );
              if (diffDays < 0) dueLabel = `${Math.abs(diffDays)} day${Math.abs(diffDays) === 1 ? '' : 's'} overdue`;
              else if (diffDays === 0) dueLabel = 'today';
              else if (diffDays === 1) dueLabel = '1 day';
              else if (diffDays < 7) dueLabel = `${diffDays} days`;
              else if (diffDays < 14) dueLabel = '1 week';
              else dueLabel = `${Math.ceil(diffDays / 7)} weeks`;
            }
            return {
              id: t.id,
              title: t.title,
              dueDate: dueLabel,
              priority: t.priority || 'medium',
            };
          });

          setUrgentTasks(urgentTaskList);
        }
      } catch (err) {
        console.error('Tasks fetch error:', err);
        if (!cancelled) {
          setUrgentTasks([]);
          setAiCategories({ urgent: 0, thisWeek: 0, quickWins: 0, financialImpact: 0, planning: 0, later: 0 });
        }
      } finally {
        if (!cancelled) setTasksLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id]);

  // Fetch real savings + budget stats
  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;
    (async () => {
      setStatsLoading(true);
      try {
        // Savings goals
        const { data: goals } = await supabase
          .from('savings_goals')
          .select('current_amount, target_amount')
          .eq('user_id', user.id) as { data: { current_amount: number; target_amount: number }[] | null };

        if (!cancelled) {
          if (goals && goals.length > 0) {
            const totalSaved = goals.reduce((sum: number, g: any) => sum + (Number(g.current_amount) || 0), 0);
            const totalTarget = goals.reduce((sum: number, g: any) => sum + (Number(g.target_amount) || 0), 0);
            setSavingsStats({ totalSaved, totalTarget, goalCount: goals.length });
          } else {
            setSavingsStats({ totalSaved: 0, totalTarget: 0, goalCount: 0 });
          }
        }

        // Budget settings + current month expenses
        const { data: budgetSettings } = await supabase
          .from('budget_settings')
          .select('monthly_budget')
          .eq('user_id', user.id)
          .maybeSingle() as { data: { monthly_budget: number | null } | null };

        const now = new Date();
        const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

        const { data: expenses } = await supabase
          .from('expenses')
          .select('amount')
          .eq('user_id', user.id)
          .gte('date', firstOfMonth) as { data: { amount: number }[] | null };

        if (!cancelled) {
          const spent = (expenses || []).reduce((sum: number, e: any) => sum + (Number(e.amount) || 0), 0);
          const budget = Number(budgetSettings?.monthly_budget) || 0;
          setBudgetStats({ spent, budget, expenseCount: (expenses || []).length });
        }
      } catch (err) {
        console.error('Stats fetch error:', err);
        if (!cancelled) {
          setSavingsStats({ totalSaved: 0, totalTarget: 0, goalCount: 0 });
          setBudgetStats({ spent: 0, budget: 0, expenseCount: 0 });
        }
      } finally {
        if (!cancelled) setStatsLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id]);

  // Calculate pregnancy stats
  const weeksPregnant = profile?.due_date
    ? Math.max(0, 40 - Math.ceil((new Date(profile.due_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24 * 7)))
    : null;

  const trimester = weeksPregnant
    ? weeksPregnant <= 12 ? 1 : weeksPregnant <= 27 ? 2 : 3
    : null;

  // Calculate days until due date
  const daysUntilDue = profile?.due_date
    ? Math.ceil((new Date(profile.due_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    : null;

  // Get stage-based recommendations
  const getStageRecommendations = (weeks: number | null): StageRecommendation[] => {
    if (!weeks) return [];

    if (weeks <= 12) {
      return [
        { title: 'Schedule first prenatal visit', icon: Activity, tab: 'tasks' },
        { title: 'Research insurance coverage', icon: Shield, tab: 'insurance' },
        { title: 'Start savings goals', icon: PiggyBank, tab: 'savings' },
      ];
    } else if (weeks <= 27) {
      return [
        { title: 'Review insurance coverage', icon: Shield, tab: 'insurance' },
        { title: 'Set up nursery savings plan', icon: PiggyBank, tab: 'savings' },
        { title: 'Calculate costs', icon: Calculator, tab: 'costcalc' },
      ];
    } else if (weeks <= 36) {
      return [
        { title: 'Pack hospital bag', icon: Backpack, tab: 'bag' },
        { title: 'Finalize birth plan', icon: FileText, tab: 'birthplan' },
        { title: 'Set up budget tracker', icon: Receipt, tab: 'budget' },
      ];
    } else {
      return [
        { title: 'Final birth plan check', icon: FileText, tab: 'birthplan' },
        { title: 'Prep hospital bag', icon: Backpack, tab: 'bag' },
        { title: 'Review all tasks', icon: CheckCircle2, tab: 'tasks' },
      ];
    }
  };

  const stageRecommendations = getStageRecommendations(weeksPregnant);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cream-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-warm-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream-50">
      {/* Subtle animated background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <AnimatedBackground
          variant="gradient"
          colors={['#FB8C8C', '#FEF0E6', '#A0D9E9']}
          intensity="subtle"
          speed="slow"
        />
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Today Card - Personalized command center */}
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            <Card className="bg-gradient-to-r from-primary-500 to-primary-600 text-white border-none shadow-glow overflow-hidden relative">
              {/* Animated gradient overlay */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                animate={{
                  x: ['-100%', '100%'],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  repeatDelay: 5,
                  ease: 'easeInOut',
                }}
              />
              <CardContent className="p-6 relative z-10">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <motion.div
                      className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm flex-shrink-0"
                      whileHover={{ scale: 1.05, rotate: [0, -5, 5, 0] }}
                      transition={{ duration: 0.5 }}
                    >
                      {weeksPregnant ? (
                        <div className="text-center">
                          <div className="text-xs font-medium text-primary-100 leading-none">WEEK</div>
                          <div className="text-xl font-bold leading-tight">{weeksPregnant}</div>
                        </div>
                      ) : (
                        <Heart className="w-7 h-7" />
                      )}
                    </motion.div>
                    <div className="min-w-0">
                      <motion.h2
                        className="text-2xl font-bold mb-1"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 }}
                      >
                        {(() => {
                          const hour = new Date().getHours();
                          const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
                          const name = profile?.full_name ? profile.full_name.split(' ')[0] : '';
                          return name ? `${greeting}, ${name}` : greeting;
                        })()}
                      </motion.h2>
                      <motion.p
                        className="text-primary-100 text-sm"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 }}
                      >
                        {weeksPregnant && daysUntilDue !== null
                          ? `${daysUntilDue > 0 ? `${daysUntilDue} days until your due date` : 'Your due date is here!'} · Trimester ${trimester}`
                          : profile?.due_date
                            ? 'Welcome to your pregnancy companion'
                            : 'Add your due date to personalize your dashboard'}
                      </motion.p>
                    </div>
                  </div>

                  {/* Quick action based on context */}
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 }}
                  >
                    {urgentTasks.length > 0 ? (
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setActiveTab('tasks');
                          setSelectedTaskId(urgentTasks[0].id);
                        }}
                        className="bg-white/15 text-white hover:bg-white/25 border border-white/20 backdrop-blur-sm whitespace-nowrap min-h-[44px]"
                      >
                        <Zap className="w-4 h-4 mr-2" />
                        Top task: {urgentTasks[0].title.slice(0, 30)}{urgentTasks[0].title.length > 30 ? '…' : ''}
                      </Button>
                    ) : !profile?.due_date ? (
                      <Button
                        variant="secondary"
                        onClick={() => router.push('/settings/family')}
                        className="bg-white/15 text-white hover:bg-white/25 border border-white/20 min-h-[44px]"
                      >
                        <Calendar className="w-4 h-4 mr-2" />
                        Add due date
                      </Button>
                    ) : (
                      <Button
                        variant="secondary"
                        onClick={() => setActiveTab('tasks')}
                        className="bg-white/15 text-white hover:bg-white/25 border border-white/20 min-h-[44px]"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        All caught up · View tasks
                      </Button>
                    )}
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Today Priority Summary — AI-Categorized Task Summary */}
        <div className="mb-8 space-y-6">
          {/* AI-Categorized Task Summary */}
          {tasksLoading ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-rose-300" />
                <Skeleton className="h-5 w-32" />
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                {[0, 1].map((i) => (
                  <GlassCard key={i}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <Skeleton className="w-10 h-10 rounded-full" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/3" />
                      </div>
                    </CardContent>
                  </GlassCard>
                ))}
              </div>
            </div>
          ) : (
            <motion.div
              className="space-y-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {/* Task Category Summary Bar - Ordered by Priority */}
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-sm text-warm-600 mr-2">Smart Tasks:</span>
                {aiCategories.urgent > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.1 }}
                  >
                    <Badge className="bg-rose-100 text-rose-700 border-rose-200 hover:bg-rose-200 transition-colors">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {aiCategories.urgent} Urgent
                    </Badge>
                  </motion.div>
                )}
                {aiCategories.thisWeek > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.15 }}
                  >
                    <Badge className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 transition-colors">
                      <Calendar className="w-3 h-3 mr-1" />
                      {aiCategories.thisWeek} This Week
                    </Badge>
                  </motion.div>
                )}
                {aiCategories.financialImpact > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-200 transition-colors">
                      <DollarSign className="w-3 h-3 mr-1" />
                      {aiCategories.financialImpact} Financial
                    </Badge>
                  </motion.div>
                )}
                {aiCategories.quickWins > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.25 }}
                  >
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-200 transition-colors">
                      <Zap className="w-3 h-3 mr-1" />
                      {aiCategories.quickWins} Quick Wins
                    </Badge>
                  </motion.div>
                )}
                {aiCategories.planning > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Badge className="bg-blue-100 text-blue-700 border-blue-200 hover:bg-blue-200 transition-colors">
                      <Lightbulb className="w-3 h-3 mr-1" />
                      {aiCategories.planning} Planning
                    </Badge>
                  </motion.div>
                )}
                {aiCategories.later > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.35 }}
                  >
                    <Badge variant="secondary" className="bg-gray-100 text-gray-600">
                      <Clock className="w-3 h-3 mr-1" />
                      {aiCategories.later} Later
                    </Badge>
                  </motion.div>
                )}
                {(aiCategories.urgent + aiCategories.thisWeek + aiCategories.quickWins + aiCategories.financialImpact + aiCategories.planning + aiCategories.later) === 0 && (
                  <motion.span
                    className="text-sm text-warm-500"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    All caught up! 🎉
                  </motion.span>
                )}
              </div>

              {/* Urgent Tasks Preview (if any) */}
              {urgentTasks.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-rose-500" />
                    <h3 className="font-semibold text-warm-900">Urgent Tasks</h3>
                    <Badge variant="secondary" className="bg-rose-100 text-rose-700">
                      {aiCategories.urgent}
                    </Badge>
                  </div>
                  <StaggerContainer staggerDelay={0.1} className="grid md:grid-cols-2 gap-3">
                    {urgentTasks.map((task) => (
                      <StaggerItem key={task.id}>
                        <ColoredGlassCard
                          color="rose"
                          hover
                          className="cursor-pointer"
                          onClick={() => {
                            setActiveTab('tasks');
                            setSelectedTaskId(task.id);
                          }}
                        >
                          <div className="flex items-center gap-3">
                            <motion.div
                              className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center"
                              whileHover={{ scale: 1.1, rotate: 10 }}
                            >
                              <Zap className="w-5 h-5 text-rose-500" />
                            </motion.div>
                            <div className="flex-1">
                              <p className="font-medium text-warm-900">{task.title}</p>
                              {task.dueDate && (
                                <p className="text-sm text-rose-600">Due in {task.dueDate}</p>
                              )}
                            </div>
                            <ChevronRight className="w-5 h-5 text-warm-400" />
                          </div>
                        </ColoredGlassCard>
                      </StaggerItem>
                    ))}
                  </StaggerContainer>
                </div>
              )}
            </motion.div>
          )}

          {/* Quick Stats Row with stagger animation */}
          <StaggerContainer staggerDelay={0.1} className="grid md:grid-cols-3 gap-4">
            {statsLoading ? (
              <>
                <StatCardSkeleton />
                <StatCardSkeleton />
                <StatCardSkeleton />
              </>
            ) : (
              <>
                {/* Savings Mini-Card */}
                <AnimatedStatCard
                  icon={PiggyBank}
                  iconClassName="bg-amber-100 text-amber-600"
                  label="Savings Goals"
                  primaryValue={savingsStats && savingsStats.goalCount > 0
                    ? `$${savingsStats.totalSaved.toLocaleString()} saved`
                    : 'No goals yet'}
                  secondaryValue={savingsStats && savingsStats.goalCount > 0
                    ? `of $${savingsStats.totalTarget.toLocaleString()} · ${savingsStats.goalCount} goal${savingsStats.goalCount !== 1 ? 's' : ''}`
                    : 'Tap to start saving →'}
                  color="amber"
                  onClick={() => setActiveTab('savings')}
                  delay={0}
                />

                {/* Budget Mini-Card */}
                <AnimatedStatCard
                  icon={Receipt}
                  iconClassName="bg-blue-100 text-blue-600"
                  label="This Month"
                  primaryValue={budgetStats && (budgetStats.budget > 0 || budgetStats.expenseCount > 0)
                    ? `$${budgetStats.spent.toLocaleString()} spent`
                    : 'No budget set'}
                  secondaryValue={budgetStats && (budgetStats.budget > 0 || budgetStats.expenseCount > 0)
                    ? budgetStats.budget > 0 ? `of $${budgetStats.budget.toLocaleString()} budget` : `${budgetStats.expenseCount} expense${budgetStats.expenseCount !== 1 ? 's' : ''}`
                    : 'Tap to set up →'}
                  color="blue"
                  onClick={() => setActiveTab('budget')}
                  delay={0.1}
                />

                {/* Timeline Card */}
                <AnimatedStatCard
                  icon={Clock}
                  iconClassName="bg-primary-100 text-primary-600"
                  label="Timeline"
                  primaryValue={daysUntilDue !== null ? `${daysUntilDue} days` : '—'}
                  secondaryValue={daysUntilDue !== null ? 'until due date' : 'Add due date'}
                  color="primary"
                  delay={0.2}
                />
              </>
            )}
          </StaggerContainer>

          {/* Discover - Quick Links with glassmorphism */}
          <StaggerContainer staggerDelay={0.1}>
            <div className="space-y-3">
              <motion.div
                className="flex items-center gap-2"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <Sparkles className="w-5 h-5 text-primary-500" />
                <h3 className="font-semibold text-warm-900">Discover</h3>
              </motion.div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {[
                  {
                    href: '/community',
                    title: 'Community Q&A',
                    description: 'Ask & answer with parents',
                    icon: Users,
                    color: 'amber' as const,
                  },
                ].map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <StaggerItem key={item.href} delay={index * 0.1}>
                      <Link href={item.href} className="group block h-full">
                        <ColoredGlassCard
                          color={item.color}
                          hover
                          className="h-full"
                        >
                          <div className="flex flex-col gap-3 h-full">
                            <motion.div
                              className={`w-10 h-10 rounded-xl flex items-center justify-center bg-${item.color}-100`}
                              whileHover={{ scale: 1.1, rotate: 5 }}
                            >
                              <Icon className={`w-5 h-5 text-${item.color}-600`} />
                            </motion.div>
                            <div className="flex-1">
                              <p className="font-semibold text-warm-900 text-sm leading-tight">{item.title}</p>
                              <p className="text-xs text-warm-500 mt-1">{item.description}</p>
                            </div>
                            <div className="flex items-center text-xs font-medium text-primary-600 group-hover:text-primary-700">
                              Explore
                              <motion.span
                                className="ml-1"
                                initial={{ x: 0 }}
                                whileHover={{ x: 4 }}
                              >
                                <ArrowRight className="w-3 h-3" />
                              </motion.span>
                            </div>
                          </div>
                        </ColoredGlassCard>
                      </Link>
                    </StaggerItem>
                  );
                })}
              </div>
            </div>
          </StaggerContainer>

          {/* Finance Center with glassmorphism cards */}
          <StaggerContainer staggerDelay={0.1}>
            <div className="space-y-3">
              <motion.div
                className="flex items-center gap-2"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <DollarSign className="w-5 h-5 text-emerald-500" />
                <div>
                  <h3 className="font-semibold text-warm-900">Finance Center</h3>
                  <p className="text-xs text-warm-500">Plan, save, and protect</p>
                </div>
              </motion.div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[
                  {
                    href: '/financial-timeline',
                    title: 'Financial Timeline',
                    description: 'Track baby costs by trimester',
                    icon: CalendarRange,
                    color: 'emerald' as const,
                    stat: daysUntilDue !== null ? `Due in ${Math.max(0, daysUntilDue)} days` : 'Set your due date',
                  },
                  {
                    href: '/baby-name',
                    title: '529 & Tax Savings',
                    description: 'Child Tax Credit, 529 deductions',
                    icon: PiggyBank,
                    color: 'amber' as const,
                    stat: 'Maximize benefits',
                  },
                  {
                    href: '/readiness',
                    title: 'Readiness Score',
                    description: 'Financial preparedness check',
                    icon: Target,
                    color: 'rose' as const,
                    stat: savingsStats && savingsStats.goalCount > 0 ? `${Math.round((savingsStats.totalSaved / Math.max(1, savingsStats.totalTarget)) * 100)}% ready` : 'Start assessment',
                  },
                ].map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <StaggerItem key={item.href} delay={index * 0.1}>
                      <Link href={item.href} className="group block h-full">
                        <ColoredGlassCard
                          color={item.color}
                          hover
                          className="h-full"
                        >
                          <div className="flex flex-col gap-3 h-full">
                            <motion.div
                              className={`w-10 h-10 rounded-xl flex items-center justify-center bg-${item.color}-100`}
                              whileHover={{ scale: 1.1, rotate: 5 }}
                            >
                              <Icon className={`w-5 h-5 text-${item.color}-600`} />
                            </motion.div>
                            <div className="flex-1">
                              <p className="font-semibold text-warm-900 text-sm leading-tight">{item.title}</p>
                              <p className="text-xs text-warm-500 mt-1">{item.description}</p>
                              {item.stat && (
                                <p className={`text-xs mt-2 font-medium text-${item.color}-600`}>{item.stat}</p>
                              )}
                            </div>
                            <div className="flex items-center text-xs font-medium text-emerald-600 group-hover:text-emerald-700">
                              Open
                              <motion.span
                                className="ml-1"
                                initial={{ x: 0 }}
                                whileHover={{ x: 4 }}
                              >
                                <ArrowRight className="w-3 h-3" />
                              </motion.span>
                            </div>
                          </div>
                        </ColoredGlassCard>
                      </Link>
                    </StaggerItem>
                  );
                })}
              </div>
            </div>
          </StaggerContainer>

          {/* Stage-Based Recommendations */}
          {weeksPregnant && (
            <StaggerContainer staggerDelay={0.1}>
              <div className="space-y-3">
                <motion.div
                  className="flex items-center gap-2"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                >
                  <Target className="w-5 h-5 text-primary-500" />
                  <h3 className="font-semibold text-warm-900">
                    Week {weeksPregnant} Recommendations
                  </h3>
                </motion.div>
                <div className="flex flex-wrap gap-2">
                  {stageRecommendations.map((rec, idx) => {
                    const Icon = rec.icon;
                    return (
                      <StaggerItem key={idx} delay={idx * 0.1}>
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2 border-warm-200 hover:border-primary-300 hover:bg-primary-50"
                            onClick={() => setActiveTab(rec.tab)}
                          >
                            <Icon className="w-4 h-4" />
                            {rec.title}
                            <Plus className="w-3 h-3" />
                          </Button>
                        </motion.div>
                      </StaggerItem>
                    );
                  })}
                </div>
              </div>
            </StaggerContainer>
          )}
        </div>

        {/* Dashboard Tabs */}
        <Tabs value={activeTab} onValueChange={(value) => {
          setActiveTab(value);
          setPlanningOpen(false);
          setTrackingOpen(false);
          setFinanceOpen(false);
        }} className="space-y-6">
          {/* MOBILE/TABLET: Horizontal scrollable pill nav */}
          <TabsList className="lg:hidden bg-white border border-warm-100 p-1 rounded-xl flex overflow-x-auto gap-1 h-auto shadow-soft scrollbar-hide">
            <TabsTrigger value="tasks" className="data-[state=active]:bg-primary-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px] font-semibold">
              <Wallet className="w-4 h-4 mr-1.5" /> Tasks
            </TabsTrigger>
            <TabsTrigger value="insurance" className="data-[state=active]:bg-cyan-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px] font-semibold">
              <Shield className="w-4 h-4 mr-1.5" /> Insurance
            </TabsTrigger>
            <TabsTrigger value="savings" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <PiggyBank className="w-4 h-4 mr-1.5" /> Savings
            </TabsTrigger>
            <TabsTrigger value="budget" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Receipt className="w-4 h-4 mr-1.5" /> Budget
            </TabsTrigger>
            <TabsTrigger value="costcalc" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Calculator className="w-4 h-4 mr-1.5" /> Costs
            </TabsTrigger>
            <TabsTrigger value="pregnancy" className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Baby className="w-4 h-4 mr-1.5" /> Pregnancy
            </TabsTrigger>
            <TabsTrigger value="vaccination" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Syringe className="w-4 h-4 mr-1.5" /> Vaccines
            </TabsTrigger>
            <TabsTrigger value="duedate" className="data-[state=active]:bg-primary-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Calendar className="w-4 h-4 mr-1.5" /> Due Date
            </TabsTrigger>
            <TabsTrigger value="isitsafe" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <ShieldCheck className="w-4 h-4 mr-1.5" /> Is It Safe?
            </TabsTrigger>
            <TabsTrigger value="bag" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Backpack className="w-4 h-4 mr-1.5" /> Hospital Bag
            </TabsTrigger>
            <TabsTrigger value="birthplan" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <FileText className="w-4 h-4 mr-1.5" /> Birth Plan
            </TabsTrigger>
            <TabsTrigger value="babynames" className="data-[state=active]:bg-rose-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Heart className="w-4 h-4 mr-1.5" /> Baby Names
            </TabsTrigger>
            <TabsTrigger value="postpartum" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Baby className="w-4 h-4 mr-1.5" /> Postpartum
            </TabsTrigger>
            <TabsTrigger value="registry" className="data-[state=active]:bg-fuchsia-500 data-[state=active]:text-white rounded-lg px-3 py-2 text-sm whitespace-nowrap min-h-[44px]">
              <Gift className="w-4 h-4 mr-1.5" /> Registry
            </TabsTrigger>
          </TabsList>

          <div className="grid lg:grid-cols-12 gap-6">
            {/* DESKTOP: Left Sidebar Navigation */}
            <aside className="hidden lg:block lg:col-span-3">
              <div className="sticky top-24 space-y-4">
                <TabsList className="flex flex-col w-full bg-white border border-warm-100 p-2 rounded-xl gap-1 h-auto shadow-soft">
                  {/* Priority section - Smart Tasks & Insurance */}
                  <div className="px-2 py-1.5 text-xs font-semibold text-primary-600 uppercase tracking-wide">Priority</div>
                  <TabsTrigger value="tasks" className="data-[state=active]:bg-primary-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px] font-semibold">
                    <Wallet className="w-4 h-4 mr-2" />
                    Smart Tasks
                  </TabsTrigger>
                  <TabsTrigger value="insurance" className="data-[state=active]:bg-cyan-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px] font-semibold">
                    <Shield className="w-4 h-4 mr-2" />
                    Insurance
                  </TabsTrigger>

                  {/* Money section */}
                  <div className="px-2 py-1.5 text-xs font-semibold text-warm-500 uppercase tracking-wide mt-2 border-t border-warm-100 pt-3">Money</div>
                  <TabsTrigger value="savings" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <PiggyBank className="w-4 h-4 mr-2" />
                    Savings Goals
                  </TabsTrigger>
                  <TabsTrigger value="budget" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Receipt className="w-4 h-4 mr-2" />
                    Budget Tracker
                  </TabsTrigger>
                  <TabsTrigger value="costcalc" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Calculator className="w-4 h-4 mr-2" />
                    Cost Estimator
                  </TabsTrigger>

                  {/* Pregnancy section */}
                  <div className="px-2 py-1.5 text-xs font-semibold text-warm-500 uppercase tracking-wide mt-2 border-t border-warm-100 pt-3">Pregnancy</div>
                  <TabsTrigger value="pregnancy" className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Baby className="w-4 h-4 mr-2" />
                    Pregnancy Guide
                  </TabsTrigger>
                  <TabsTrigger value="duedate" className="data-[state=active]:bg-primary-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Calendar className="w-4 h-4 mr-2" />
                    Due Date Calculator
                  </TabsTrigger>
                  <TabsTrigger value="isitsafe" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <ShieldCheck className="w-4 h-4 mr-2" />
                    Is It Safe?
                  </TabsTrigger>
                  <TabsTrigger value="vaccination" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Syringe className="w-4 h-4 mr-2" />
                    Vaccinations
                  </TabsTrigger>

                  {/* Postpartum section */}
                  <div className="px-2 py-1.5 text-xs font-semibold text-warm-500 uppercase tracking-wide mt-2 border-t border-warm-100 pt-3">Postpartum</div>
                  <TabsTrigger value="postpartum" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Baby className="w-4 h-4 mr-2" />
                    Postpartum
                  </TabsTrigger>

                  {/* Birth Prep section */}
                  <div className="px-2 py-1.5 text-xs font-semibold text-warm-500 uppercase tracking-wide mt-2 border-t border-warm-100 pt-3">Birth Prep</div>
                  <TabsTrigger value="bag" className="data-[state=active]:bg-pink-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Backpack className="w-4 h-4 mr-2" />
                    Hospital Bag
                  </TabsTrigger>
                  <TabsTrigger value="birthplan" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <FileText className="w-4 h-4 mr-2" />
                    Birth Plan
                  </TabsTrigger>
                  <TabsTrigger value="babynames" className="data-[state=active]:bg-rose-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Heart className="w-4 h-4 mr-2" />
                    Baby Names
                  </TabsTrigger>

                  {/* Other */}
                  <div className="px-2 py-1.5 text-xs font-semibold text-warm-500 uppercase tracking-wide mt-2 border-t border-warm-100 pt-3">Registry</div>
                  <TabsTrigger value="registry" className="data-[state=active]:bg-fuchsia-500 data-[state=active]:text-white rounded-lg px-3 py-2.5 text-sm w-full justify-start min-h-[44px]">
                    <Gift className="w-4 h-4 mr-2" />
                    Baby Registry
                  </TabsTrigger>
                </TabsList>
              </div>
            </aside>

            {/* MAIN CONTENT */}
            <div className="lg:col-span-9">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
              <TabsContent value="tasks" className="m-0">
                <SmartTaskManager
                  userId={user?.id}
                  state={profile?.state}
                  selectedTaskId={selectedTaskId}
                  onTaskSelected={() => setSelectedTaskId(null)}
                />
              </TabsContent>

              <TabsContent value="savings" className="m-0">
                <SavingsGoals
                  userId={user?.id}
                  dueDate={profile?.due_date}
                  incomeBracket={profile?.income_bracket}
                />
              </TabsContent>

              <TabsContent value="costcalc" className="m-0">
                <BabyCostCalculator />
              </TabsContent>

              <TabsContent value="budget" className="m-0">
                <BudgetTracker
                  userId={user?.id}
                  dueDate={profile?.due_date}
                  incomeBracket={profile?.income_bracket}
                />
              </TabsContent>

              <TabsContent value="bag" className="m-0">
                <HospitalBagPlanner />
              </TabsContent>

              <TabsContent value="pregnancy" className="m-0">
                <PregnancyTracker />
              </TabsContent>

              <TabsContent value="vaccination" className="m-0">
                <VaccinationTracker
                  completedVaccineIds={completedVaccines}
                  onCompletedChange={setCompletedVaccines}
                />
              </TabsContent>

              <TabsContent value="postpartum" className="m-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Baby className="w-5 h-5 text-pink-500" />
                      Postpartum
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-warm-600 mb-4">Track your postpartum recovery, baby metrics, feeding, and milestones.</p>
                    <Button onClick={() => router.push('/postpartum')}>
                      Open Postpartum Tracker
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="birthplan" className="m-0">
                <BirthPlanBuilder
                  userId={user?.id}
                  completedVaccineIds={completedVaccines}
                  onCompletedVaccinesChange={setCompletedVaccines}
                />
              </TabsContent>

              <TabsContent value="insurance" className="m-0">
                <InsuranceDocumentAnalyzer userId={user?.id} />
              </TabsContent>

              <TabsContent value="registry" className="m-0">
                <RegistryTracker userId={user?.id} />
              </TabsContent>

              <TabsContent value="duedate" className="m-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-primary-500" />
                      Due Date Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-warm-600 mb-4">Calculate your estimated due date based on your last menstrual period or conception date.</p>
                    <Button onClick={() => router.push('/due-date-calculator')}>
                      Open Due Date Calculator
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="isitsafe" className="m-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-500" />
                      Is It Safe?
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-warm-600 mb-4">Search our pregnancy safety database to find out if foods, medications, and activities are safe during pregnancy.</p>
                    <Button onClick={() => router.push('/is-it-safe')}>
                      Open Safety Database
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="babynames" className="m-0">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Heart className="w-5 h-5 text-rose-500" />
                      Baby Names
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-warm-600 mb-4">Browse baby names, meanings, and origins. Save your favorites!</p>
                    <Button onClick={() => router.push('/baby-names')}>
                      Explore Baby Names
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>

            {/* Collapsible Chat Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                {chatOpen ? (
                  <>
                    <div className="flex justify-end mb-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setChatOpen(false)}
                        className="text-warm-500 hover:text-warm-700"
                      >
                        <X className="w-4 h-4 mr-1" />
                        <span className="text-xs">Close</span>
                      </Button>
                    </div>
                    <Chat
                      userContext={{
                        state: profile?.state || undefined,
                        dueDate: profile?.due_date || undefined,
                        incomeBracket: profile?.income_bracket || undefined,
                      }}
                    />
                  </>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <Button
                      onClick={() => setChatOpen(true)}
                      className="shadow-lg rounded-full h-14 w-14 flex items-center justify-center"
                      title="Ask BabyNest Assistant"
                    >
                      <MessageCircle className="w-6 h-6" />
                    </Button>
                    <Button
                      onClick={() => setChatOpen(true)}
                      variant="outline"
                      className="gap-2 px-4 py-5 border-warm-200 shadow-soft"
                    >
                      <MessageCircle className="w-5 h-5" />
                      Ask AI
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
            </div>
          </div>
        </Tabs>
        {/* Finance Center Section */}
        <div className="container mx-auto my-8 px-4">
            <h2 className="text-xl font-semibold text-warm-800 mb-4">Finance Center</h2>
            <p className="text-base text-warm-600 mb-8">Plan, save, and protect your family's future with our financial tools.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Financial Timeline Card */}
              <Card className="shadow-md border border-warm-200">
                  <CardHeader>
                      <DollarSign className="text-primary-500 w-6 h-6" />
                      <CardTitle>Financial Timeline</CardTitle>
                  </CardHeader>
                  <CardContent>
                      <p className="text-warm-700">Estimate your baby's upcoming costs based on the due date.</p>
                      <Link href="/financial-timeline">Explore Timeline</Link>
                  </CardContent>
              </Card>
              {/* Hospital Cost Estimator Card */}
              <Card className="shadow-md border border-warm-200">
                  <CardHeader>
                      <Calculator className="text-primary-500 w-6 h-6" />
                      <CardTitle>Hospital Cost Estimator</CardTitle>
                  </CardHeader>
                  <CardContent>
                      <p className="text-warm-700">Calculate your estimated out-of-pocket costs for the hospital.</p>
                      <Link href="/hospital-costs">Estimate Costs</Link>
                  </CardContent>
              </Card>
              {/* 529 & Tax Savings Card */}
              <Card className="shadow-md border border-warm-200">
                  <CardHeader>
                      <PiggyBank className="text-primary-500 w-6 h-6" />
                      <CardTitle>529 & Tax Savings</CardTitle>
                  </CardHeader>
                  <CardContent>
                      <p className="text-warm-700">Discover potential tax benefits and savings with 529 plans.</p>
                      <Link href="/baby-name">Learn More</Link>
                  </CardContent>
              </Card>
              {/* Insurance Dashboard Card */}
              <Card className="shadow-md border border-warm-200">
                  <CardHeader>
                      <Shield className="text-primary-500 w-6 h-6" />
                      <CardTitle>Insurance Dashboard</CardTitle>
                  </CardHeader>
                  <CardContent>
                      <p className="text-warm-700">Check your current insurance coverage status.</p>
                      <Link href="/providers">View Dashboard</Link>
                  </CardContent>
              </Card>
              {/* Readiness Score Card */}
              <Card className="shadow-md border border-warm-200">
                  <CardHeader>
                      <Target className="text-primary-500 w-6 h-6" />
                      <CardTitle>Readiness Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                      <p className="text-warm-700">Assess your financial preparedness for the new arrival.</p>
                      <Link href="/readiness">Check Readiness</Link>
                  </CardContent>
              </Card>
            </div>
        </div>
      </div>
    </div>
  );
}
