-- Migration: Update registry_items table to support the import feature
-- Run this in Supabase SQL Editor

-- First, check if the table exists and update it
DO $$
BEGIN
    -- Add new columns if they don't exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'user_id') THEN
        ALTER TABLE registry_items ADD COLUMN user_id UUID REFERENCES profiles(id) ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'source') THEN
        ALTER TABLE registry_items ADD COLUMN source VARCHAR(50);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'external_url') THEN
        ALTER TABLE registry_items ADD COLUMN external_url TEXT;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'status') THEN
        ALTER TABLE registry_items ADD COLUMN status VARCHAR(20) DEFAULT 'wanted';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'priority') THEN
        ALTER TABLE registry_items ADD COLUMN priority VARCHAR(20) DEFAULT 'essential';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'quantity') THEN
        ALTER TABLE registry_items ADD COLUMN quantity INTEGER DEFAULT 1;
    END IF;

    -- Rename product_url to external_url if that's all we have
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'product_url') 
       AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'external_url') THEN
        ALTER TABLE registry_items RENAME COLUMN product_url TO external_url;
    END IF;

    -- Migrate is_purchased to status
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'is_purchased') THEN
        UPDATE registry_items SET status = 'purchased' WHERE is_purchased = TRUE AND status = 'wanted';
    END IF;

    -- Migrate is_essential to priority
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'registry_items' AND column_name = 'is_essential') THEN
        UPDATE registry_items SET priority = 'essential' WHERE is_essential = TRUE;
        UPDATE registry_items SET priority = 'nice-to-have' WHERE is_essential = FALSE;
    END IF;

EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Error updating registry_items: %', SQLERRM;
END $$;

-- Enable RLS
ALTER TABLE registry_items ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if exists
DROP POLICY IF EXISTS "Users can CRUD own registry items" ON registry_items;

-- Create policy
CREATE POLICY "Users can CRUD own registry items"
  ON registry_items
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_registry_items_user_id ON registry_items(user_id);
CREATE INDEX IF NOT EXISTS idx_registry_items_status ON registry_items(status);
