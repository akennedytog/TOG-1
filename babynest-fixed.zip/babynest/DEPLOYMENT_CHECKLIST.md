# BabyNest Deployment Checklist

## Pre-Deployment Verification

### ✅ Code Complete
- [x] 7-step onboarding wizard
- [x] 50 states database populated
- [x] 20+ auto-generated tasks
- [x] AI chat integration
- [x] Insurance OCR upload
- [x] Authentication (sign up/sign in)
- [x] Dashboard with task management
- [x] RLS policies configured

### ✅ Database Setup
- [x] Supabase project: aduocseaimyczipgdjbj
- [x] All 50 states in database
- [x] RLS policies configured
- [x] profiles table columns added
- [x] tasks table set up

### Environment Variables (.env.local)
```
NEXT_PUBLIC_SUPABASE_URL=https://aduocseaimyczipgdjbj.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
OPENAI_API_KEY=your-openai-key
```

## Deployment Steps

### 1. Build Verification
```bash
cd /Users/aleckennedy/.openclaw/workspace/babynest
npm run build
```

### 2. Vercel Deployment
```bash
# Install Vercel CLI if not installed
npm i -g vercel

# Deploy
vercel --prod
```

### 3. Environment Variables in Vercel
- Go to Vercel Dashboard
- Project Settings → Environment Variables
- Add all variables from .env.local

### 4. Custom Domain (Optional)
- theonegroup.info subdomain
- Or new domain: babynest.app

## Post-Deployment
- [ ] Test sign up flow
- [ ] Test onboarding
- [ ] Verify tasks generate
- [ ] Test AI chat
- [ ] Check mobile responsiveness

## Production Considerations
- [ ] Add error tracking (Sentry)
- [ ] Add analytics (already have Vercel)
- [ ] Set up monitoring
- [ ] Configure email (Resend)
- [ ] Set up Stripe payments

---

## Deployment Command Ready:
```bash
cd /Users/aleckennedy/.openclaw/workspace/babynest && vercel --prod
```

**Ready to deploy?**