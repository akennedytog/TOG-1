import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// CSRF protection middleware
export function middleware(request: NextRequest) {
  // Only apply to API routes
  if (!request.nextUrl.pathname.startsWith('/api/')) {
    return NextResponse.next()
  }

  const method = request.method || 'GET'

  // Skip GET requests (safe methods)
  if (method === 'GET' || method === 'HEAD') {
    return NextResponse.next()
  }

  // Check origin/referer for state-changing operations
  const origin = request.headers.get('origin') || ''
  
  // In production, validate against your domain
  const allowedOrigins = [
    process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
    // Add your production domains
  ]
  
  // For state-changing requests, require proper origin
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
    // Skip validation for Stripe webhooks (they come from Stripe)
    if (request.nextUrl.pathname === '/api/stripe/webhook') {
      return NextResponse.next()
    }
    
    // In development, be lenient
    if (process.env.NODE_ENV === 'development') {
      return NextResponse.next()
    }
    
    // In production, validate origin
    if (origin && !allowedOrigins.some(allowed => origin.startsWith(allowed))) {
      return NextResponse.json(
        { error: 'Invalid origin' },
        { status: 403 }
      )
    }
  }

  // Add security headers
  const response = NextResponse.next()
  
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-XSS-Protection', '1; mode=block')
  
  return response
}

// Apply middleware to specific paths
export const config = {
  matcher: [
    '/api/:path*',
  ],
}
