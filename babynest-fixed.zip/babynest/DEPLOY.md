# BabyNest Deployment Guide

## Deploy to Netlify (Separate from The One Group)

### Option 1: Deploy via Netlify CLI (Recommended)

1. **Install Netlify CLI** (if not already installed):
   ```bash
   npm install -g netlify-cli
   ```

2. **Login to Netlify**:
   ```bash
   netlify login
   ```

3. **Initialize a new site** (in the babynest folder):
   ```bash
   cd /Users/aleckennedy/.openclaw/workspace/babynest
   netlify init
   ```
   - Choose "Create & configure a new site"
   - Pick your team (personal account)
   - Site name suggestion: `babynest-app` (or whatever you prefer)

4. **Set environment variables** in Netlify:
   ```bash
   netlify env:set NEXT_PUBLIC_SUPABASE_URL https://aduocseaimyczipgdjbj.supabase.co
   netlify env:set NEXT_PUBLIC_SUPABASE_ANON_KEY your_anon_key_here
   netlify env:set SUPABASE_SERVICE_ROLE_KEY your_service_role_key_here
   ```

5. **Deploy**:
   ```bash
   netlify deploy --prod
   ```

### Option 2: Deploy via Git (GitHub → Netlify)

1. **Create a GitHub repo** for BabyNest (keep it private)

2. **Push code to GitHub**:
   ```bash
   cd /Users/aleckennedy/.openclaw/workspace/babynest
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/babynest.git
   git push -u origin main
   ```

3. **Connect in Netlify Dashboard**:
   - Go to https://app.netlify.com
   - "Add new site" → "Import an existing project"
   - Connect to GitHub
   - Select your BabyNest repo
   - Build settings:
     - Build command: `npm run build`
     - Publish directory: `.next`
   - Add environment variables in Site settings → Environment variables

### Required Environment Variables

Add these in Netlify → Site settings → Environment variables:

| Variable | Value |
|----------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://aduocseaimyczipgdjbj.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Your service role key |

### After Deployment

- **Site URL**: Will be something like `https://babynest-app-123.netlify.app`
- **Custom domain**: You can add later in Site settings → Domain management
- **The One Group site**: Stays at `https://theonegroup.info` (completely separate)

### Quick Deploy Script

Save this as `deploy.sh` in the babynest folder:

```bash
#!/bin/bash
echo "🚀 Deploying BabyNest to Netlify..."
npm run build
netlify deploy --prod
echo "✅ Deployed!"
```

Then run: `chmod +x deploy.sh && ./deploy.sh`
