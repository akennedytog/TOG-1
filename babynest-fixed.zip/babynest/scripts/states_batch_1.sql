-- BabyNest State Content - Batch 1 (States 1-9)
-- States: AL, AK, AZ, AR, CO, CT, DE, GA, HI
-- Run this in Supabase SQL Editor

-- Alabama
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Alabama',
    'AL',
    'Alabama CollegeCounts 529 Fund',
    'The Alabama CollegeCounts 529 Fund is a tax-advantaged savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Alabama state income tax, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.collegecounts529.com/',
    '{"state_income_tax": "2% - 5%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "20% to 35% of qualifying expenses, depending on income.", "earned_income_credit": "Follows federal guidelines; percentage of the federal credit.", "unique_deductions": ["Alabama offers a deduction for contributions to the CollegeCounts 529 Fund."]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "ALL Kids", "medicaid_expansion": false, "special_rules": "Newborns must be enrolled within 60 days to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "Alabama Prepaid Affordable College Tuition (PACT)", "matching_grants": "No state matching grants available.", "scholarships": "Alabama offers various state scholarships based on merit and need.", "other": "Alabama provides the ALL Kids CHIP program for low-cost health coverage for children."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in Alabama. From saving for college with the CollegeCounts 529 Fund to understanding tax benefits and insurance rules, there are several financial considerations to keep in mind. Alabama offers a state income tax deduction for contributions to its 529 plan, and families can benefit from various tax credits and deductions. Additionally, understanding health insurance enrollment deadlines and options like the ALL Kids program can help ensure your child is covered.", "key_deadlines": ["Enroll newborn in health insurance within 60 days.", "Consider opening a 529 plan early to maximize savings."], "action_items": ["Open a CollegeCounts 529 Fund account.", "Review health insurance options and enroll your newborn.", "Explore available tax credits and deductions."], "resources": ["https://www.collegecounts529.com/", "https://www.alabamapublichealth.gov/allkids/", "https://www.revenue.alabama.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Alaska
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Alaska',
    'AK',
    'Alaska 529',
    'Alaska 529 is a tax-advantaged college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Alaska does not have a state income tax, contributions grow tax-deferred and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.alaska529plan.com',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines, up to $2,000 per child.", "dependent_care_credit": "Follows federal guidelines, up to 35% of qualifying expenses.", "earned_income_credit": "Follows federal guidelines, available to low- to moderate-income working families.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Denali KidCare", "medicaid_expansion": true, "special_rules": "Alaska provides automatic coverage for newborns under existing family plans for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "Alaska does not currently offer matching grants for 529 contributions.", "scholarships": "Alaska Performance Scholarship for high school graduates meeting specific criteria.", "other": "Alaska offers the Alaska Education Loan for residents pursuing higher education."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and financial planning is an important part of preparing for your child''s future. In Alaska, parents can take advantage of the Alaska 529 plan to save for education expenses, benefiting from tax-free growth and withdrawals for qualified expenses. While Alaska does not have a state income tax, it provides several federal tax credits and benefits that can help reduce the financial burden of raising a child. Additionally, programs like Denali KidCare ensure that your child has access to necessary healthcare services.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Consider opening an Alaska 529 account as early as possible to maximize growth potential."], "action_items": ["Open an Alaska 529 account to start saving for future education expenses.", "Enroll your newborn in a health insurance plan within the first 30 days.", "Explore eligibility for federal tax credits such as the Child Tax Credit and Earned Income Credit."], "resources": ["https://www.alaska529plan.com", "https://dhss.alaska.gov/dpa/Pages/medicaid/DenaliKidCare.aspx", "https://www.irs.gov/credits-deductions/individuals/earned-income-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Arizona
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Arizona',
    'AZ',
    'AZ529, Arizona''s Education Savings Plan',
    'AZ529 is Arizona''s official 529 college savings plan, designed to help families save for future education expenses with tax advantages. Contributions grow tax-deferred, and withdrawals used for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "up to $2,000 for single filers and $4,000 for joint filers", "deduction_amount_single": 2000, "deduction_amount_married": 4000, "earnings_tax_free": true, "notes": "Contributions are deductible from Arizona state income tax."}'::jsonb,
    'https://az529.gov/',
    '{"state_income_tax": "2.59% to 4.50%", "child_tax_credit": "Up to $2,000 per qualifying child under federal law", "dependent_care_credit": "25% of the federal credit", "earned_income_credit": "None", "unique_deductions": ["Contributions to AZ529", "Military retirement pay exclusion"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "KidsCare", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "The Arizona Community Foundation offers various scholarships for state residents.", "other": "Arizona offers tax credits for private school tuition organizations."}'::jsonb,
    '{"overview": "Welcoming a new baby is a joyous occasion, but it also comes with financial responsibilities. In Arizona, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. From saving for future education expenses with the AZ529 plan to understanding state-specific tax credits, there are many ways to plan for your child''s future. Additionally, Arizona provides healthcare coverage options for newborns and young children through programs like KidsCare.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "File state taxes to claim AZ529 deductions by April 15"], "action_items": ["Open an AZ529 account", "Review health insurance coverage for your newborn", "Explore available scholarships and grants"], "resources": ["https://az529.gov/", "https://www.azdor.gov/TaxCredits.aspx", "https://www.azahcccs.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Arkansas
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Arkansas',
    'AR',
    'Arkansas Brighter Future 529 Plan',
    'The Arkansas Brighter Future 529 Plan is designed to help families save for future education expenses with tax advantages. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "up to $10,000 for married couples filing jointly and $5,000 for individuals", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Arkansas state income tax."}'::jsonb,
    'https://www.arkansas529.org',
    '{"state_income_tax": "2% to 5.5%", "child_tax_credit": "Follows federal child tax credit rules", "dependent_care_credit": "20% of the federal credit", "earned_income_credit": "3% of the federal EITC", "unique_deductions": ["Tuition deduction for higher education", "Credit for adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "ARKids First", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "The Gift Arkansas 529 Matching Grant Program offers matching contributions for eligible families.", "scholarships": "Arkansas Academic Challenge Scholarship for residents attending in-state colleges.", "other": "Arkansas offers the ARKids First program for children''s health insurance."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Arkansas, parents can take advantage of various state programs and tax benefits to ease the financial burden. The Arkansas Brighter Future 529 Plan offers tax advantages for saving for your child''s education, while the ARKids First program ensures affordable health coverage. Understanding these resources can help you plan effectively for your child''s future.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Apply for ARKids First as soon as possible after birth"], "action_items": ["Open an Arkansas Brighter Future 529 account", "Review eligibility for ARKids First", "Check eligibility for state tax credits"], "resources": ["https://www.arkansas529.org", "https://humanservices.arkansas.gov/about-dhs/dms/arkids", "https://www.irs.gov/credits-deductions/individuals/earned-income-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Colorado
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Colorado',
    'CO',
    'CollegeInvest Direct Portfolio College Savings Plan',
    'The CollegeInvest Direct Portfolio College Savings Plan offers a tax-advantaged way to save for higher education expenses. Managed by Vanguard, it provides a variety of investment options to suit different risk tolerances and savings goals.',
    '{"state_tax_deduction": "Full amount of contributions", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Colorado state income tax in the year they are made."}'::jsonb,
    'https://www.collegeinvest.org/',
    '{"state_income_tax": "4.4%", "child_tax_credit": "Follows federal guidelines with additional state credits for low-income families.", "dependent_care_credit": "Up to $1,000 per child for low-income families.", "earned_income_credit": "10% of the federal EITC for eligible families.", "unique_deductions": ["Contributions to a 529 plan", "Child care expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Child Health Plan Plus (CHP+)", "medicaid_expansion": true, "special_rules": "Colorado offers a special enrollment period for newborns within 30 days of birth."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "CollegeInvest offers matching grants for qualifying low- and middle-income families.", "scholarships": "CollegeInvest offers scholarships through its Matching Grant and Scholarship Program.", "other": "CollegeInvest also provides financial literacy resources for families."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is an exciting time, and planning for their future is an important step. In Colorado, parents have access to a variety of financial tools and resources to help manage the costs of raising a child. From tax-advantaged savings plans to state-specific tax credits, understanding these options can help you make informed decisions. Additionally, Colorado offers health insurance programs to ensure your child has access to necessary medical care.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Open a 529 plan as early as possible to maximize savings"], "action_items": ["Review and enroll in a 529 plan", "Apply for health insurance for your newborn", "Explore available tax credits and deductions"], "resources": ["https://www.collegeinvest.org/", "https://www.colorado.gov/pacific/hcpf/child-health-plan-plus", "https://www.colorado.gov/pacific/cdle/tax-credits"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Connecticut
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Connecticut',
    'CT',
    'CHET 529 College Savings Program',
    'The CHET 529 College Savings Program is Connecticut''s tax-advantaged savings plan designed to help families save for future college expenses. It offers a range of investment options and is open to residents and non-residents alike.',
    '{"state_tax_deduction": "false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are not deductible on Connecticut state taxes, but earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.aboutchet.com',
    '{"state_income_tax": "3% to 6.99%", "child_tax_credit": "Connecticut does not offer a state-level child tax credit.", "dependent_care_credit": "Connecticut offers a dependent care credit that is a percentage of the federal credit.", "earned_income_credit": "Connecticut offers a refundable Earned Income Tax Credit equal to 30.5% of the federal EITC.", "unique_deductions": ["Property tax credit", "Social Security income exclusion"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "HUSKY B", "medicaid_expansion": true, "special_rules": "Connecticut''s HUSKY Health program provides coverage for children and families with varying income levels."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "CHET Baby Scholars offers a $100 contribution for babies under one year old when an account is opened.", "scholarships": "CHET Advance Scholarship awards scholarships to high school seniors and college students.", "other": "CHET Dream Big! Competition offers additional opportunities for account holders."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Connecticut, parents have access to the CHET 529 College Savings Program, which offers tax advantages and flexible investment options to help save for college expenses. Additionally, Connecticut provides various tax benefits and health insurance programs to support families.", "key_deadlines": ["Enroll newborns in health insurance within 60 days of birth.", "Open a CHET 529 account early to take advantage of the CHET Baby Scholars program."], "action_items": ["Consider opening a CHET 529 College Savings account.", "Review eligibility for Connecticut''s HUSKY Health program.", "Explore Connecticut''s tax credits and deductions for families."], "resources": ["https://www.aboutchet.com", "https://portal.ct.gov/HUSKY", "https://portal.ct.gov/DRS"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Delaware
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Delaware',
    'DE',
    'Delaware College Investment Plan',
    'The Delaware College Investment Plan is a tax-advantaged savings plan designed to help families save for future education expenses. It offers a variety of investment options managed by Fidelity, allowing flexibility and growth potential.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Delaware does not offer a state tax deduction for contributions, the earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.fidelity.com/529-plans/delaware',
    '{"state_income_tax": "2.2% - 6.6%", "child_tax_credit": "Follows federal rules; no additional state credit", "dependent_care_credit": "20% of the federal credit", "earned_income_credit": "20% of the federal EITC", "unique_deductions": ["No state-specific deductions for children"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Delaware Healthy Children Program", "medicaid_expansion": true, "special_rules": "Delaware provides automatic coverage for newborns under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None available", "scholarships": "The Delaware Scholarship Compendium provides information on various scholarships available to residents.", "other": "Delaware offers the SEED (Student Excellence Equals Degree) Scholarship for eligible students attending Delaware Technical Community College."}'::jsonb,
    '{"overview": "Planning for a new baby involves understanding the financial implications and taking advantage of available resources. In Delaware, parents can benefit from the Delaware College Investment Plan to save for future education expenses. While the state does not offer a tax deduction for contributions, the plan''s tax-free growth on earnings can be a significant advantage. Additionally, Delaware provides various tax benefits and credits that can help reduce the financial burden on families.", "key_deadlines": ["Enroll newborns in health insurance within 30 days of birth", "Annual tax filing deadline: April 15"], "action_items": ["Open a Delaware College Investment Plan account", "Review health insurance options for newborn coverage", "Explore available scholarships and grants"], "resources": ["https://www.fidelity.com/529-plans/delaware", "https://dhss.delaware.gov/dhss/dss/dhcp.html", "https://www.delawarestudentsuccess.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Georgia
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Georgia',
    'GA',
    'Path2College 529 Plan',
    'The Path2College 529 Plan is Georgia''s official college savings plan, offering tax-advantaged savings options to help families prepare for future education expenses. It provides a range of investment options and is managed by TIAA-CREF Tuition Financing, Inc.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 4000, "deduction_amount_married": 8000, "earnings_tax_free": true, "notes": "Contributions are deductible from Georgia state income tax, and the earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.path2college529.com/',
    '{"state_income_tax": "5.75%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "20% to 35% of eligible expenses, similar to federal", "earned_income_credit": "No state EITC; follows federal guidelines", "unique_deductions": ["Contributions to the Path2College 529 Plan"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "PeachCare for Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered for the first 30 days under the mother''s health plan."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "No state matching grants available", "scholarships": "HOPE Scholarship for eligible Georgia residents", "other": "Georgia offers the Zell Miller Scholarship for students with exceptional academic performance."}'::jsonb,
    '{"overview": "As new parents in Georgia, planning for your child''s future involves understanding the financial tools and benefits available to you. The Path2College 529 Plan is a key resource, offering tax advantages and a variety of investment options to help you save for your child''s education. Additionally, Georgia provides several tax benefits and programs to support families, including the PeachCare for Kids program for health coverage.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth", "Annual contribution deadline for 529 tax deductions: December 31"], "action_items": ["Open a Path2College 529 Plan account", "Enroll your newborn in health insurance within the first 30 days", "Explore eligibility for PeachCare for Kids and Medicaid"], "resources": ["https://www.path2college529.com/", "https://dch.georgia.gov/peachcare-kids", "https://www.georgiafutures.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Hawaii
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Hawaii',
    'HI',
    'Hawaii''s College Savings Program',
    'Hawaii''s College Savings Program offers a tax-advantaged way to save for college expenses. The plan provides flexibility in investment options and can be used at eligible institutions nationwide.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Hawaii does not offer a state tax deduction for contributions to the 529 plan."}'::jsonb,
    'https://www.uhero.hawaii.edu/529-college-savings-plan/',
    '{"state_income_tax": "1.4% to 11%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "15% of the federal credit", "earned_income_credit": "20% of the federal EITC", "unique_deductions": ["None specific to children"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Hawaii QUEST", "medicaid_expansion": true, "special_rules": "Hawaii provides comprehensive coverage through its QUEST program, which includes CHIP and Medicaid services."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "Hawaii B+ Scholarship for high school graduates attending UH campuses", "other": "Hawaii offers the Early Learning Scholarship Program for preschool-aged children."}'::jsonb,
    '{"overview": "Planning for a new baby in Hawaii involves understanding the financial landscape, including education savings, tax benefits, and healthcare options. Hawaii offers a 529 College Savings Plan to help parents save for future education costs, though it does not provide a state tax deduction for contributions. Healthcare coverage for newborns is comprehensive, with automatic coverage periods and access to programs like Hawaii QUEST. Additionally, parents can benefit from state tax credits and unique educational programs.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "File taxes by April 15 to claim credits"], "action_items": ["Open a 529 plan for education savings", "Enroll newborn in Hawaii QUEST if eligible", "Explore state tax credits and deductions"], "resources": ["https://www.uhero.hawaii.edu/529-college-savings-plan/", "https://medquest.hawaii.gov/", "https://www.hawaii.edu/finaid/scholarships/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();
