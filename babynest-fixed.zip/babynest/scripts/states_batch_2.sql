-- BabyNest State Content - Batch 2 (States 10-18)
-- States: ID, IN, IA, KS, KY, LA, ME, MD, MA
-- Run this in Supabase SQL Editor

-- Idaho
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Idaho',
    'ID',
    'IDeal - Idaho College Savings Program',
    'IDeal is Idaho''s 529 college savings plan, offering tax-advantaged savings for education expenses. It provides flexible investment options and can be used for a variety of education-related costs.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Idaho state income tax, up to $6,000 for single filers and $12,000 for joint filers."}'::jsonb,
    'https://www.idsaves.org/',
    '{"state_income_tax": "1.125% to 6.925%", "child_tax_credit": "Idaho offers a nonrefundable child tax credit of $205 per qualifying child.", "dependent_care_credit": "Idaho provides a credit equal to 50% of the federal credit for child and dependent care expenses.", "earned_income_credit": "Idaho does not offer a state-specific earned income credit.", "unique_deductions": ["Contributions to Idaho 529 plans", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Idaho Children''s Health Insurance Program (CHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "IDeal occasionally offers matching grant promotions for new accounts.", "scholarships": "IDeal offers scholarships through various promotions and partnerships.", "other": "IDeal provides financial literacy resources for families."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Idaho, parents have access to the IDeal 529 College Savings Program, which offers tax advantages and flexible savings options for education expenses. Understanding the state''s tax benefits and insurance rules can help parents make informed financial decisions.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Consider opening a 529 plan soon after birth"], "action_items": ["Open an IDeal 529 account", "Review health insurance coverage for your newborn", "Explore Idaho''s tax benefits for families"], "resources": ["https://www.idsaves.org/", "https://healthandwelfare.idaho.gov/", "https://tax.idaho.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Indiana
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Indiana',
    'IN',
    'CollegeChoice 529 Direct Savings Plan',
    'The CollegeChoice 529 Direct Savings Plan offers a flexible and tax-advantaged way for families to save for future education expenses. It provides a variety of investment options and is open to both Indiana residents and non-residents.',
    '{"state_tax_deduction": "up to $1,500", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Indiana state income tax up to $1,500 per taxpayer, per year."}'::jsonb,
    'https://www.collegechoicedirect.com/',
    '{"state_income_tax": "3.23%", "child_tax_credit": "Follows federal guidelines, up to $2,000 per qualifying child.", "dependent_care_credit": "20% of the federal credit, non-refundable.", "earned_income_credit": "9% of the federal earned income credit.", "unique_deductions": ["Adoption Credit", "Education Expense Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Hoosier Healthwise", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Not available", "scholarships": "The 21st Century Scholars Program offers income-eligible students up to four years of undergraduate tuition at participating Indiana colleges.", "other": "Indiana offers the On My Way Pre-K program for eligible 4-year-olds."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents. In Indiana, families can take advantage of the CollegeChoice 529 Direct Savings Plan to start saving for their child''s education with tax advantages. Additionally, understanding state tax benefits and insurance rules will help ensure your family is financially prepared.", "key_deadlines": ["60 days to enroll newborns in health insurance", "April 15 for state tax deductions"], "action_items": ["Open a CollegeChoice 529 account", "Review health insurance coverage for your newborn", "Explore eligibility for the 21st Century Scholars Program"], "resources": ["https://www.collegechoicedirect.com/", "https://www.in.gov/fssa/ompp/hoosier-healthwise/", "https://scholars.in.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Iowa
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Iowa',
    'IA',
    'College Savings Iowa 529 Plan',
    'The College Savings Iowa 529 Plan offers a tax-advantaged way to save for education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $3,785 per beneficiary", "deduction_amount_single": 3785, "deduction_amount_married": 7570, "earnings_tax_free": true, "notes": "The deduction amount is adjusted annually for inflation."}'::jsonb,
    'https://www.collegesavingsiowa.com',
    '{"state_income_tax": "4.4% - 8.53%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child", "dependent_care_credit": "Up to 75% of the federal credit", "earned_income_credit": "15% of the federal EITC", "unique_deductions": ["Tuition and Textbook Credit", "Iowa Adoption Tax Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "31 days", "chip_program": "hawk-i", "medicaid_expansion": true, "special_rules": "Iowa provides automatic enrollment for newborns under existing family plans for the first 31 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "Iowa Tuition Grant for private college students", "other": "Iowa offers the Future Ready Iowa Last-Dollar Scholarship for community college students."}'::jsonb,
    '{"overview": "As a new parent in Iowa, it''s important to consider the financial aspects of raising a child, including education savings, tax benefits, and insurance coverage. Iowa offers a robust 529 plan, College Savings Iowa, which provides tax advantages for saving for your child''s future education. Additionally, understanding state tax benefits and insurance rules can help you make informed decisions for your family''s financial well-being.", "key_deadlines": ["Enroll newborns in health insurance within 60 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a College Savings Iowa 529 account", "Review and adjust your health insurance coverage", "Explore state tax credits and deductions"], "resources": ["https://www.collegesavingsiowa.com", "https://dhs.iowa.gov/hawki", "https://tax.iowa.gov"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Kansas
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Kansas',
    'KS',
    'Learning Quest 529 Education Savings Program',
    'The Learning Quest 529 Education Savings Program is Kansas''s tax-advantaged college savings plan. It offers a variety of investment options managed by American Century Investments, designed to help families save for future education expenses.',
    '{"state_tax_deduction": "up to $3,000 per beneficiary", "deduction_amount_single": 3000, "deduction_amount_married": 6000, "earnings_tax_free": true, "notes": "Contributions are deductible from Kansas state income tax for each beneficiary."}'::jsonb,
    'https://www.learningquest.com',
    '{"state_income_tax": "3.1% to 5.7%", "child_tax_credit": "Follows federal child tax credit rules", "dependent_care_credit": "Up to 25% of the federal credit", "earned_income_credit": "17% of the federal credit", "unique_deductions": ["529 plan contributions", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "KanCare", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "No state matching grants available", "scholarships": "Kansas offers various scholarships through state universities and private organizations.", "other": "Kansas offers the Kansas Promise Scholarship for specific high-demand fields."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Kansas, parents can take advantage of the Learning Quest 529 Education Savings Program to start saving for their child''s future education. Additionally, understanding state tax benefits and insurance rules can help parents manage expenses effectively. Kansas provides several tax credits and deductions that can ease the financial burden of raising a child.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a 529 plan account", "Review health insurance coverage options", "Explore available tax credits and deductions"], "resources": ["https://www.learningquest.com", "https://www.kancare.ks.gov", "https://www.ksrevenue.org"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Kentucky
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Kentucky',
    'KY',
    'Kentucky Education Savings Plan Trust',
    'The Kentucky Education Savings Plan Trust is a 529 college savings plan that offers tax advantages for saving for education expenses. It allows families to invest in a variety of investment options to grow their savings over time.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Kentucky state income tax up to the specified limits."}'::jsonb,
    'https://www.kysaves.com/',
    '{"state_income_tax": "5%", "child_tax_credit": "Follows federal guidelines; no additional state credit.", "dependent_care_credit": "Follows federal guidelines; no additional state credit.", "earned_income_credit": "Follows federal guidelines; no additional state credit.", "unique_deductions": ["Deduction for contributions to Kentucky''s 529 plan"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "KCHIP", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "No matching grants currently available", "scholarships": "The Kentucky Educational Excellence Scholarship (KEES) is available for students who meet academic requirements.", "other": "Kentucky offers the Work Ready Kentucky Scholarship for certain technical programs."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Kentucky, parents can take advantage of the Kentucky Education Savings Plan Trust to start saving for their child''s future education expenses. This 529 plan offers tax advantages and a variety of investment options to help your savings grow. Additionally, understanding state tax benefits and insurance rules can help you better plan for your family''s needs.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Consider opening a 529 plan as early as possible"], "action_items": ["Open a Kentucky 529 plan to start saving for education", "Review health insurance options and enroll your newborn", "Explore state scholarships and financial aid options"], "resources": ["https://www.kysaves.com/", "https://kidshealth.ky.gov/Pages/index.aspx", "https://kheaa.com/website/kheaa/kees?main=1"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Louisiana
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Louisiana',
    'LA',
    'START Saving Program',
    'The START Saving Program is Louisiana''s 529 college savings plan, designed to help families save for future education expenses. It offers tax advantages and flexible investment options to meet the needs of Louisiana residents.',
    '{"state_tax_deduction": "up to $2,400 per beneficiary per year", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Louisiana state income tax up to $2,400 per beneficiary per year, or $4,800 for married couples filing jointly."}'::jsonb,
    'https://www.startsaving.la.gov/',
    '{"state_income_tax": "1.85% to 4.25%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child", "dependent_care_credit": "Up to 50% of the federal credit", "earned_income_credit": "3.5% of the federal EITC", "unique_deductions": ["School tuition deduction", "Student loan interest deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "LaCHIP", "medicaid_expansion": true, "special_rules": "Louisiana offers automatic coverage for newborns for the first 30 days if the parent is already insured."}'::jsonb,
    '{"prepaid_plan": "START K12 Program", "matching_grants": "The START Saving Program offers an Earnings Enhancement Fund, which matches a percentage of contributions based on income level.", "scholarships": "Taylor Opportunity Program for Students (TOPS)", "other": "Louisiana offers the START K12 Program for saving towards private school tuition."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Louisiana, parents have access to the START Saving Program, a 529 plan that provides tax advantages and flexible savings options for future education expenses. Additionally, Louisiana offers several tax benefits and unique programs to support families, including the LaCHIP program for children''s health insurance and the Taylor Opportunity Program for Students (TOPS) for scholarships.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a START Saving Program account", "Review health insurance options for your newborn", "Explore eligibility for LaCHIP and Medicaid"], "resources": ["https://www.startsaving.la.gov/", "https://ldh.la.gov/index.cfm/subhome/1/n/331", "https://www.osfa.la.gov/tops/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Maine
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Maine',
    'ME',
    'NextGen 529',
    'The NextGen 529 plan is Maine''s tax-advantaged college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is managed by the Finance Authority of Maine (FAME) with investments managed by Merrill Lynch.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Maine does not offer a state tax deduction for contributions, the plan offers tax-free growth and withdrawals for qualified expenses."}'::jsonb,
    'https://www.nextgenforme.com/',
    '{"state_income_tax": "5.8% to 7.15%", "child_tax_credit": "Maine offers a state child tax credit that mirrors the federal credit.", "dependent_care_credit": "Maine provides a state credit for dependent care expenses, which is a percentage of the federal credit.", "earned_income_credit": "Maine offers a state earned income credit equal to 25% of the federal EITC.", "unique_deductions": ["Educational Opportunity Tax Credit", "Property Tax Fairness Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "MaineCare", "medicaid_expansion": true, "special_rules": "MaineCare provides comprehensive coverage for children and pregnant women with expanded income eligibility."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "NextGen 529 offers matching grants for eligible Maine residents, such as the Alfond Grant for newborns.", "scholarships": "The Alfond Scholarship Foundation provides a $500 grant to every Maine resident baby for future education expenses.", "other": "Maine offers the Harold Alfond College Challenge, which automatically provides a $500 grant to every baby born a Maine resident."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Maine, parents have access to resources like the NextGen 529 plan to start saving for education early. Understanding the state''s tax benefits and insurance rules can help parents make informed financial decisions. Maine''s unique programs, such as the Alfond Grant, provide additional support to ensure your child''s educational future is bright.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Apply for the Alfond Grant within one year of birth"], "action_items": ["Open a NextGen 529 account", "Review MaineCare eligibility for your newborn", "Apply for the Alfond Grant"], "resources": ["https://www.nextgenforme.com/", "https://www.maine.gov/dhhs/mainecare.shtml", "https://www.alfondscholarshipfoundation.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Maryland
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Maryland',
    'MD',
    'Maryland 529',
    'Maryland 529 offers two college savings options: the Maryland Prepaid College Trust and the Maryland College Investment Plan. These plans provide tax-advantaged ways to save for future education expenses.',
    '{"state_tax_deduction": "up to $2,500 per beneficiary per account", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions exceeding $2,500 can be carried forward for up to 10 years."}'::jsonb,
    'https://maryland529.com/',
    '{"state_income_tax": "2% to 5.75%", "child_tax_credit": "Maryland does not offer a state-level child tax credit, but federal credits apply.", "dependent_care_credit": "Maryland offers a state-level dependent care credit that is a percentage of the federal credit.", "earned_income_credit": "Maryland offers a refundable earned income credit that is a percentage of the federal EITC.", "unique_deductions": ["Child and Dependent Care Expenses", "529 Plan Contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Maryland Children''s Health Program (MCHP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s health plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Maryland Prepaid College Trust", "matching_grants": "The Save4College State Contribution Program offers matching contributions for eligible families.", "scholarships": "Various scholarships are available through Maryland Higher Education Commission.", "other": "Maryland offers a state contribution program for low to moderate-income families."}'::jsonb,
    '{"overview": "Planning for a new baby involves considering future education costs, healthcare, and tax benefits. Maryland offers a variety of programs to help parents save for college, including the Maryland 529 plans. These plans provide tax advantages and flexible savings options. Additionally, understanding state tax benefits and insurance rules can help ensure financial stability.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a Maryland 529 account", "Review health insurance options for your newborn", "Understand state and federal tax benefits"], "resources": ["https://maryland529.com/", "https://www.marylandhealthconnection.gov/", "https://www.mhec.state.md.us/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Massachusetts
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Massachusetts',
    'MA',
    'U.Fund College Investing Plan',
    'The U.Fund College Investing Plan is Massachusetts'' tax-advantaged 529 college savings plan. It offers a variety of investment options managed by Fidelity Investments, allowing families to save for future education expenses.',
    '{"state_tax_deduction": "up to $1,000 for single filers and $2,000 for joint filers", "deduction_amount_single": 1000, "deduction_amount_married": 2000, "earnings_tax_free": true, "notes": "Contributions are deductible from Massachusetts state income tax, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.fidelity.com/529-plans/massachusetts',
    '{"state_income_tax": "5%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "15% of the federal credit", "earned_income_credit": "30% of the federal credit", "unique_deductions": ["Deduction for 529 plan contributions", "Renters deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "MassHealth", "medicaid_expansion": true, "special_rules": "Massachusetts requires health insurance coverage for all residents, with penalties for non-compliance."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "The U.Fund offers occasional matching grant promotions for new accounts.", "scholarships": "The John and Abigail Adams Scholarship provides tuition waivers for Massachusetts public colleges.", "other": "The BabySteps Savings Plan offers a $50 seed deposit for newborns enrolled in the U.Fund."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is an exciting time, but it also comes with financial responsibilities. In Massachusetts, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. From the U.Fund College Investing Plan to state tax deductions, there are numerous ways to plan for your child''s future education expenses. Additionally, understanding state insurance rules and available credits can help you manage costs effectively.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a U.Fund 529 account", "Review and update health insurance coverage", "Explore eligibility for MassHealth and CHIP"], "resources": ["https://www.fidelity.com/529-plans/massachusetts", "https://www.mass.gov/topics/masshealth", "https://www.mass.gov/service-details/child-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();
