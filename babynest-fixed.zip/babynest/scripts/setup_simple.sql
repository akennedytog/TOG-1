-- BabyNest Simple Setup
-- Run this in Supabase SQL Editor

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  state VARCHAR(2),
  due_date DATE,
  income_bracket VARCHAR(50),
  family_size INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- States table
CREATE TABLE IF NOT EXISTS states (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  abbreviation VARCHAR(2) NOT NULL UNIQUE,
  plan_529_name TEXT,
  plan_529_description TEXT,
  plan_529_tax_benefits JSONB,
  plan_529_link TEXT,
  tax_benefits JSONB,
  insurance_rules JSONB,
  unique_programs JSONB,
  content JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  due_date DATE,
  category VARCHAR(50) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  priority VARCHAR(10) DEFAULT 'medium',
  state_specific BOOLEAN DEFAULT FALSE,
  state VARCHAR(2),
  estimated_time INTEGER,
  completion_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversations table
CREATE TABLE IF NOT EXISTS conversations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  messages JSONB NOT NULL DEFAULT '[]',
  summary TEXT,
  category VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Waitlist table
CREATE TABLE IF NOT EXISTS waitlist (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  state VARCHAR(2),
  due_date DATE,
  source VARCHAR(50),
  notes TEXT,
  contacted BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE states ENABLE ROW LEVEL SECURITY;
ALTER TABLE waitlist ENABLE ROW LEVEL SECURITY;

-- RLS Policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can CRUD own tasks" ON tasks;
CREATE POLICY "Users can CRUD own tasks" ON tasks FOR ALL USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can CRUD own conversations" ON conversations;
CREATE POLICY "Users can CRUD own conversations" ON conversations FOR ALL USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "States are public" ON states;
CREATE POLICY "States are public" ON states FOR SELECT TO PUBLIC USING (true);

DROP POLICY IF EXISTS "Anyone can join waitlist" ON waitlist;
CREATE POLICY "Anyone can join waitlist" ON waitlist FOR INSERT TO PUBLIC WITH CHECK (true);

-- Functions
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_tasks_updated_at ON tasks;
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_states_updated_at ON states;
CREATE TRIGGER update_states_updated_at BEFORE UPDATE ON states FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_conversations_updated_at ON conversations;
CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON conversations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert sample states
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, content) VALUES
('Florida', 'FL', 'Sage Scholars Florida 529 Savings Plan', 'Florida direct-sold 529 plan with low fees', '{"no_state_income_tax": true}'::jsonb, '{"overview": "Florida has no state income tax"}'::jsonb),
('California', 'CA', 'ScholarShare 529', 'California direct-sold 529 plan', '{"earnings_tax_free": true}'::jsonb, '{"overview": "California offers CalKIDS"}'::jsonb),
('Texas', 'TX', 'Texas College Savings Plan', 'Texas 529 plan options', '{"no_state_income_tax": true}'::jsonb, '{"overview": "Texas has no state income tax"}'::jsonb),
('New York', 'NY', 'NY 529 College Savings Program', 'NY 529 plan with tax deduction', '{"deduction": 10000}'::jsonb, '{"overview": "NY offers up to $10,000 deduction"}'::jsonb),
('Illinois', 'IL', 'Bright Start 529', 'Illinois 529 plan', '{"deduction": 20000}'::jsonb, '{"overview": "IL offers up to $20,000 deduction"}'::jsonb)
ON CONFLICT (abbreviation) DO NOTHING;

-- Sample tasks
INSERT INTO tasks (title, description, category, priority, state_specific, state, estimated_time) VALUES
('Add baby to health insurance', 'Contact insurance within 60 days of birth', 'insurance', 'urgent', true, 'FL', 30),
('Set up 529 plan', 'Open 529 savings account', '529', 'high', false, NULL, 45),
('Apply for SSN', 'Get baby Social Security number', 'general', 'high', false, NULL, 30)
ON CONFLICT DO NOTHING;

SELECT 'Database setup complete!' as status;
