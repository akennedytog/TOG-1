# BabyNest State Content Generator

This script generates comprehensive financial and insurance content for all 50 states using AI.

## Setup

```bash
# Install dependencies
pip install openai

# Set your OpenAI API key
export OPENAI_API_KEY='your-key-here'
```

## Usage

### Generate All 50 States

```bash
python scripts/generate_state_content.py
```

This will:
1. Generate content for all 50 states using GPT-4
2. Export to `state_content.json` (JSON format)
3. Export to `state_content_inserts.sql` (SQL format)

### Generate Single State

```bash
python scripts/generate_state_content.py --state "Florida"
```

### Generate Tasks for a State

```bash
python scripts/generate_state_content.py --tasks FL
```

### Options

- `--model gpt-4` - Use specific model (default: gpt-4)
- `--delay 2.0` - Delay between API calls in seconds (default: 1.0)
- `--export json` - Export format: json, sql, or both (default: both)

## Output

### JSON Format
`state_content.json` contains an array of state objects with:
- 529 plan details
- Tax benefits
- Insurance rules
- Unique programs
- Content (overview, deadlines, resources)

### SQL Format
`state_content_inserts.sql` contains INSERT statements ready to run in Supabase.

## Cost Estimate

- ~50 API calls (one per state)
- Each call ~2000 tokens
- Cost: ~$3-5 using GPT-4

## Review Process

The AI-generated content should be reviewed by a legal/financial professional before deployment. The script includes a disclaimer and placeholder handling for uncertain information.

## Integration

After generating:

1. Review `state_content.json` for accuracy
2. Run SQL in Supabase SQL Editor
3. Or import JSON programmatically

```javascript
// Import JSON to Supabase
const fs = require('fs');
const content = JSON.parse(fs.readFileSync('state_content.json'));

for (const state of content) {
  await supabase.from('states').insert(state);
}
```