-- BabyNest State Content - Batch 3 (States 19-27)
-- States: MI, MN, MS, MO, MT, NE, NV, NH, NJ
-- Run this in Supabase SQL Editor

-- Michigan
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Michigan',
    'MI',
    'Michigan Education Savings Program (MESP)',
    'The Michigan Education Savings Program (MESP) is a tax-advantaged 529 college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Michigan state income tax up to the specified limits."}'::jsonb,
    'https://www.misaves.com/',
    '{"state_income_tax": "4.25%", "child_tax_credit": "No additional state child tax credit; follows federal guidelines.", "dependent_care_credit": "Michigan offers a state credit based on a percentage of the federal credit.", "earned_income_credit": "Michigan offers a state EITC equal to 6% of the federal EITC.", "unique_deductions": ["Tuition and fees deduction for higher education"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "MIChild", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Michigan Education Trust (MET)", "matching_grants": "No state matching grants available.", "scholarships": "The Michigan Competitive Scholarship is available for students who meet certain criteria.", "other": "MI Bright Future program offers career exploration resources."}'::jsonb,
    '{"overview": "Welcoming a new baby is a joyous occasion, but it also comes with financial responsibilities. In Michigan, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. From the Michigan Education Savings Program to state tax deductions, there are numerous ways to plan for your child''s future education. Additionally, Michigan offers health insurance programs like MIChild to ensure your newborn is covered.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth.", "Contribute to MESP by December 31st for tax benefits."], "action_items": ["Open a Michigan Education Savings Program account.", "Review and update health insurance coverage for your newborn.", "Explore Michigan Education Trust for prepaid tuition options."], "resources": ["https://www.misaves.com/", "https://www.michigan.gov/treasury/0,4679,7-121-1753_6096-213665--,00.html", "https://www.michigan.gov/mdhhs/assistance-programs/healthcare/childrens-health-insurance-program"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Minnesota
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Minnesota',
    'MN',
    'Minnesota College Savings Plan',
    'The Minnesota College Savings Plan is a tax-advantaged 529 savings plan designed to help families save for education expenses. Contributions grow tax-deferred, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $1,500 for single filers and $3,000 for joint filers", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Minnesota state income tax, subject to limits."}'::jsonb,
    'https://www.mnsaves.org',
    '{"state_income_tax": "5.35% - 9.85%", "child_tax_credit": "Minnesota offers a refundable child tax credit for eligible families.", "dependent_care_credit": "Minnesota provides a dependent care credit for qualifying expenses.", "earned_income_credit": "Minnesota offers a state earned income credit, which is a percentage of the federal EITC.", "unique_deductions": ["Education Savings Account contributions", "Student Loan Interest Deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "MinnesotaCare", "medicaid_expansion": true, "special_rules": "MinnesotaCare offers low-cost health coverage for children and families."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "The Minnesota College Savings Plan offers matching grants for low- and moderate-income families.", "scholarships": "The plan offers scholarships for eligible participants.", "other": "Minnesota also provides tax credits for educational expenses."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Minnesota, parents can take advantage of various financial programs and tax benefits to help ease the burden of saving for their child''s future education. The Minnesota College Savings Plan offers a flexible and tax-advantaged way to save for college expenses, while state tax deductions and credits can provide additional financial relief. Understanding these options can help parents plan effectively for their child''s future.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File for state tax deductions by April 15"], "action_items": ["Open a Minnesota College Savings Plan account", "Review eligibility for MinnesotaCare", "Apply for child tax credits"], "resources": ["https://www.mnsaves.org", "https://mn.gov/dhs/people-we-serve/children-and-families/health-care/health-care-programs/programs-and-services/minnesotacare.jsp", "https://www.revenue.state.mn.us/individuals"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Mississippi
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Mississippi',
    'MS',
    'Mississippi Affordable College Savings (MACS) Program',
    'The Mississippi Affordable College Savings (MACS) Program is designed to help families save for future college expenses. It offers tax advantages and flexible investment options to make saving for higher education more accessible.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions to the MACS plan are deductible from Mississippi state income tax, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.treasurerlynnfitch.ms.gov/college-savings-macs',
    '{"state_income_tax": "3% to 5%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "Follows federal guidelines; no additional state credit", "earned_income_credit": "Follows federal guidelines; no additional state credit", "unique_deductions": ["Contributions to MACS", "Interest on student loans"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Mississippi CHIP", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Mississippi Prepaid Affordable College Tuition (MPACT) Program", "matching_grants": "No state matching grants available", "scholarships": "Mississippi Tuition Assistance Grant (MTAG) and Mississippi Eminent Scholars Grant (MESG)", "other": "The state offers various scholarships and financial aid programs for residents."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is a joyous occasion, and planning for their future is an important step. In Mississippi, parents have access to a variety of financial planning tools and resources to help secure their child''s education and well-being. From the Mississippi Affordable College Savings (MACS) Program to state tax benefits, there are several ways to prepare financially for your child''s future. Additionally, understanding insurance rules and available state programs can ensure your child is well-protected and supported.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Consider opening a 529 plan as early as possible"], "action_items": ["Open a MACS 529 plan", "Review health insurance options for your newborn", "Explore state scholarships and grants"], "resources": ["https://www.treasurerlynnfitch.ms.gov/college-savings-macs", "https://medicaid.ms.gov/chip", "https://riseupms.com/financial-aid/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Missouri
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Missouri',
    'MO',
    'MOST - Missouri''s 529 Education Plan',
    'MOST 529 is Missouri''s state-sponsored college savings plan, offering tax advantages for residents saving for education expenses. Contributions grow tax-deferred, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $8,000 per taxpayer", "deduction_amount_single": 8000, "deduction_amount_married": 16000, "earnings_tax_free": true, "notes": "Contributions are deductible from Missouri state income tax, up to $8,000 per taxpayer or $16,000 for married couples filing jointly."}'::jsonb,
    'https://www.missourimost.org',
    '{"state_income_tax": "0% to 5.4%", "child_tax_credit": "Follows federal guidelines with no additional state credit", "dependent_care_credit": "20% to 35% of eligible expenses, follows federal guidelines", "earned_income_credit": "10% of the federal EITC", "unique_deductions": ["Contributions to MOST 529 Plan", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "31 days of automatic coverage", "chip_program": "MO HealthNet for Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 31 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "MOST 529 offers periodic promotions and matching grants for new accounts.", "scholarships": "MOST 529 periodically offers scholarships and contests for account holders.", "other": "Missouri offers a First Steps program for early intervention services for children with developmental delays."}'::jsonb,
    '{"overview": "Planning for a new baby in Missouri involves understanding the financial benefits and programs available to support your child''s future. Missouri offers a robust 529 college savings plan with significant tax advantages, making it easier for parents to save for education expenses. Additionally, the state provides various tax credits and deductions that can benefit families. Health insurance rules ensure newborns are covered, and programs like MO HealthNet for Kids offer additional support for eligible families.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to MOST 529 by December 31 for tax benefits"], "action_items": ["Open a MOST 529 account", "Review health insurance options for your newborn", "Check eligibility for MO HealthNet for Kids"], "resources": ["https://www.missourimost.org", "https://mydss.mo.gov/healthcare/mo-healthnet-for-kids", "https://dor.mo.gov"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Montana
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Montana',
    'MT',
    'Montana Family Education Savings Program',
    'The Montana Family Education Savings Program offers a tax-advantaged way to save for education expenses. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "amount", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Montana state income tax, subject to limits."}'::jsonb,
    'https://www.mfesp.com/',
    '{"state_income_tax": "1% - 6.75%", "child_tax_credit": "Follows federal guidelines, no additional state credit", "dependent_care_credit": "Follows federal guidelines, no additional state credit", "earned_income_credit": "3% of the federal EITC", "unique_deductions": ["529 plan contributions", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "31 days of automatic coverage", "chip_program": "Healthy Montana Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 31 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None available", "scholarships": "Some scholarships available through the Montana University System", "other": "Montana offers a tax deduction for contributions to any state''s 529 plan."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Montana, parents can take advantage of various programs and tax benefits to ease the financial burden. The Montana Family Education Savings Program allows parents to save for their child''s future education expenses with tax advantages. Additionally, understanding the state''s tax benefits and insurance rules can help parents plan effectively.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "File state taxes by April 15 to claim deductions"], "action_items": ["Open a 529 plan account", "Review health insurance coverage options", "Explore eligibility for state tax credits"], "resources": ["https://www.mfesp.com/", "https://dphhs.mt.gov/hmk", "https://revenue.mt.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Nebraska
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Nebraska',
    'NE',
    'NEST 529 College Savings Plan',
    'The NEST 529 College Savings Plan offers a flexible and tax-advantaged way to save for future education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Nebraska state income tax, up to the specified limits."}'::jsonb,
    'https://www.nest529.com',
    '{"state_income_tax": "2.46% - 6.84%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Non-refundable credit based on federal credit, up to $1,050 for one child.", "earned_income_credit": "10% of the federal EITC.", "unique_deductions": ["529 plan contributions", "Charitable contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Kids Connection", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "Occasional promotions for matching contributions for new accounts.", "scholarships": "NEST 529 offers periodic scholarship opportunities for account holders.", "other": "NEST 529 offers periodic promotions and incentives for new account holders."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in Nebraska. Understanding the financial landscape, including tax benefits and savings plans, can help you prepare for your child''s education and healthcare needs. Nebraska offers the NEST 529 College Savings Plan, which provides tax advantages and flexible investment options to help you save for future educational expenses. Additionally, understanding state tax benefits and insurance rules will ensure you maximize your resources.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a NEST 529 College Savings Plan account", "Review and adjust your health insurance coverage", "Explore state tax benefits and credits"], "resources": ["https://www.nest529.com", "https://dhhs.ne.gov/Pages/Medicaid-and-Long-Term-Care.aspx", "https://revenue.nebraska.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Nevada
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Nevada',
    'NV',
    'Nevada College Savings Plans',
    'Nevada offers several 529 plans, including the SSGA Upromise 529 Plan, the Vanguard 529 College Savings Plan, and the USAA 529 College Savings Plan. These plans provide a variety of investment options and are designed to help families save for future college expenses.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Nevada does not offer a state tax deduction, earnings grow tax-free and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://nv529.org/',
    '{"state_income_tax": "none", "child_tax_credit": "Eligible for federal child tax credit up to $2,000 per qualifying child.", "dependent_care_credit": "Eligible for federal credit up to 35% of qualifying expenses, depending on income.", "earned_income_credit": "Eligible for federal EITC, which varies based on income and number of children.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Nevada Check Up", "medicaid_expansion": true, "special_rules": "Parents must apply for Medicaid or Nevada Check Up within 30 days of birth to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "Nevada does not currently offer matching grants for 529 contributions.", "scholarships": "The Millennium Scholarship provides up to $10,000 for eligible Nevada high school graduates attending in-state colleges.", "other": "Nevada offers the Silver State Matching Grant Program for eligible families with low to moderate income."}'::jsonb,
    '{"overview": "Planning for a new baby in Nevada involves understanding the financial tools and benefits available to you. While Nevada does not have a state income tax, it offers several 529 college savings plans to help you save for your child''s education. Additionally, programs like Nevada Check Up provide health coverage for children from low-income families. It''s important to be aware of enrollment deadlines for health insurance and to take advantage of federal tax credits.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Apply for Nevada Check Up or Medicaid as soon as possible after birth."], "action_items": ["Open a Nevada 529 College Savings Plan to start saving for education.", "Ensure your newborn is added to your health insurance plan within 30 days.", "Explore eligibility for Nevada Check Up if applicable."], "resources": ["Nevada College Savings Plans: https://nv529.org/", "Nevada Check Up: https://dhcfp.nv.gov/Pgms/CPT/NevadaCheckUp/", "Federal Child Tax Credit: https://www.irs.gov/credits-deductions/individuals/child-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- New Hampshire
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'New Hampshire',
    'NH',
    'New Hampshire''s UNIQUE College Investing Plan',
    'The UNIQUE College Investing Plan is New Hampshire''s 529 college savings plan, offering tax-advantaged savings for education expenses. Managed by Fidelity Investments, it provides a variety of investment options to help families save for future education costs.',
    '{"state_tax_deduction": false, "deduction_amount_single": 0, "deduction_amount_married": 0, "earnings_tax_free": true, "notes": "While New Hampshire does not offer a state tax deduction, earnings grow tax-free, and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.fidelity.com/529-plans/new-hampshire',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines; no additional state credit.", "dependent_care_credit": "No additional state credit; follows federal guidelines.", "earned_income_credit": "No additional state credit; follows federal guidelines.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "New Hampshire Healthy Kids", "medicaid_expansion": true, "special_rules": "Parents must apply for Medicaid or CHIP within 30 days to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "New Hampshire does not offer matching grants for 529 contributions.", "scholarships": "The UNIQUE Annual Scholarship Program provides scholarships to New Hampshire residents attending college in the state.", "other": "New Hampshire offers the UNIQUE Endowment Scholarship, funded by the New Hampshire Higher Education Assistance Foundation."}'::jsonb,
    '{"overview": "Planning for a new baby involves considering future education expenses, healthcare, and tax benefits. In New Hampshire, parents can take advantage of the UNIQUE College Investing Plan, a 529 savings plan that offers tax-free growth and withdrawals for qualified education expenses. While the state does not impose an income tax, understanding federal tax credits and deductions can help maximize savings. Additionally, ensuring health coverage for your newborn through programs like Medicaid and CHIP is crucial.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Apply for Medicaid or CHIP within 30 days if eligible."], "action_items": ["Open a UNIQUE College Investing Plan account to start saving for education.", "Review federal tax credits and deductions applicable to families.", "Ensure newborn is enrolled in a health insurance plan within the deadline."], "resources": ["https://www.fidelity.com/529-plans/new-hampshire", "https://www.nh.gov/insurance/consumers/health.htm", "https://www.dhhs.nh.gov/programs-services/medicaid/medicaid-children"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- New Jersey
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'New Jersey',
    'NJ',
    'NJBEST 529 College Savings Plan',
    'The NJBEST 529 College Savings Plan is New Jersey''s tax-advantaged college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While contributions are not tax-deductible, earnings grow tax-free and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.njbest.com',
    '{"state_income_tax": "1.4% to 10.75%", "child_tax_credit": "New Jersey offers a state-level child tax credit for eligible families, which is based on income and the number of qualifying children.", "dependent_care_credit": "New Jersey provides a state-level dependent care credit that mirrors the federal credit, with specific income limits and percentages.", "earned_income_credit": "New Jersey offers a state Earned Income Tax Credit (EITC) that is a percentage of the federal EITC, providing additional support to low- and moderate-income families.", "unique_deductions": ["Property tax deduction", "Medical expenses deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "NJ FamilyCare", "medicaid_expansion": true, "special_rules": "New Jersey requires that newborns be added to a health insurance plan within 60 days of birth to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "New Jersey offers a one-time scholarship through the NJBEST program for students attending a New Jersey college or university.", "scholarships": "NJBEST Scholarship provides up to $3,000 for students attending in-state schools.", "other": "New Jersey provides various state financial aid programs for higher education, including the Tuition Aid Grant (TAG) program."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In New Jersey, parents can take advantage of various state programs and tax benefits to ease the financial burden of raising a child. From the NJBEST 529 College Savings Plan to state tax credits, there are numerous resources available to help parents plan for their child''s future.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth", "Consider opening a 529 plan as early as possible to maximize growth"], "action_items": ["Research and enroll in the NJBEST 529 College Savings Plan", "Review eligibility for state tax credits and deductions", "Add newborn to health insurance within the required timeframe"], "resources": ["https://www.njbest.com", "https://www.state.nj.us/treasury/taxation/", "https://www.njfamilycare.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();
