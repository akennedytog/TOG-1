#!/usr/bin/env python3
"""
BabyNest State Content Generator
Generates comprehensive financial/insurance content for all 50 states using AI
"""

import json
import os
import time
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from datetime import datetime

# You can use OpenAI or Anthropic here
# For this script, we'll use OpenAI

try:
    from openai import OpenAI
    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False
    print("OpenAI not installed. Install with: pip install openai")


@dataclass
class StateContent:
    """Represents a state's content for the database"""
    name: str
    abbreviation: str
    plan_529_name: str
    plan_529_description: str
    plan_529_tax_benefits: Dict
    plan_529_link: str
    tax_benefits: Dict
    insurance_rules: Dict
    unique_programs: Dict
    content: Dict
    
    def to_sql(self) -> str:
        """Convert to SQL INSERT statement"""
        return f"""
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    '{self.name.replace("'", "''")}',
    '{self.abbreviation}',
    '{self.plan_529_name.replace("'", "''")}',
    '{self.plan_529_description.replace("'", "''")}',
    '{json.dumps(self.plan_529_tax_benefits).replace("'", "''")}'::jsonb,
    '{self.plan_529_link}',
    '{json.dumps(self.tax_benefits).replace("'", "''")}'::jsonb,
    '{json.dumps(self.insurance_rules).replace("'", "''")}'::jsonb,
    '{json.dumps(self.unique_programs).replace("'", "''")}'::jsonb,
    '{json.dumps(self.content).replace("'", "''")}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();
"""


class StateContentGenerator:
    """Generates content for all 50 states"""
    
    def __init__(self, model: str = "gpt-4"):
        self.model = model
        self.states = [
            ("Alabama", "AL"), ("Alaska", "AK"), ("Arizona", "AZ"), ("Arkansas", "AR"),
            ("California", "CA"), ("Colorado", "CO"), ("Connecticut", "CT"), ("Delaware", "DE"),
            ("Florida", "FL"), ("Georgia", "GA"), ("Hawaii", "HI"), ("Idaho", "ID"),
            ("Illinois", "IL"), ("Indiana", "IN"), ("Iowa", "IA"), ("Kansas", "KS"),
            ("Kentucky", "KY"), ("Louisiana", "LA"), ("Maine", "ME"), ("Maryland", "MD"),
            ("Massachusetts", "MA"), ("Michigan", "MI"), ("Minnesota", "MN"), ("Mississippi", "MS"),
            ("Missouri", "MO"), ("Montana", "MT"), ("Nebraska", "NE"), ("Nevada", "NV"),
            ("New Hampshire", "NH"), ("New Jersey", "NJ"), ("New Mexico", "NM"), ("New York", "NY"),
            ("North Carolina", "NC"), ("North Dakota", "ND"), ("Ohio", "OH"), ("Oklahoma", "OK"),
            ("Oregon", "OR"), ("Pennsylvania", "PA"), ("Rhode Island", "RI"), ("South Carolina", "SC"),
            ("South Dakota", "SD"), ("Tennessee", "TN"), ("Texas", "TX"), ("Utah", "UT"),
            ("Vermont", "VT"), ("Virginia", "VA"), ("Washington", "WA"), ("West Virginia", "WV"),
            ("Wisconsin", "WI"), ("Wyoming", "WY")
        ]
        
        self.generated_content: List[StateContent] = []
        
    def generate_state_content(self, state_name: str, abbreviation: str) -> StateContent:
        """Generate content for a single state using AI"""
        
        prompt = f"""Generate comprehensive baby financial planning content for {state_name} ({abbreviation}).

Return a JSON object with this exact structure:
{{
  "plan_529_name": "Exact official name of the state's 529 plan",
  "plan_529_description": "2-3 sentence description of the plan",
  "plan_529_link": "Official website URL",
  "plan_529_tax_benefits": {{
    "state_tax_deduction": "amount or false",
    "deduction_amount_single": 5000,
    "deduction_amount_married": 10000,
    "earnings_tax_free": True,
    "notes": "any special rules"
  }},
  "tax_benefits": {{
    "state_income_tax": "rate or 'none'",
    "child_tax_credit": "details",
    "dependent_care_credit": "details",
    "earned_income_credit": "details",
    "unique_deductions": ["list of deductions"]
  }},
  "insurance_rules": {{
    "newborn_enrollment_deadline": "30, 60, or 90 days",
    "automatic_coverage_period": "days of automatic coverage",
    "chip_program": "name of state CHIP program",
    "medicaid_expansion": True,
    "special_rules": "any unique rules"
  }},
  "unique_programs": {{
    "prepaid_plan": "name if available",
    "matching_grants": "details if available",
    "scholarships": "details",
    "other": "any other unique benefits"
  }},
  "content": {{
    "overview": "2-3 paragraph overview for parents",
    "key_deadlines": ["list of important deadlines"],
    "action_items": ["specific actions for parents"],
    "resources": ["helpful links and resources"]
  }}
}}

Be accurate and specific. If you're unsure about a detail, indicate it clearly."""

        try:
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that generates accurate financial information for new parents. Always return valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            
            # Extract JSON from response
            # Handle cases where AI adds markdown code blocks
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]
            
            data = json.loads(content.strip())
            
            return StateContent(
                name=state_name,
                abbreviation=abbreviation,
                plan_529_name=data.get("plan_529_name", ""),
                plan_529_description=data.get("plan_529_description", ""),
                plan_529_tax_benefits=data.get("plan_529_tax_benefits", {}),
                plan_529_link=data.get("plan_529_link", ""),
                tax_benefits=data.get("tax_benefits", {}),
                insurance_rules=data.get("insurance_rules", {}),
                unique_programs=data.get("unique_programs", {}),
                content=data.get("content", {})
            )
            
        except Exception as e:
            print(f"Error generating content for {state_name}: {e}")
            # Return placeholder content
            return StateContent(
                name=state_name,
                abbreviation=abbreviation,
                plan_529_name=f"{state_name} 529 Plan",
                plan_529_description=f"529 college savings plan for {state_name} residents.",
                plan_529_tax_benefits={},
                plan_529_link="",
                tax_benefits={},
                insurance_rules={},
                unique_programs={},
                content={}
            )
    
    def generate_all_states(self, delay: float = 1.0) -> List[StateContent]:
        """Generate content for all 50 states"""
        print(f"Generating content for {len(self.states)} states...")
        print(f"Using model: {self.model}")
        print("-" * 50)
        
        for i, (state_name, abbreviation) in enumerate(self.states, 1):
            print(f"[{i}/{len(self.states)}] Generating content for {state_name}...", end=" ")
            
            content = self.generate_state_content(state_name, abbreviation)
            self.generated_content.append(content)
            
            print(f"✓")
            
            # Delay to avoid rate limits
            if i < len(self.states):
                time.sleep(delay)
        
        print("-" * 50)
        print(f"Generated content for {len(self.generated_content)} states")
        return self.generated_content
    
    def export_to_json(self, filename: str = "state_content.json"):
        """Export all content to JSON file"""
        data = [
            {
                "name": c.name,
                "abbreviation": c.abbreviation,
                "plan_529_name": c.plan_529_name,
                "plan_529_description": c.plan_529_description,
                "plan_529_tax_benefits": c.plan_529_tax_benefits,
                "plan_529_link": c.plan_529_link,
                "tax_benefits": c.tax_benefits,
                "insurance_rules": c.insurance_rules,
                "unique_programs": c.unique_programs,
                "content": c.content
            }
            for c in self.generated_content
        ]
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"Exported to {filename}")
    
    def export_to_sql(self, filename: str = "state_content_inserts.sql"):
        """Export all content to SQL file"""
        with open(filename, 'w') as f:
            f.write("-- BabyNest State Content\n")
            f.write(f"-- Generated: {datetime.now().isoformat()}\n")
            f.write("-- Run this in Supabase SQL Editor\n\n")
            
            for content in self.generated_content:
                f.write(content.to_sql())
                f.write("\n")
        
        print(f"Exported to {filename}")
    
    def generate_sample_tasks(self, state_abbr: str) -> List[Dict]:
        """Generate sample tasks for a state"""
        
        state_content = next((c for c in self.generated_content if c.abbreviation == state_abbr), None)
        
        if not state_content:
            print(f"No content found for {state_abbr}")
            return []
        
        prompt = f"""Generate 8-10 specific tasks for new parents in {state_content.name} based on this information:

529 Plan: {state_content.plan_529_name}
Tax Benefits: {json.dumps(state_content.tax_benefits)}
Insurance Rules: {json.dumps(state_content.insurance_rules)}
Unique Programs: {json.dumps(state_content.unique_programs)}

Return a JSON array of tasks with this structure:
[
  {{
    "title": "Task title",
    "description": "Detailed description",
    "category": "insurance|529|tax|legal|general",
    "priority": "urgent|high|medium|low",
    "due_date_offset": "relative to birth",
    "estimated_time": 30
  }}
]

Focus on state-specific tasks that are time-sensitive and high-impact."""

        try:
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You generate actionable task lists for new parents."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.5,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]
            
            tasks = json.loads(content.strip())
            return tasks
            
        except Exception as e:
            print(f"Error generating tasks: {e}")
            return []


def main():
    """Main execution"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Generate BabyNest state content")
    parser.add_argument("--model", default="gpt-4", help="AI model to use")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between API calls (seconds)")
    parser.add_argument("--state", help="Generate for single state only")
    parser.add_argument("--export", choices=["json", "sql", "both"], default="both", help="Export format")
    parser.add_argument("--tasks", help="Generate tasks for specific state (provide abbreviation)")
    
    args = parser.parse_args()
    
    if not HAS_OPENAI:
        print("ERROR: OpenAI not installed. Run: pip install openai")
        print("Then set OPENAI_API_KEY environment variable")
        return
    
    if not os.getenv('OPENAI_API_KEY'):
        print("ERROR: OPENAI_API_KEY not set")
        print("Set it with: export OPENAI_API_KEY='your-key'")
        return
    
    generator = StateContentGenerator(model=args.model)
    
    # Generate tasks for specific state
    if args.tasks:
        print(f"Generating tasks for {args.tasks}...")
        tasks = generator.generate_sample_tasks(args.tasks.upper())
        filename = f"tasks_{args.tasks.upper()}.json"
        with open(filename, 'w') as f:
            json.dump(tasks, f, indent=2)
        print(f"Exported to {filename}")
        return
    
    # Generate content for single state
    if args.state:
        state_name = args.state
        abbreviation = next((abbr for name, abbr in generator.states if name == state_name), None)
        
        if not abbreviation:
            print(f"State '{state_name}' not found")
            return
        
        print(f"Generating content for {state_name}...")
        content = generator.generate_state_content(state_name, abbreviation)
        
        print(f"\n{state_name} ({abbreviation}):")
        print(json.dumps(asdict(content), indent=2))
        return
    
    # Generate all states
    generator.generate_all_states(delay=args.delay)
    
    # Export
    if args.export in ["json", "both"]:
        generator.export_to_json()
    
    if args.export in ["sql", "both"]:
        generator.export_to_sql()
    
    print("\nDone! 🎉")
    print("\nNext steps:")
    print("1. Review the generated content")
    print("2. Run the SQL file in Supabase SQL Editor")
    print("3. Or import the JSON file programmatically")


if __name__ == "__main__":
    main()