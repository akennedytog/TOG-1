#!/usr/bin/env python3
"""
Generate SQL content for 45 US states for BabyNest
"""

import json
import os
from datetime import datetime
from openai import OpenAI

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

# The 45 states to generate (excluding FL, CA, TX, NY, IL)
STATES = [
    ("Alabama", "AL"), ("Alaska", "AK"), ("Arizona", "AZ"), ("Arkansas", "AR"),
    ("Colorado", "CO"), ("Connecticut", "CT"), ("Delaware", "DE"),
    ("Georgia", "GA"), ("Hawaii", "HI"), ("Idaho", "ID"),
    ("Indiana", "IN"), ("Iowa", "IA"), ("Kansas", "KS"), ("Kentucky", "KY"),
    ("Louisiana", "LA"), ("Maine", "ME"), ("Maryland", "MD"), ("Massachusetts", "MA"),
    ("Michigan", "MI"), ("Minnesota", "MN"), ("Mississippi", "MS"), ("Missouri", "MO"),
    ("Montana", "MT"), ("Nebraska", "NE"), ("Nevada", "NV"), ("New Hampshire", "NH"),
    ("New Jersey", "NJ"), ("New Mexico", "NM"), ("North Carolina", "NC"),
    ("North Dakota", "ND"), ("Ohio", "OH"), ("Oklahoma", "OK"), ("Oregon", "OR"),
    ("Pennsylvania", "PA"), ("Rhode Island", "RI"), ("South Carolina", "SC"),
    ("South Dakota", "SD"), ("Tennessee", "TN"), ("Utah", "UT"), ("Vermont", "VT"),
    ("Virginia", "VA"), ("Washington", "WA"), ("West Virginia", "WV"),
    ("Wisconsin", "WI"), ("Wyoming", "WY")
]

PROMPT_TEMPLATE = """Generate comprehensive baby financial planning content for {state_name} ({abbreviation}).

Return a JSON object with this exact structure:
{{
  "plan_529_name": "Exact official name of the state's 529 plan",
  "plan_529_description": "2-3 sentence description of the plan",
  "plan_529_link": "Official website URL",
  "plan_529_tax_benefits": {{
    "state_tax_deduction": "amount or false",
    "deduction_amount_single": 5000,
    "deduction_amount_married": 10000,
    "earnings_tax_free": true,
    "notes": "any special rules"
  }},
  "tax_benefits": {{
    "state_income_tax": "rate or 'none'",
    "child_tax_credit": "details",
    "dependent_care_credit": "details",
    "earned_income_credit": "details",
    "unique_deductions": ["list of deductions"]
  }},
  "insurance_rules": {{
    "newborn_enrollment_deadline": "30, 60, or 90 days",
    "automatic_coverage_period": "days of automatic coverage",
    "chip_program": "name of state CHIP program",
    "medicaid_expansion": true,
    "special_rules": "any unique rules"
  }},
  "unique_programs": {{
    "prepaid_plan": "name if available",
    "matching_grants": "details if available",
    "scholarships": "details",
    "other": "any other unique benefits"
  }},
  "content": {{
    "overview": "2-3 paragraph overview for parents",
    "key_deadlines": ["list of important deadlines"],
    "action_items": ["specific actions for parents"],
    "resources": ["helpful links and resources"]
  }}
}}

Be accurate and specific. Use real 529 plan names and actual state programs."""

def generate_state_content(state_name, abbreviation):
    """Generate content for a single state using AI"""
    
    prompt = PROMPT_TEMPLATE.format(state_name=state_name, abbreviation=abbreviation)

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that generates accurate financial information for new parents. Always return valid JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=2000
        )
        
        content = response.choices[0].message.content
        
        # Extract JSON from response
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]
        
        data = json.loads(content.strip())
        
        return {
            "name": state_name,
            "abbreviation": abbreviation,
            "plan_529_name": data.get("plan_529_name", ""),
            "plan_529_description": data.get("plan_529_description", ""),
            "plan_529_link": data.get("plan_529_link", ""),
            "plan_529_tax_benefits": data.get("plan_529_tax_benefits", {}),
            "tax_benefits": data.get("tax_benefits", {}),
            "insurance_rules": data.get("insurance_rules", {}),
            "unique_programs": data.get("unique_programs", {}),
            "content": data.get("content", {})
        }
        
    except Exception as e:
        print(f"  Error: {e}")
        return None

def to_sql_insert(data):
    """Convert state data to SQL INSERT statement"""
    return f"""-- {data['name']}
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    '{data['name'].replace("'", "''")}',
    '{data['abbreviation']}',
    '{data['plan_529_name'].replace("'", "''")}',
    '{data['plan_529_description'].replace("'", "''")}',
    '{json.dumps(data['plan_529_tax_benefits']).replace("'", "''")}'::jsonb,
    '{data['plan_529_link']}',
    '{json.dumps(data['tax_benefits']).replace("'", "''")}'::jsonb,
    '{json.dumps(data['insurance_rules']).replace("'", "''")}'::jsonb,
    '{json.dumps(data['unique_programs']).replace("'", "''")}'::jsonb,
    '{json.dumps(data['content']).replace("'", "''")}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

"""

def main():
    output_file = "/Users/aleckennedy/.openclaw/workspace/babynest/scripts/all_45_states.sql"
    
    # Write header
    with open(output_file, 'w') as f:
        f.write("-- BabyNest State Content - 45 States\n")
        f.write(f"-- Generated: {datetime.now().isoformat()}\n")
        f.write("-- Run this in Supabase SQL Editor\n\n")
    
    print(f"Generating content for {len(STATES)} states...")
    print("-" * 50)
    
    all_data = []
    
    for i, (state_name, abbreviation) in enumerate(STATES, 1):
        print(f"[{i}/{len(STATES)}] {state_name} ({abbreviation})...", end=" ")
        
        data = generate_state_content(state_name, abbreviation)
        
        if data:
            all_data.append(data)
            print("✓")
            
            # Save progress every 5 states
            if i % 5 == 0 or i == len(STATES):
                with open(output_file, 'a') as f:
                    for state_data in all_data[-5:]:
                        f.write(to_sql_insert(state_data))
                print(f"  Saved progress ({i}/{len(STATES)} states)")
        else:
            print("✗ (skipped)")
        
    print("-" * 50)
    print(f"Complete! Generated content for {len(all_data)} states")
    print(f"Output saved to: {output_file}")

if __name__ == "__main__":
    main()
