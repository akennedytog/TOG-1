-- BabyNest State Content - Batch 5 (States 37-45)
-- States: SD, TN, UT, VT, VA, WA, WV, WI, WY
-- Run this in Supabase SQL Editor

-- South Dakota
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'South Dakota',
    'SD',
    'CollegeAccess 529 Plan',
    'The CollegeAccess 529 Plan is South Dakota''s tax-advantaged college savings plan, offering a variety of investment options to help families save for future education expenses. It is open to residents of any state and provides tax-free growth on contributions.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "There is no state income tax in South Dakota, so no state tax deduction is available."}'::jsonb,
    'https://www.collegeaccess529.com',
    '{"state_income_tax": "none", "child_tax_credit": "South Dakota follows federal guidelines for the child tax credit.", "dependent_care_credit": "South Dakota does not offer a state-specific dependent care credit.", "earned_income_credit": "South Dakota does not offer a state-specific earned income credit.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30", "automatic_coverage_period": "30", "chip_program": "South Dakota CHIP", "medicaid_expansion": true, "special_rules": "Parents should apply for Medicaid or CHIP within 30 days of birth for continuous coverage."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "No state matching grants are available for the 529 plan.", "scholarships": "The South Dakota Opportunity Scholarship provides up to $6,500 over four years for eligible students.", "other": "South Dakota offers the Jump Start Scholarship for students who graduate high school early."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in South Dakota. While the state does not have an income tax, making it unique in its tax structure, parents can still take advantage of federal tax benefits and the CollegeAccess 529 Plan to save for their child''s education. Understanding the available insurance programs, such as Medicaid and CHIP, ensures that your newborn has the necessary health coverage from the start.", "key_deadlines": ["Enroll your newborn in health insurance within 30 days of birth.", "Apply for Medicaid or CHIP as soon as possible after birth."], "action_items": ["Open a CollegeAccess 529 Plan to start saving for education.", "Review federal tax credits and deductions applicable to new parents.", "Ensure your newborn is covered by health insurance within the first 30 days."], "resources": ["https://www.collegeaccess529.com", "https://dss.sd.gov/medicaid/children/chip.aspx", "https://www.sdsos.gov/scholarships/SDOpportunityScholarship.aspx"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Tennessee
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Tennessee',
    'TN',
    'TNStars College Savings 529 Program',
    'The TNStars College Savings 529 Program offers families a flexible and tax-advantaged way to save for future education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Tennessee does not have a state income tax, so there are no state tax deductions for contributions."}'::jsonb,
    'https://www.tnstars.com/',
    '{"state_income_tax": "none", "child_tax_credit": "Federal child tax credit up to $2,000 per qualifying child.", "dependent_care_credit": "Federal credit available for up to 35% of qualifying expenses.", "earned_income_credit": "Federal EITC available based on income and number of children.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "CoverKids", "medicaid_expansion": true, "special_rules": "Parents must apply within 30 days of birth to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "TNStars offers occasional promotions with matching contributions.", "scholarships": "Tennessee Promise provides last-dollar scholarships for community college.", "other": "Tennessee HOPE Scholarship for eligible students attending in-state colleges."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is crucial. In Tennessee, parents have access to the TNStars College Savings 529 Program, which offers a tax-advantaged way to save for education. Although Tennessee does not have a state income tax, the 529 plan provides federal tax benefits, with earnings growing tax-free when used for qualified education expenses. Additionally, programs like CoverKids ensure that your child has access to healthcare coverage from birth.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Consider opening a 529 plan as early as possible to maximize growth."], "action_items": ["Apply for a Social Security number for your newborn.", "Enroll your newborn in a health insurance plan within 30 days.", "Open a TNStars 529 College Savings account to start saving for education.", "Explore eligibility for programs like Tennessee Promise and HOPE Scholarship."], "resources": ["https://www.tnstars.com/", "https://www.tn.gov/coverkids.html", "https://www.tn.gov/collegepays/financial-aid.html", "https://www.tn.gov/tnpromise.html"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Utah
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Utah',
    'UT',
    'my529',
    'my529 is Utah''s official 529 college savings plan, offering tax-advantaged savings for education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions to my529 are eligible for a Utah state income tax credit."}'::jsonb,
    'https://my529.org',
    '{"state_income_tax": "4.85%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Up to 15% of the federal credit for child and dependent care expenses.", "earned_income_credit": "10% of the federal earned income credit for eligible taxpayers.", "unique_deductions": ["Utah Educational Savings Plan credit", "Retirement savings contributions credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Utah Children''s Health Insurance Program (CHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s health insurance plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Not available", "scholarships": "Utah offers various scholarships through the Utah System of Higher Education.", "other": "Utah Educational Savings Plan offers a state tax credit for contributions."}'::jsonb,
    '{"overview": "Planning for a baby''s future in Utah involves understanding the financial tools and benefits available to new parents. Utah offers a robust 529 plan, my529, which allows parents to save for future educational expenses with tax advantages. Additionally, the state provides several tax credits and deductions that can ease the financial burden of raising a child. Health insurance coverage for newborns is also a critical consideration, with specific enrollment deadlines and automatic coverage periods to be aware of.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File for state tax credits by April 15"], "action_items": ["Open a my529 account", "Review health insurance options for newborn", "Explore state tax credits and deductions"], "resources": ["https://my529.org", "https://health.utah.gov/chip", "https://tax.utah.gov"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Vermont
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Vermont',
    'VT',
    'Vermont Higher Education Investment Plan',
    'The Vermont Higher Education Investment Plan is the state''s 529 college savings plan, offering tax-advantaged savings for education expenses. It provides a variety of investment options managed by Intuition College Savings Solutions.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Vermont state income tax, up to the specified limits."}'::jsonb,
    'https://www.vheip.org/',
    '{"state_income_tax": "3.35% - 8.75%", "child_tax_credit": "Vermont offers a state-level child tax credit of $1,000 per qualifying child under age 5.", "dependent_care_credit": "Vermont provides a dependent care credit equal to 24% of the federal credit.", "earned_income_credit": "Vermont offers a state earned income tax credit equal to 36% of the federal EITC.", "unique_deductions": ["Social Security benefits deduction", "Charitable contributions deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Dr. Dynasaur", "medicaid_expansion": true, "special_rules": "Vermont provides coverage for pregnant women and children under Dr. Dynasaur, with income-based eligibility."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "The Vermont Higher Education Investment Plan offers a matching grant program for eligible low-income families.", "scholarships": "Vermont Student Assistance Corporation (VSAC) offers various scholarships for Vermont residents.", "other": "VSAC also provides career and education counseling services."}'::jsonb,
    '{"overview": "Welcoming a new baby is a joyous occasion, and planning for their future is an important step for Vermont parents. Understanding the financial landscape can help you make informed decisions about saving for education, managing healthcare, and taking advantage of tax benefits. Vermont offers a variety of programs and incentives to support families, including the Vermont Higher Education Investment Plan for college savings, state tax credits, and healthcare programs like Dr. Dynasaur.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a Vermont 529 plan account", "Review eligibility for Dr. Dynasaur", "Claim applicable tax credits on state tax return"], "resources": ["https://www.vheip.org/", "https://www.vtvsac.org/", "https://www.greenmountaincare.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Virginia
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Virginia',
    'VA',
    'Virginia529',
    'Virginia529 is the official 529 college savings plan for the state of Virginia, offering tax-advantaged savings options for education expenses. The plan provides flexibility with various investment options and can be used for qualified education expenses nationwide.',
    '{"state_tax_deduction": "up to $4,000 per account per year", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Unused deductions can be carried forward to future tax years until the full amount is deducted."}'::jsonb,
    'https://www.virginia529.com/',
    '{"state_income_tax": "2% to 5.75%", "child_tax_credit": "Up to $500 per qualifying child", "dependent_care_credit": "20% to 35% of qualifying expenses, up to $3,000 for one child or $6,000 for two or more children", "earned_income_credit": "20% of the federal EITC, non-refundable", "unique_deductions": ["529 plan contributions", "Virginia Education Savings Trust contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "FAMIS (Family Access to Medical Insurance Security)", "medicaid_expansion": true, "special_rules": "Virginia provides automatic coverage for newborns under the mother''s health plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Virginia529 Prepaid", "matching_grants": "Virginia529 offers a scholarship program for eligible low-income families.", "scholarships": "Virginia529 offers scholarships through its SOAR Virginia program for high school students.", "other": "Virginia529 also offers the Invest529 program with various investment options."}'::jsonb,
    '{"overview": "Planning for a new baby in Virginia involves understanding the financial resources and benefits available to support your child''s future. Virginia offers a robust 529 plan, Virginia529, which provides tax advantages for saving for education expenses. Additionally, the state provides various tax credits and deductions to ease the financial burden on families. Health insurance coverage for newborns is crucial, and Virginia has specific rules to ensure your child is covered from birth.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth", "Consider opening a Virginia529 account as early as possible"], "action_items": ["Review and enroll in a health insurance plan for your newborn", "Open a Virginia529 account to start saving for education", "Explore eligibility for state tax credits and deductions"], "resources": ["https://www.virginia529.com/", "https://www.coverva.org/", "https://www.tax.virginia.gov/individual-income-tax"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Washington
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Washington',
    'WA',
    'DreamAhead College Investment Plan',
    'The DreamAhead College Investment Plan is Washington''s 529 college savings plan, offering a variety of investment options to help families save for future education expenses. It provides flexibility in contributions and withdrawals for qualified education expenses.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Washington does not have a state income tax, so there are no state tax deductions for contributions."}'::jsonb,
    'https://wastate529.wa.gov/dreamahead',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines, up to $2,000 per qualifying child.", "dependent_care_credit": "Follows federal guidelines, up to $3,000 for one child or $6,000 for two or more children.", "earned_income_credit": "Follows federal guidelines, varies based on income and number of children.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Apple Health for Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered for 30 days under the mother''s plan."}'::jsonb,
    '{"prepaid_plan": "GET (Guaranteed Education Tuition) Program", "matching_grants": "No state matching grants available.", "scholarships": "The Washington College Grant provides financial aid to eligible students.", "other": "Washington offers the College Bound Scholarship for eligible low-income students."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in Washington. Understanding the financial tools and resources available can help you prepare for your child''s education and healthcare needs. Washington offers the DreamAhead College Investment Plan, a flexible 529 savings plan, and the GET Program, a prepaid tuition plan, to help families save for college. Additionally, the state provides various healthcare programs to ensure your child is covered from birth.", "key_deadlines": ["Enroll newborns in health insurance within 60 days of birth.", "Consider opening a 529 plan as early as possible to maximize savings."], "action_items": ["Research and choose between the DreamAhead 529 Plan and the GET Program.", "Enroll your newborn in a health insurance plan within the 60-day window.", "Explore eligibility for the Washington College Grant and College Bound Scholarship."], "resources": ["https://wastate529.wa.gov/", "https://www.hca.wa.gov/health-care-services-supports/apple-health-medicaid-coverage", "https://wsac.wa.gov/college-bound"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- West Virginia
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'West Virginia',
    'WV',
    'SMART529 WV Direct College Savings Plan',
    'The SMART529 WV Direct College Savings Plan is a tax-advantaged savings plan designed to help families save for future education expenses. It offers a variety of investment options and is managed by The Hartford Financial Services Group, Inc.',
    '{"state_tax_deduction": "up to $5,000 per year per account holder", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible in the year they are made, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.smart529.com',
    '{"state_income_tax": "3% to 6.5%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child", "dependent_care_credit": "20% to 35% of qualifying expenses, following federal rules", "earned_income_credit": "Follows federal guidelines; up to 20% of the federal EITC", "unique_deductions": ["Deduction for contributions to WV 529 plans", "Deduction for Social Security benefits"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "West Virginia Children''s Health Insurance Program (WVCHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "Occasional promotions may offer matching contributions for new accounts", "scholarships": "Various state-sponsored scholarships available for residents", "other": "West Virginia Invests Grant covers tuition and fees for certain certificate and associate degree programs"}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In West Virginia, parents can take advantage of several state-specific programs and tax benefits to help manage the costs of raising a child. The SMART529 WV Direct College Savings Plan offers a tax-advantaged way to save for future education expenses. Additionally, West Virginia provides a range of tax credits and deductions that can ease the financial burden on families. Understanding these benefits and planning accordingly can help ensure a secure financial future for your child.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to a 529 plan by December 31 for tax benefits"], "action_items": ["Open a SMART529 account and start contributing", "Review eligibility for WVCHIP and Medicaid", "Explore available scholarships and grants"], "resources": ["https://www.smart529.com", "https://www.wvchip.org", "https://www.wvinvests.org"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Wisconsin
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Wisconsin',
    'WI',
    'Edvest College Savings Plan',
    'The Edvest College Savings Plan is Wisconsin''s official 529 college savings plan, offering tax-advantaged savings options for education expenses. It provides a range of investment options managed by TIAA-CREF, designed to help families save for future education costs.',
    '{"state_tax_deduction": "up to $3,860 per beneficiary", "deduction_amount_single": 3860, "deduction_amount_married": 7720, "earnings_tax_free": true, "notes": "Contributions are deductible from Wisconsin state income tax up to the stated limits per beneficiary."}'::jsonb,
    'https://www.edvest.com/',
    '{"state_income_tax": "3.54% - 7.65%", "child_tax_credit": "Wisconsin does not have a state-specific child tax credit, but federal credits apply.", "dependent_care_credit": "Up to 50% of the federal credit, non-refundable.", "earned_income_credit": "A percentage of the federal EITC, ranging from 4% to 34% depending on the number of children.", "unique_deductions": ["Tuition and fee deduction", "Wisconsin Homestead Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "BadgerCare Plus", "medicaid_expansion": true, "special_rules": "BadgerCare Plus covers children up to 300% of the federal poverty level."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "Edvest occasionally offers promotions with matching contributions for new accounts.", "scholarships": "Wisconsin offers various state scholarships, such as the Wisconsin Grant for low-income students.", "other": "Wisconsin residents can benefit from the Wisconsin Covenant, which provides support for students who meet certain academic and community service criteria."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their financial future is an important step for Wisconsin parents. From saving for college with the Edvest 529 Plan to understanding state tax benefits, there are many resources available to help manage the costs of raising a child. Additionally, Wisconsin offers health coverage options through BadgerCare Plus, ensuring that your child has access to necessary healthcare services.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to Edvest by December 31 for tax benefits"], "action_items": ["Open an Edvest 529 account", "Review health insurance options", "Explore state tax benefits and credits"], "resources": ["https://www.edvest.com/", "https://www.dhs.wisconsin.gov/badgercareplus/", "https://www.revenue.wi.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Wyoming
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Wyoming',
    'WY',
    'CollegeInvest Direct Portfolio College Savings Plan',
    'The CollegeInvest Direct Portfolio College Savings Plan offers a range of investment options managed by Vanguard and is designed to help families save for future education expenses. It provides flexibility in contributions and tax advantages for growth.',
    '{"state_tax_deduction": false, "deduction_amount_single": 0, "deduction_amount_married": 0, "earnings_tax_free": true, "notes": "Wyoming does not offer a state income tax deduction for contributions to 529 plans."}'::jsonb,
    'https://www.collegeinvest.org/',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Follows federal guidelines; up to 35% of qualifying expenses.", "earned_income_credit": "Wyoming does not have a state EIC; follows federal EIC guidelines.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Kid Care CHIP", "medicaid_expansion": false, "special_rules": "Wyoming has not expanded Medicaid under the ACA."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "No state matching grants available for 529 plans.", "scholarships": "Wyoming Hathaway Scholarship Program provides merit-based scholarships for Wyoming students attending the University of Wyoming or Wyoming community colleges.", "other": "Wyoming offers the Hathaway Scholarship, which is a unique benefit for residents."}'::jsonb,
    '{"overview": "As new parents in Wyoming, planning for your child''s future education and financial security is crucial. While Wyoming does not have a state income tax, it offers unique opportunities like the Hathaway Scholarship Program for higher education. Additionally, the CollegeInvest Direct Portfolio College Savings Plan allows you to save for college with tax-free growth on earnings. Understanding your insurance options, such as enrolling your newborn in health coverage within 60 days, is also important.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth.", "Consider opening a 529 plan as early as possible to maximize growth potential."], "action_items": ["Research and consider opening a CollegeInvest 529 plan.", "Ensure your newborn is added to your health insurance plan within 60 days.", "Explore the Hathaway Scholarship Program for future educational planning."], "resources": ["https://www.collegeinvest.org/", "https://health.wyo.gov/healthcarefin/chip/", "https://edu.wyoming.gov/beyond-the-classroom/college-career/hathaway-scholarship-program/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();
