-- BabyNest State Content - 45 States
-- Generated: 2026-05-10T19:44:33.598607
-- Run this in Supabase SQL Editor

-- Alabama
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Alabama',
    'AL',
    'Alabama CollegeCounts 529 Fund',
    'The Alabama CollegeCounts 529 Fund is a tax-advantaged savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Alabama state income tax, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.collegecounts529.com/',
    '{"state_income_tax": "2% - 5%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "20% to 35% of qualifying expenses, depending on income.", "earned_income_credit": "Follows federal guidelines; percentage of the federal credit.", "unique_deductions": ["Alabama offers a deduction for contributions to the CollegeCounts 529 Fund."]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "ALL Kids", "medicaid_expansion": false, "special_rules": "Newborns must be enrolled within 60 days to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "Alabama Prepaid Affordable College Tuition (PACT)", "matching_grants": "No state matching grants available.", "scholarships": "Alabama offers various state scholarships based on merit and need.", "other": "Alabama provides the ALL Kids CHIP program for low-cost health coverage for children."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in Alabama. From saving for college with the CollegeCounts 529 Fund to understanding tax benefits and insurance rules, there are several financial considerations to keep in mind. Alabama offers a state income tax deduction for contributions to its 529 plan, and families can benefit from various tax credits and deductions. Additionally, understanding health insurance enrollment deadlines and options like the ALL Kids program can help ensure your child is covered.", "key_deadlines": ["Enroll newborn in health insurance within 60 days.", "Consider opening a 529 plan early to maximize savings."], "action_items": ["Open a CollegeCounts 529 Fund account.", "Review health insurance options and enroll your newborn.", "Explore available tax credits and deductions."], "resources": ["https://www.collegecounts529.com/", "https://www.alabamapublichealth.gov/allkids/", "https://www.revenue.alabama.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Alaska
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Alaska',
    'AK',
    'Alaska 529',
    'Alaska 529 is a tax-advantaged college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Alaska does not have a state income tax, contributions grow tax-deferred and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.alaska529plan.com',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines, up to $2,000 per child.", "dependent_care_credit": "Follows federal guidelines, up to 35% of qualifying expenses.", "earned_income_credit": "Follows federal guidelines, available to low- to moderate-income working families.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Denali KidCare", "medicaid_expansion": true, "special_rules": "Alaska provides automatic coverage for newborns under existing family plans for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "Alaska does not currently offer matching grants for 529 contributions.", "scholarships": "Alaska Performance Scholarship for high school graduates meeting specific criteria.", "other": "Alaska offers the Alaska Education Loan for residents pursuing higher education."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and financial planning is an important part of preparing for your child''s future. In Alaska, parents can take advantage of the Alaska 529 plan to save for education expenses, benefiting from tax-free growth and withdrawals for qualified expenses. While Alaska does not have a state income tax, it provides several federal tax credits and benefits that can help reduce the financial burden of raising a child. Additionally, programs like Denali KidCare ensure that your child has access to necessary healthcare services.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Consider opening an Alaska 529 account as early as possible to maximize growth potential."], "action_items": ["Open an Alaska 529 account to start saving for future education expenses.", "Enroll your newborn in a health insurance plan within the first 30 days.", "Explore eligibility for federal tax credits such as the Child Tax Credit and Earned Income Credit."], "resources": ["https://www.alaska529plan.com", "https://dhss.alaska.gov/dpa/Pages/medicaid/DenaliKidCare.aspx", "https://www.irs.gov/credits-deductions/individuals/earned-income-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Arizona
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Arizona',
    'AZ',
    'AZ529, Arizona''s Education Savings Plan',
    'AZ529 is Arizona''s official 529 college savings plan, designed to help families save for future education expenses with tax advantages. Contributions grow tax-deferred, and withdrawals used for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "up to $2,000 for single filers and $4,000 for joint filers", "deduction_amount_single": 2000, "deduction_amount_married": 4000, "earnings_tax_free": true, "notes": "Contributions are deductible from Arizona state income tax."}'::jsonb,
    'https://az529.gov/',
    '{"state_income_tax": "2.59% to 4.50%", "child_tax_credit": "Up to $2,000 per qualifying child under federal law", "dependent_care_credit": "25% of the federal credit", "earned_income_credit": "None", "unique_deductions": ["Contributions to AZ529", "Military retirement pay exclusion"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "KidsCare", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "The Arizona Community Foundation offers various scholarships for state residents.", "other": "Arizona offers tax credits for private school tuition organizations."}'::jsonb,
    '{"overview": "Welcoming a new baby is a joyous occasion, but it also comes with financial responsibilities. In Arizona, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. From saving for future education expenses with the AZ529 plan to understanding state-specific tax credits, there are many ways to plan for your child''s future. Additionally, Arizona provides healthcare coverage options for newborns and young children through programs like KidsCare.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "File state taxes to claim AZ529 deductions by April 15"], "action_items": ["Open an AZ529 account", "Review health insurance coverage for your newborn", "Explore available scholarships and grants"], "resources": ["https://az529.gov/", "https://www.azdor.gov/TaxCredits.aspx", "https://www.azahcccs.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Arkansas
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Arkansas',
    'AR',
    'Arkansas Brighter Future 529 Plan',
    'The Arkansas Brighter Future 529 Plan is designed to help families save for future education expenses with tax advantages. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "up to $10,000 for married couples filing jointly and $5,000 for individuals", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Arkansas state income tax."}'::jsonb,
    'https://www.arkansas529.org',
    '{"state_income_tax": "2% to 5.5%", "child_tax_credit": "Follows federal child tax credit rules", "dependent_care_credit": "20% of the federal credit", "earned_income_credit": "3% of the federal EITC", "unique_deductions": ["Tuition deduction for higher education", "Credit for adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "ARKids First", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "The Gift Arkansas 529 Matching Grant Program offers matching contributions for eligible families.", "scholarships": "Arkansas Academic Challenge Scholarship for residents attending in-state colleges.", "other": "Arkansas offers the ARKids First program for children''s health insurance."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Arkansas, parents can take advantage of various state programs and tax benefits to ease the financial burden. The Arkansas Brighter Future 529 Plan offers tax advantages for saving for your child''s education, while the ARKids First program ensures affordable health coverage. Understanding these resources can help you plan effectively for your child''s future.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Apply for ARKids First as soon as possible after birth"], "action_items": ["Open an Arkansas Brighter Future 529 account", "Review eligibility for ARKids First", "Check eligibility for state tax credits"], "resources": ["https://www.arkansas529.org", "https://humanservices.arkansas.gov/about-dhs/dms/arkids", "https://www.irs.gov/credits-deductions/individuals/earned-income-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Colorado
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Colorado',
    'CO',
    'CollegeInvest Direct Portfolio College Savings Plan',
    'The CollegeInvest Direct Portfolio College Savings Plan offers a tax-advantaged way to save for higher education expenses. Managed by Vanguard, it provides a variety of investment options to suit different risk tolerances and savings goals.',
    '{"state_tax_deduction": "Full amount of contributions", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Colorado state income tax in the year they are made."}'::jsonb,
    'https://www.collegeinvest.org/',
    '{"state_income_tax": "4.4%", "child_tax_credit": "Follows federal guidelines with additional state credits for low-income families.", "dependent_care_credit": "Up to $1,000 per child for low-income families.", "earned_income_credit": "10% of the federal EITC for eligible families.", "unique_deductions": ["Contributions to a 529 plan", "Child care expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Child Health Plan Plus (CHP+)", "medicaid_expansion": true, "special_rules": "Colorado offers a special enrollment period for newborns within 30 days of birth."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "CollegeInvest offers matching grants for qualifying low- and middle-income families.", "scholarships": "CollegeInvest offers scholarships through its Matching Grant and Scholarship Program.", "other": "CollegeInvest also provides financial literacy resources for families."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is an exciting time, and planning for their future is an important step. In Colorado, parents have access to a variety of financial tools and resources to help manage the costs of raising a child. From tax-advantaged savings plans to state-specific tax credits, understanding these options can help you make informed decisions. Additionally, Colorado offers health insurance programs to ensure your child has access to necessary medical care.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Open a 529 plan as early as possible to maximize savings"], "action_items": ["Review and enroll in a 529 plan", "Apply for health insurance for your newborn", "Explore available tax credits and deductions"], "resources": ["https://www.collegeinvest.org/", "https://www.colorado.gov/pacific/hcpf/child-health-plan-plus", "https://www.colorado.gov/pacific/cdle/tax-credits"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Connecticut
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Connecticut',
    'CT',
    'CHET 529 College Savings Program',
    'The CHET 529 College Savings Program is Connecticut''s tax-advantaged savings plan designed to help families save for future college expenses. It offers a range of investment options and is open to residents and non-residents alike.',
    '{"state_tax_deduction": "false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are not deductible on Connecticut state taxes, but earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.aboutchet.com',
    '{"state_income_tax": "3% to 6.99%", "child_tax_credit": "Connecticut does not offer a state-level child tax credit.", "dependent_care_credit": "Connecticut offers a dependent care credit that is a percentage of the federal credit.", "earned_income_credit": "Connecticut offers a refundable Earned Income Tax Credit equal to 30.5% of the federal EITC.", "unique_deductions": ["Property tax credit", "Social Security income exclusion"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "HUSKY B", "medicaid_expansion": true, "special_rules": "Connecticut''s HUSKY Health program provides coverage for children and families with varying income levels."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "CHET Baby Scholars offers a $100 contribution for babies under one year old when an account is opened.", "scholarships": "CHET Advance Scholarship awards scholarships to high school seniors and college students.", "other": "CHET Dream Big! Competition offers additional opportunities for account holders."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Connecticut, parents have access to the CHET 529 College Savings Program, which offers tax advantages and flexible investment options to help save for college expenses. Additionally, Connecticut provides various tax benefits and health insurance programs to support families.", "key_deadlines": ["Enroll newborns in health insurance within 60 days of birth.", "Open a CHET 529 account early to take advantage of the CHET Baby Scholars program."], "action_items": ["Consider opening a CHET 529 College Savings account.", "Review eligibility for Connecticut''s HUSKY Health program.", "Explore Connecticut''s tax credits and deductions for families."], "resources": ["https://www.aboutchet.com", "https://portal.ct.gov/HUSKY", "https://portal.ct.gov/DRS"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Delaware
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Delaware',
    'DE',
    'Delaware College Investment Plan',
    'The Delaware College Investment Plan is a tax-advantaged savings plan designed to help families save for future education expenses. It offers a variety of investment options managed by Fidelity, allowing flexibility and growth potential.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Delaware does not offer a state tax deduction for contributions, the earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.fidelity.com/529-plans/delaware',
    '{"state_income_tax": "2.2% - 6.6%", "child_tax_credit": "Follows federal rules; no additional state credit", "dependent_care_credit": "20% of the federal credit", "earned_income_credit": "20% of the federal EITC", "unique_deductions": ["No state-specific deductions for children"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Delaware Healthy Children Program", "medicaid_expansion": true, "special_rules": "Delaware provides automatic coverage for newborns under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None available", "scholarships": "The Delaware Scholarship Compendium provides information on various scholarships available to residents.", "other": "Delaware offers the SEED (Student Excellence Equals Degree) Scholarship for eligible students attending Delaware Technical Community College."}'::jsonb,
    '{"overview": "Planning for a new baby involves understanding the financial implications and taking advantage of available resources. In Delaware, parents can benefit from the Delaware College Investment Plan to save for future education expenses. While the state does not offer a tax deduction for contributions, the plan''s tax-free growth on earnings can be a significant advantage. Additionally, Delaware provides various tax benefits and credits that can help reduce the financial burden on families.", "key_deadlines": ["Enroll newborns in health insurance within 30 days of birth", "Annual tax filing deadline: April 15"], "action_items": ["Open a Delaware College Investment Plan account", "Review health insurance options for newborn coverage", "Explore available scholarships and grants"], "resources": ["https://www.fidelity.com/529-plans/delaware", "https://dhss.delaware.gov/dhss/dss/dhcp.html", "https://www.delawarestudentsuccess.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Georgia
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Georgia',
    'GA',
    'Path2College 529 Plan',
    'The Path2College 529 Plan is Georgia''s official college savings plan, offering tax-advantaged savings options to help families prepare for future education expenses. It provides a range of investment options and is managed by TIAA-CREF Tuition Financing, Inc.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 4000, "deduction_amount_married": 8000, "earnings_tax_free": true, "notes": "Contributions are deductible from Georgia state income tax, and the earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.path2college529.com/',
    '{"state_income_tax": "5.75%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "20% to 35% of eligible expenses, similar to federal", "earned_income_credit": "No state EITC; follows federal guidelines", "unique_deductions": ["Contributions to the Path2College 529 Plan"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "PeachCare for Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered for the first 30 days under the mother''s health plan."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "No state matching grants available", "scholarships": "HOPE Scholarship for eligible Georgia residents", "other": "Georgia offers the Zell Miller Scholarship for students with exceptional academic performance."}'::jsonb,
    '{"overview": "As new parents in Georgia, planning for your child''s future involves understanding the financial tools and benefits available to you. The Path2College 529 Plan is a key resource, offering tax advantages and a variety of investment options to help you save for your child''s education. Additionally, Georgia provides several tax benefits and programs to support families, including the PeachCare for Kids program for health coverage.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth", "Annual contribution deadline for 529 tax deductions: December 31"], "action_items": ["Open a Path2College 529 Plan account", "Enroll your newborn in health insurance within the first 30 days", "Explore eligibility for PeachCare for Kids and Medicaid"], "resources": ["https://www.path2college529.com/", "https://dch.georgia.gov/peachcare-kids", "https://www.georgiafutures.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Hawaii
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Hawaii',
    'HI',
    'Hawaii''s College Savings Program',
    'Hawaii''s College Savings Program offers a tax-advantaged way to save for college expenses. The plan provides flexibility in investment options and can be used at eligible institutions nationwide.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Hawaii does not offer a state tax deduction for contributions to the 529 plan."}'::jsonb,
    'https://www.uhero.hawaii.edu/529-college-savings-plan/',
    '{"state_income_tax": "1.4% to 11%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "15% of the federal credit", "earned_income_credit": "20% of the federal EITC", "unique_deductions": ["None specific to children"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Hawaii QUEST", "medicaid_expansion": true, "special_rules": "Hawaii provides comprehensive coverage through its QUEST program, which includes CHIP and Medicaid services."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "Hawaii B+ Scholarship for high school graduates attending UH campuses", "other": "Hawaii offers the Early Learning Scholarship Program for preschool-aged children."}'::jsonb,
    '{"overview": "Planning for a new baby in Hawaii involves understanding the financial landscape, including education savings, tax benefits, and healthcare options. Hawaii offers a 529 College Savings Plan to help parents save for future education costs, though it does not provide a state tax deduction for contributions. Healthcare coverage for newborns is comprehensive, with automatic coverage periods and access to programs like Hawaii QUEST. Additionally, parents can benefit from state tax credits and unique educational programs.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "File taxes by April 15 to claim credits"], "action_items": ["Open a 529 plan for education savings", "Enroll newborn in Hawaii QUEST if eligible", "Explore state tax credits and deductions"], "resources": ["https://www.uhero.hawaii.edu/529-college-savings-plan/", "https://medquest.hawaii.gov/", "https://www.hawaii.edu/finaid/scholarships/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Idaho
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Idaho',
    'ID',
    'IDeal - Idaho College Savings Program',
    'IDeal is Idaho''s 529 college savings plan, offering tax-advantaged savings for education expenses. It provides flexible investment options and can be used for a variety of education-related costs.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Idaho state income tax, up to $6,000 for single filers and $12,000 for joint filers."}'::jsonb,
    'https://www.idsaves.org/',
    '{"state_income_tax": "1.125% to 6.925%", "child_tax_credit": "Idaho offers a nonrefundable child tax credit of $205 per qualifying child.", "dependent_care_credit": "Idaho provides a credit equal to 50% of the federal credit for child and dependent care expenses.", "earned_income_credit": "Idaho does not offer a state-specific earned income credit.", "unique_deductions": ["Contributions to Idaho 529 plans", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Idaho Children''s Health Insurance Program (CHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "IDeal occasionally offers matching grant promotions for new accounts.", "scholarships": "IDeal offers scholarships through various promotions and partnerships.", "other": "IDeal provides financial literacy resources for families."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Idaho, parents have access to the IDeal 529 College Savings Program, which offers tax advantages and flexible savings options for education expenses. Understanding the state''s tax benefits and insurance rules can help parents make informed financial decisions.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Consider opening a 529 plan soon after birth"], "action_items": ["Open an IDeal 529 account", "Review health insurance coverage for your newborn", "Explore Idaho''s tax benefits for families"], "resources": ["https://www.idsaves.org/", "https://healthandwelfare.idaho.gov/", "https://tax.idaho.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Indiana
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Indiana',
    'IN',
    'CollegeChoice 529 Direct Savings Plan',
    'The CollegeChoice 529 Direct Savings Plan offers a flexible and tax-advantaged way for families to save for future education expenses. It provides a variety of investment options and is open to both Indiana residents and non-residents.',
    '{"state_tax_deduction": "up to $1,500", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Indiana state income tax up to $1,500 per taxpayer, per year."}'::jsonb,
    'https://www.collegechoicedirect.com/',
    '{"state_income_tax": "3.23%", "child_tax_credit": "Follows federal guidelines, up to $2,000 per qualifying child.", "dependent_care_credit": "20% of the federal credit, non-refundable.", "earned_income_credit": "9% of the federal earned income credit.", "unique_deductions": ["Adoption Credit", "Education Expense Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Hoosier Healthwise", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Not available", "scholarships": "The 21st Century Scholars Program offers income-eligible students up to four years of undergraduate tuition at participating Indiana colleges.", "other": "Indiana offers the On My Way Pre-K program for eligible 4-year-olds."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents. In Indiana, families can take advantage of the CollegeChoice 529 Direct Savings Plan to start saving for their child''s education with tax advantages. Additionally, understanding state tax benefits and insurance rules will help ensure your family is financially prepared.", "key_deadlines": ["60 days to enroll newborns in health insurance", "April 15 for state tax deductions"], "action_items": ["Open a CollegeChoice 529 account", "Review health insurance coverage for your newborn", "Explore eligibility for the 21st Century Scholars Program"], "resources": ["https://www.collegechoicedirect.com/", "https://www.in.gov/fssa/ompp/hoosier-healthwise/", "https://scholars.in.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Iowa
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Iowa',
    'IA',
    'College Savings Iowa 529 Plan',
    'The College Savings Iowa 529 Plan offers a tax-advantaged way to save for education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $3,785 per beneficiary", "deduction_amount_single": 3785, "deduction_amount_married": 7570, "earnings_tax_free": true, "notes": "The deduction amount is adjusted annually for inflation."}'::jsonb,
    'https://www.collegesavingsiowa.com',
    '{"state_income_tax": "4.4% - 8.53%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child", "dependent_care_credit": "Up to 75% of the federal credit", "earned_income_credit": "15% of the federal EITC", "unique_deductions": ["Tuition and Textbook Credit", "Iowa Adoption Tax Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "31 days", "chip_program": "hawk-i", "medicaid_expansion": true, "special_rules": "Iowa provides automatic enrollment for newborns under existing family plans for the first 31 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "Iowa Tuition Grant for private college students", "other": "Iowa offers the Future Ready Iowa Last-Dollar Scholarship for community college students."}'::jsonb,
    '{"overview": "As a new parent in Iowa, it''s important to consider the financial aspects of raising a child, including education savings, tax benefits, and insurance coverage. Iowa offers a robust 529 plan, College Savings Iowa, which provides tax advantages for saving for your child''s future education. Additionally, understanding state tax benefits and insurance rules can help you make informed decisions for your family''s financial well-being.", "key_deadlines": ["Enroll newborns in health insurance within 60 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a College Savings Iowa 529 account", "Review and adjust your health insurance coverage", "Explore state tax credits and deductions"], "resources": ["https://www.collegesavingsiowa.com", "https://dhs.iowa.gov/hawki", "https://tax.iowa.gov"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Kansas
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Kansas',
    'KS',
    'Learning Quest 529 Education Savings Program',
    'The Learning Quest 529 Education Savings Program is Kansas''s tax-advantaged college savings plan. It offers a variety of investment options managed by American Century Investments, designed to help families save for future education expenses.',
    '{"state_tax_deduction": "up to $3,000 per beneficiary", "deduction_amount_single": 3000, "deduction_amount_married": 6000, "earnings_tax_free": true, "notes": "Contributions are deductible from Kansas state income tax for each beneficiary."}'::jsonb,
    'https://www.learningquest.com',
    '{"state_income_tax": "3.1% to 5.7%", "child_tax_credit": "Follows federal child tax credit rules", "dependent_care_credit": "Up to 25% of the federal credit", "earned_income_credit": "17% of the federal credit", "unique_deductions": ["529 plan contributions", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "KanCare", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "No state matching grants available", "scholarships": "Kansas offers various scholarships through state universities and private organizations.", "other": "Kansas offers the Kansas Promise Scholarship for specific high-demand fields."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Kansas, parents can take advantage of the Learning Quest 529 Education Savings Program to start saving for their child''s future education. Additionally, understanding state tax benefits and insurance rules can help parents manage expenses effectively. Kansas provides several tax credits and deductions that can ease the financial burden of raising a child.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a 529 plan account", "Review health insurance coverage options", "Explore available tax credits and deductions"], "resources": ["https://www.learningquest.com", "https://www.kancare.ks.gov", "https://www.ksrevenue.org"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Kentucky
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Kentucky',
    'KY',
    'Kentucky Education Savings Plan Trust',
    'The Kentucky Education Savings Plan Trust is a 529 college savings plan that offers tax advantages for saving for education expenses. It allows families to invest in a variety of investment options to grow their savings over time.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Kentucky state income tax up to the specified limits."}'::jsonb,
    'https://www.kysaves.com/',
    '{"state_income_tax": "5%", "child_tax_credit": "Follows federal guidelines; no additional state credit.", "dependent_care_credit": "Follows federal guidelines; no additional state credit.", "earned_income_credit": "Follows federal guidelines; no additional state credit.", "unique_deductions": ["Deduction for contributions to Kentucky''s 529 plan"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "KCHIP", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "No matching grants currently available", "scholarships": "The Kentucky Educational Excellence Scholarship (KEES) is available for students who meet academic requirements.", "other": "Kentucky offers the Work Ready Kentucky Scholarship for certain technical programs."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Kentucky, parents can take advantage of the Kentucky Education Savings Plan Trust to start saving for their child''s future education expenses. This 529 plan offers tax advantages and a variety of investment options to help your savings grow. Additionally, understanding state tax benefits and insurance rules can help you better plan for your family''s needs.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Consider opening a 529 plan as early as possible"], "action_items": ["Open a Kentucky 529 plan to start saving for education", "Review health insurance options and enroll your newborn", "Explore state scholarships and financial aid options"], "resources": ["https://www.kysaves.com/", "https://kidshealth.ky.gov/Pages/index.aspx", "https://kheaa.com/website/kheaa/kees?main=1"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Louisiana
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Louisiana',
    'LA',
    'START Saving Program',
    'The START Saving Program is Louisiana''s 529 college savings plan, designed to help families save for future education expenses. It offers tax advantages and flexible investment options to meet the needs of Louisiana residents.',
    '{"state_tax_deduction": "up to $2,400 per beneficiary per year", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Louisiana state income tax up to $2,400 per beneficiary per year, or $4,800 for married couples filing jointly."}'::jsonb,
    'https://www.startsaving.la.gov/',
    '{"state_income_tax": "1.85% to 4.25%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child", "dependent_care_credit": "Up to 50% of the federal credit", "earned_income_credit": "3.5% of the federal EITC", "unique_deductions": ["School tuition deduction", "Student loan interest deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "LaCHIP", "medicaid_expansion": true, "special_rules": "Louisiana offers automatic coverage for newborns for the first 30 days if the parent is already insured."}'::jsonb,
    '{"prepaid_plan": "START K12 Program", "matching_grants": "The START Saving Program offers an Earnings Enhancement Fund, which matches a percentage of contributions based on income level.", "scholarships": "Taylor Opportunity Program for Students (TOPS)", "other": "Louisiana offers the START K12 Program for saving towards private school tuition."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Louisiana, parents have access to the START Saving Program, a 529 plan that provides tax advantages and flexible savings options for future education expenses. Additionally, Louisiana offers several tax benefits and unique programs to support families, including the LaCHIP program for children''s health insurance and the Taylor Opportunity Program for Students (TOPS) for scholarships.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a START Saving Program account", "Review health insurance options for your newborn", "Explore eligibility for LaCHIP and Medicaid"], "resources": ["https://www.startsaving.la.gov/", "https://ldh.la.gov/index.cfm/subhome/1/n/331", "https://www.osfa.la.gov/tops/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Maine
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Maine',
    'ME',
    'NextGen 529',
    'The NextGen 529 plan is Maine''s tax-advantaged college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is managed by the Finance Authority of Maine (FAME) with investments managed by Merrill Lynch.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Maine does not offer a state tax deduction for contributions, the plan offers tax-free growth and withdrawals for qualified expenses."}'::jsonb,
    'https://www.nextgenforme.com/',
    '{"state_income_tax": "5.8% to 7.15%", "child_tax_credit": "Maine offers a state child tax credit that mirrors the federal credit.", "dependent_care_credit": "Maine provides a state credit for dependent care expenses, which is a percentage of the federal credit.", "earned_income_credit": "Maine offers a state earned income credit equal to 25% of the federal EITC.", "unique_deductions": ["Educational Opportunity Tax Credit", "Property Tax Fairness Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "MaineCare", "medicaid_expansion": true, "special_rules": "MaineCare provides comprehensive coverage for children and pregnant women with expanded income eligibility."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "NextGen 529 offers matching grants for eligible Maine residents, such as the Alfond Grant for newborns.", "scholarships": "The Alfond Scholarship Foundation provides a $500 grant to every Maine resident baby for future education expenses.", "other": "Maine offers the Harold Alfond College Challenge, which automatically provides a $500 grant to every baby born a Maine resident."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step. In Maine, parents have access to resources like the NextGen 529 plan to start saving for education early. Understanding the state''s tax benefits and insurance rules can help parents make informed financial decisions. Maine''s unique programs, such as the Alfond Grant, provide additional support to ensure your child''s educational future is bright.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Apply for the Alfond Grant within one year of birth"], "action_items": ["Open a NextGen 529 account", "Review MaineCare eligibility for your newborn", "Apply for the Alfond Grant"], "resources": ["https://www.nextgenforme.com/", "https://www.maine.gov/dhhs/mainecare.shtml", "https://www.alfondscholarshipfoundation.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Maryland
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Maryland',
    'MD',
    'Maryland 529',
    'Maryland 529 offers two college savings options: the Maryland Prepaid College Trust and the Maryland College Investment Plan. These plans provide tax-advantaged ways to save for future education expenses.',
    '{"state_tax_deduction": "up to $2,500 per beneficiary per account", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions exceeding $2,500 can be carried forward for up to 10 years."}'::jsonb,
    'https://maryland529.com/',
    '{"state_income_tax": "2% to 5.75%", "child_tax_credit": "Maryland does not offer a state-level child tax credit, but federal credits apply.", "dependent_care_credit": "Maryland offers a state-level dependent care credit that is a percentage of the federal credit.", "earned_income_credit": "Maryland offers a refundable earned income credit that is a percentage of the federal EITC.", "unique_deductions": ["Child and Dependent Care Expenses", "529 Plan Contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Maryland Children''s Health Program (MCHP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s health plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Maryland Prepaid College Trust", "matching_grants": "The Save4College State Contribution Program offers matching contributions for eligible families.", "scholarships": "Various scholarships are available through Maryland Higher Education Commission.", "other": "Maryland offers a state contribution program for low to moderate-income families."}'::jsonb,
    '{"overview": "Planning for a new baby involves considering future education costs, healthcare, and tax benefits. Maryland offers a variety of programs to help parents save for college, including the Maryland 529 plans. These plans provide tax advantages and flexible savings options. Additionally, understanding state tax benefits and insurance rules can help ensure financial stability.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a Maryland 529 account", "Review health insurance options for your newborn", "Understand state and federal tax benefits"], "resources": ["https://maryland529.com/", "https://www.marylandhealthconnection.gov/", "https://www.mhec.state.md.us/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Massachusetts
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Massachusetts',
    'MA',
    'U.Fund College Investing Plan',
    'The U.Fund College Investing Plan is Massachusetts'' tax-advantaged 529 college savings plan. It offers a variety of investment options managed by Fidelity Investments, allowing families to save for future education expenses.',
    '{"state_tax_deduction": "up to $1,000 for single filers and $2,000 for joint filers", "deduction_amount_single": 1000, "deduction_amount_married": 2000, "earnings_tax_free": true, "notes": "Contributions are deductible from Massachusetts state income tax, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.fidelity.com/529-plans/massachusetts',
    '{"state_income_tax": "5%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "15% of the federal credit", "earned_income_credit": "30% of the federal credit", "unique_deductions": ["Deduction for 529 plan contributions", "Renters deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "MassHealth", "medicaid_expansion": true, "special_rules": "Massachusetts requires health insurance coverage for all residents, with penalties for non-compliance."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "The U.Fund offers occasional matching grant promotions for new accounts.", "scholarships": "The John and Abigail Adams Scholarship provides tuition waivers for Massachusetts public colleges.", "other": "The BabySteps Savings Plan offers a $50 seed deposit for newborns enrolled in the U.Fund."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is an exciting time, but it also comes with financial responsibilities. In Massachusetts, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. From the U.Fund College Investing Plan to state tax deductions, there are numerous ways to plan for your child''s future education expenses. Additionally, understanding state insurance rules and available credits can help you manage costs effectively.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a U.Fund 529 account", "Review and update health insurance coverage", "Explore eligibility for MassHealth and CHIP"], "resources": ["https://www.fidelity.com/529-plans/massachusetts", "https://www.mass.gov/topics/masshealth", "https://www.mass.gov/service-details/child-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Michigan
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Michigan',
    'MI',
    'Michigan Education Savings Program (MESP)',
    'The Michigan Education Savings Program (MESP) is a tax-advantaged 529 college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Michigan state income tax up to the specified limits."}'::jsonb,
    'https://www.misaves.com/',
    '{"state_income_tax": "4.25%", "child_tax_credit": "No additional state child tax credit; follows federal guidelines.", "dependent_care_credit": "Michigan offers a state credit based on a percentage of the federal credit.", "earned_income_credit": "Michigan offers a state EITC equal to 6% of the federal EITC.", "unique_deductions": ["Tuition and fees deduction for higher education"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "MIChild", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Michigan Education Trust (MET)", "matching_grants": "No state matching grants available.", "scholarships": "The Michigan Competitive Scholarship is available for students who meet certain criteria.", "other": "MI Bright Future program offers career exploration resources."}'::jsonb,
    '{"overview": "Welcoming a new baby is a joyous occasion, but it also comes with financial responsibilities. In Michigan, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. From the Michigan Education Savings Program to state tax deductions, there are numerous ways to plan for your child''s future education. Additionally, Michigan offers health insurance programs like MIChild to ensure your newborn is covered.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth.", "Contribute to MESP by December 31st for tax benefits."], "action_items": ["Open a Michigan Education Savings Program account.", "Review and update health insurance coverage for your newborn.", "Explore Michigan Education Trust for prepaid tuition options."], "resources": ["https://www.misaves.com/", "https://www.michigan.gov/treasury/0,4679,7-121-1753_6096-213665--,00.html", "https://www.michigan.gov/mdhhs/assistance-programs/healthcare/childrens-health-insurance-program"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Minnesota
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Minnesota',
    'MN',
    'Minnesota College Savings Plan',
    'The Minnesota College Savings Plan is a tax-advantaged 529 savings plan designed to help families save for education expenses. Contributions grow tax-deferred, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $1,500 for single filers and $3,000 for joint filers", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Minnesota state income tax, subject to limits."}'::jsonb,
    'https://www.mnsaves.org',
    '{"state_income_tax": "5.35% - 9.85%", "child_tax_credit": "Minnesota offers a refundable child tax credit for eligible families.", "dependent_care_credit": "Minnesota provides a dependent care credit for qualifying expenses.", "earned_income_credit": "Minnesota offers a state earned income credit, which is a percentage of the federal EITC.", "unique_deductions": ["Education Savings Account contributions", "Student Loan Interest Deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "MinnesotaCare", "medicaid_expansion": true, "special_rules": "MinnesotaCare offers low-cost health coverage for children and families."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "The Minnesota College Savings Plan offers matching grants for low- and moderate-income families.", "scholarships": "The plan offers scholarships for eligible participants.", "other": "Minnesota also provides tax credits for educational expenses."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Minnesota, parents can take advantage of various financial programs and tax benefits to help ease the burden of saving for their child''s future education. The Minnesota College Savings Plan offers a flexible and tax-advantaged way to save for college expenses, while state tax deductions and credits can provide additional financial relief. Understanding these options can help parents plan effectively for their child''s future.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File for state tax deductions by April 15"], "action_items": ["Open a Minnesota College Savings Plan account", "Review eligibility for MinnesotaCare", "Apply for child tax credits"], "resources": ["https://www.mnsaves.org", "https://mn.gov/dhs/people-we-serve/children-and-families/health-care/health-care-programs/programs-and-services/minnesotacare.jsp", "https://www.revenue.state.mn.us/individuals"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Mississippi
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Mississippi',
    'MS',
    'Mississippi Affordable College Savings (MACS) Program',
    'The Mississippi Affordable College Savings (MACS) Program is designed to help families save for future college expenses. It offers tax advantages and flexible investment options to make saving for higher education more accessible.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions to the MACS plan are deductible from Mississippi state income tax, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.treasurerlynnfitch.ms.gov/college-savings-macs',
    '{"state_income_tax": "3% to 5%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "Follows federal guidelines; no additional state credit", "earned_income_credit": "Follows federal guidelines; no additional state credit", "unique_deductions": ["Contributions to MACS", "Interest on student loans"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Mississippi CHIP", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Mississippi Prepaid Affordable College Tuition (MPACT) Program", "matching_grants": "No state matching grants available", "scholarships": "Mississippi Tuition Assistance Grant (MTAG) and Mississippi Eminent Scholars Grant (MESG)", "other": "The state offers various scholarships and financial aid programs for residents."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is a joyous occasion, and planning for their future is an important step. In Mississippi, parents have access to a variety of financial planning tools and resources to help secure their child''s education and well-being. From the Mississippi Affordable College Savings (MACS) Program to state tax benefits, there are several ways to prepare financially for your child''s future. Additionally, understanding insurance rules and available state programs can ensure your child is well-protected and supported.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Consider opening a 529 plan as early as possible"], "action_items": ["Open a MACS 529 plan", "Review health insurance options for your newborn", "Explore state scholarships and grants"], "resources": ["https://www.treasurerlynnfitch.ms.gov/college-savings-macs", "https://medicaid.ms.gov/chip", "https://riseupms.com/financial-aid/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Missouri
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Missouri',
    'MO',
    'MOST - Missouri''s 529 Education Plan',
    'MOST 529 is Missouri''s state-sponsored college savings plan, offering tax advantages for residents saving for education expenses. Contributions grow tax-deferred, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $8,000 per taxpayer", "deduction_amount_single": 8000, "deduction_amount_married": 16000, "earnings_tax_free": true, "notes": "Contributions are deductible from Missouri state income tax, up to $8,000 per taxpayer or $16,000 for married couples filing jointly."}'::jsonb,
    'https://www.missourimost.org',
    '{"state_income_tax": "0% to 5.4%", "child_tax_credit": "Follows federal guidelines with no additional state credit", "dependent_care_credit": "20% to 35% of eligible expenses, follows federal guidelines", "earned_income_credit": "10% of the federal EITC", "unique_deductions": ["Contributions to MOST 529 Plan", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "31 days of automatic coverage", "chip_program": "MO HealthNet for Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 31 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "MOST 529 offers periodic promotions and matching grants for new accounts.", "scholarships": "MOST 529 periodically offers scholarships and contests for account holders.", "other": "Missouri offers a First Steps program for early intervention services for children with developmental delays."}'::jsonb,
    '{"overview": "Planning for a new baby in Missouri involves understanding the financial benefits and programs available to support your child''s future. Missouri offers a robust 529 college savings plan with significant tax advantages, making it easier for parents to save for education expenses. Additionally, the state provides various tax credits and deductions that can benefit families. Health insurance rules ensure newborns are covered, and programs like MO HealthNet for Kids offer additional support for eligible families.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to MOST 529 by December 31 for tax benefits"], "action_items": ["Open a MOST 529 account", "Review health insurance options for your newborn", "Check eligibility for MO HealthNet for Kids"], "resources": ["https://www.missourimost.org", "https://mydss.mo.gov/healthcare/mo-healthnet-for-kids", "https://dor.mo.gov"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Montana
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Montana',
    'MT',
    'Montana Family Education Savings Program',
    'The Montana Family Education Savings Program offers a tax-advantaged way to save for education expenses. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "amount", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Montana state income tax, subject to limits."}'::jsonb,
    'https://www.mfesp.com/',
    '{"state_income_tax": "1% - 6.75%", "child_tax_credit": "Follows federal guidelines, no additional state credit", "dependent_care_credit": "Follows federal guidelines, no additional state credit", "earned_income_credit": "3% of the federal EITC", "unique_deductions": ["529 plan contributions", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "31 days of automatic coverage", "chip_program": "Healthy Montana Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 31 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None available", "scholarships": "Some scholarships available through the Montana University System", "other": "Montana offers a tax deduction for contributions to any state''s 529 plan."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In Montana, parents can take advantage of various programs and tax benefits to ease the financial burden. The Montana Family Education Savings Program allows parents to save for their child''s future education expenses with tax advantages. Additionally, understanding the state''s tax benefits and insurance rules can help parents plan effectively.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "File state taxes by April 15 to claim deductions"], "action_items": ["Open a 529 plan account", "Review health insurance coverage options", "Explore eligibility for state tax credits"], "resources": ["https://www.mfesp.com/", "https://dphhs.mt.gov/hmk", "https://revenue.mt.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Nebraska
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Nebraska',
    'NE',
    'NEST 529 College Savings Plan',
    'The NEST 529 College Savings Plan offers a flexible and tax-advantaged way to save for future education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Nebraska state income tax, up to the specified limits."}'::jsonb,
    'https://www.nest529.com',
    '{"state_income_tax": "2.46% - 6.84%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Non-refundable credit based on federal credit, up to $1,050 for one child.", "earned_income_credit": "10% of the federal EITC.", "unique_deductions": ["529 plan contributions", "Charitable contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Kids Connection", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "Occasional promotions for matching contributions for new accounts.", "scholarships": "NEST 529 offers periodic scholarship opportunities for account holders.", "other": "NEST 529 offers periodic promotions and incentives for new account holders."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in Nebraska. Understanding the financial landscape, including tax benefits and savings plans, can help you prepare for your child''s education and healthcare needs. Nebraska offers the NEST 529 College Savings Plan, which provides tax advantages and flexible investment options to help you save for future educational expenses. Additionally, understanding state tax benefits and insurance rules will ensure you maximize your resources.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a NEST 529 College Savings Plan account", "Review and adjust your health insurance coverage", "Explore state tax benefits and credits"], "resources": ["https://www.nest529.com", "https://dhhs.ne.gov/Pages/Medicaid-and-Long-Term-Care.aspx", "https://revenue.nebraska.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Nevada
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Nevada',
    'NV',
    'Nevada College Savings Plans',
    'Nevada offers several 529 plans, including the SSGA Upromise 529 Plan, the Vanguard 529 College Savings Plan, and the USAA 529 College Savings Plan. These plans provide a variety of investment options and are designed to help families save for future college expenses.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While Nevada does not offer a state tax deduction, earnings grow tax-free and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://nv529.org/',
    '{"state_income_tax": "none", "child_tax_credit": "Eligible for federal child tax credit up to $2,000 per qualifying child.", "dependent_care_credit": "Eligible for federal credit up to 35% of qualifying expenses, depending on income.", "earned_income_credit": "Eligible for federal EITC, which varies based on income and number of children.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Nevada Check Up", "medicaid_expansion": true, "special_rules": "Parents must apply for Medicaid or Nevada Check Up within 30 days of birth to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "Nevada does not currently offer matching grants for 529 contributions.", "scholarships": "The Millennium Scholarship provides up to $10,000 for eligible Nevada high school graduates attending in-state colleges.", "other": "Nevada offers the Silver State Matching Grant Program for eligible families with low to moderate income."}'::jsonb,
    '{"overview": "Planning for a new baby in Nevada involves understanding the financial tools and benefits available to you. While Nevada does not have a state income tax, it offers several 529 college savings plans to help you save for your child''s education. Additionally, programs like Nevada Check Up provide health coverage for children from low-income families. It''s important to be aware of enrollment deadlines for health insurance and to take advantage of federal tax credits.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Apply for Nevada Check Up or Medicaid as soon as possible after birth."], "action_items": ["Open a Nevada 529 College Savings Plan to start saving for education.", "Ensure your newborn is added to your health insurance plan within 30 days.", "Explore eligibility for Nevada Check Up if applicable."], "resources": ["Nevada College Savings Plans: https://nv529.org/", "Nevada Check Up: https://dhcfp.nv.gov/Pgms/CPT/NevadaCheckUp/", "Federal Child Tax Credit: https://www.irs.gov/credits-deductions/individuals/child-tax-credit"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- New Hampshire
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'New Hampshire',
    'NH',
    'New Hampshire''s UNIQUE College Investing Plan',
    'The UNIQUE College Investing Plan is New Hampshire''s 529 college savings plan, offering tax-advantaged savings for education expenses. Managed by Fidelity Investments, it provides a variety of investment options to help families save for future education costs.',
    '{"state_tax_deduction": false, "deduction_amount_single": 0, "deduction_amount_married": 0, "earnings_tax_free": true, "notes": "While New Hampshire does not offer a state tax deduction, earnings grow tax-free, and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.fidelity.com/529-plans/new-hampshire',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines; no additional state credit.", "dependent_care_credit": "No additional state credit; follows federal guidelines.", "earned_income_credit": "No additional state credit; follows federal guidelines.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "New Hampshire Healthy Kids", "medicaid_expansion": true, "special_rules": "Parents must apply for Medicaid or CHIP within 30 days to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "New Hampshire does not offer matching grants for 529 contributions.", "scholarships": "The UNIQUE Annual Scholarship Program provides scholarships to New Hampshire residents attending college in the state.", "other": "New Hampshire offers the UNIQUE Endowment Scholarship, funded by the New Hampshire Higher Education Assistance Foundation."}'::jsonb,
    '{"overview": "Planning for a new baby involves considering future education expenses, healthcare, and tax benefits. In New Hampshire, parents can take advantage of the UNIQUE College Investing Plan, a 529 savings plan that offers tax-free growth and withdrawals for qualified education expenses. While the state does not impose an income tax, understanding federal tax credits and deductions can help maximize savings. Additionally, ensuring health coverage for your newborn through programs like Medicaid and CHIP is crucial.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Apply for Medicaid or CHIP within 30 days if eligible."], "action_items": ["Open a UNIQUE College Investing Plan account to start saving for education.", "Review federal tax credits and deductions applicable to families.", "Ensure newborn is enrolled in a health insurance plan within the deadline."], "resources": ["https://www.fidelity.com/529-plans/new-hampshire", "https://www.nh.gov/insurance/consumers/health.htm", "https://www.dhhs.nh.gov/programs-services/medicaid/medicaid-children"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- New Jersey
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'New Jersey',
    'NJ',
    'NJBEST 529 College Savings Plan',
    'The NJBEST 529 College Savings Plan is New Jersey''s tax-advantaged college savings plan designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "While contributions are not tax-deductible, earnings grow tax-free and withdrawals are tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.njbest.com',
    '{"state_income_tax": "1.4% to 10.75%", "child_tax_credit": "New Jersey offers a state-level child tax credit for eligible families, which is based on income and the number of qualifying children.", "dependent_care_credit": "New Jersey provides a state-level dependent care credit that mirrors the federal credit, with specific income limits and percentages.", "earned_income_credit": "New Jersey offers a state Earned Income Tax Credit (EITC) that is a percentage of the federal EITC, providing additional support to low- and moderate-income families.", "unique_deductions": ["Property tax deduction", "Medical expenses deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "NJ FamilyCare", "medicaid_expansion": true, "special_rules": "New Jersey requires that newborns be added to a health insurance plan within 60 days of birth to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "New Jersey offers a one-time scholarship through the NJBEST program for students attending a New Jersey college or university.", "scholarships": "NJBEST Scholarship provides up to $3,000 for students attending in-state schools.", "other": "New Jersey provides various state financial aid programs for higher education, including the Tuition Aid Grant (TAG) program."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In New Jersey, parents can take advantage of various state programs and tax benefits to ease the financial burden of raising a child. From the NJBEST 529 College Savings Plan to state tax credits, there are numerous resources available to help parents plan for their child''s future.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth", "Consider opening a 529 plan as early as possible to maximize growth"], "action_items": ["Research and enroll in the NJBEST 529 College Savings Plan", "Review eligibility for state tax credits and deductions", "Add newborn to health insurance within the required timeframe"], "resources": ["https://www.njbest.com", "https://www.state.nj.us/treasury/taxation/", "https://www.njfamilycare.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- New Mexico
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'New Mexico',
    'NM',
    'The Education Plan',
    'The Education Plan is New Mexico''s 529 college savings plan, designed to help families save for future education expenses. It offers tax advantages and a variety of investment options to fit different risk preferences.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from New Mexico state income tax."}'::jsonb,
    'https://www.theeducationplan.com/',
    '{"state_income_tax": "1.7% - 5.9%", "child_tax_credit": "Follows federal guidelines, no additional state credit", "dependent_care_credit": "Up to 40% of the federal credit", "earned_income_credit": "10% of the federal EITC", "unique_deductions": ["529 plan contributions", "Medical care expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "New MexiKids", "medicaid_expansion": true, "special_rules": "Newborns are covered under the mother''s Medicaid for the first year if the mother was on Medicaid at the time of birth."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "The New Mexico Legislative Lottery Scholarship provides tuition assistance to New Mexico residents.", "other": "New Mexico offers the Bridge to Success Scholarship for students transitioning from high school to college."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In New Mexico, parents have access to various programs and tax benefits that can help ease the financial burden of raising a child. From the state''s 529 college savings plan to tax credits and health insurance options, there are many resources available to support your family''s financial planning.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Consider opening a 529 plan as early as possible"], "action_items": ["Review and update your health insurance policy", "Open a 529 college savings account", "Explore eligibility for state tax credits and deductions"], "resources": ["https://www.theeducationplan.com/", "https://www.yes.state.nm.us/", "https://www.nmlegis.gov/", "https://www.bewellnm.com/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- North Carolina
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'North Carolina',
    'NC',
    'NC 529 Plan',
    'The NC 529 Plan is North Carolina''s tax-advantaged college savings plan, designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are not deductible on North Carolina state taxes, but earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.cfnc.org/save-for-college/nc-529-plan/',
    '{"state_income_tax": "4.75%", "child_tax_credit": "North Carolina does not have a state-specific child tax credit, but federal credits apply.", "dependent_care_credit": "North Carolina offers a state credit of up to 7% of eligible expenses, depending on income.", "earned_income_credit": "North Carolina does not offer a state EITC, but federal EITC is available.", "unique_deductions": ["529 plan earnings tax-free", "Child and Dependent Care Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "NC Health Choice", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "No state matching grants available.", "scholarships": "The North Carolina Education Lottery Scholarship is available for eligible students attending a UNC System university.", "other": "North Carolina offers the NC Promise Tuition Plan, which reduces tuition costs at select universities."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In North Carolina, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. The NC 529 Plan is a flexible and tax-advantaged way to save for your child''s future education expenses. Additionally, understanding state tax benefits and insurance rules can help you plan effectively.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Consider opening a 529 plan early to maximize savings"], "action_items": ["Open an NC 529 Plan account", "Review health insurance options for your newborn", "Explore eligibility for NC Health Choice"], "resources": ["https://www.cfnc.org", "https://www.ncdhhs.gov", "https://www.nclottery.com/Education"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- North Dakota
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'North Dakota',
    'ND',
    'College SAVE',
    'College SAVE is North Dakota''s 529 college savings plan, designed to help families save for future education expenses. The plan offers tax advantages and a variety of investment options to suit different risk preferences.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from North Dakota state income tax, and earnings grow tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.collegesave4u.com/',
    '{"state_income_tax": "1.10% - 2.90%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "20% of the federal credit", "earned_income_credit": "10% of the federal credit", "unique_deductions": ["529 plan contributions", "medical expenses exceeding 7.5% of AGI"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Healthy Steps", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "The College SAVE plan offers a matching grant for eligible families, providing up to $300 in matching funds.", "scholarships": "The College SAVE plan offers scholarships through the BND Match Program for qualifying families.", "other": "The College SAVE plan provides a $25 initial contribution for new accounts opened for babies under one year old."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is a joyous occasion, but it also comes with financial responsibilities. In North Dakota, parents can take advantage of several financial planning tools to prepare for their child''s future. From the College SAVE 529 plan to state-specific tax benefits, there are numerous ways to save for education and manage the costs of raising a child. Understanding insurance rules and available state programs can also help ensure your child is covered and your family is financially secure.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Open a College SAVE account early to maximize benefits"], "action_items": ["Set up a College SAVE 529 plan", "Review health insurance coverage options", "Explore eligibility for CHIP and Medicaid"], "resources": ["https://www.collegesave4u.com/", "https://www.nd.gov/dhs/services/medicalserv/chip/", "https://www.nd.gov/dhs/services/financialhelp/eitc.html"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Ohio
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Ohio',
    'OH',
    'CollegeAdvantage 529 Savings Plan',
    'The CollegeAdvantage 529 Savings Plan is Ohio''s tax-advantaged college savings plan, offering a variety of investment options to help families save for higher education expenses. Contributions grow tax-free, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $4,000 per beneficiary, per year", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions over $4,000 per beneficiary can be carried forward to future years."}'::jsonb,
    'https://www.collegeadvantage.com/',
    '{"state_income_tax": "2.765% - 3.99%", "child_tax_credit": "Up to $2,000 per qualifying child under federal guidelines", "dependent_care_credit": "Up to 25% of the federal credit, depending on income", "earned_income_credit": "10% of the federal credit", "unique_deductions": ["Adoption credit", "Disability income exclusion"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Healthy Start", "medicaid_expansion": true, "special_rules": "Ohio allows retroactive Medicaid coverage for up to 3 months prior to application if eligible."}'::jsonb,
    '{"prepaid_plan": "Ohio Tuition Trust Authority Prepaid Plan", "matching_grants": "CollegeAdvantage offers periodic matching grants and promotions.", "scholarships": "Ohio offers various state-funded scholarships for residents attending in-state colleges.", "other": "Ohio offers a variety of state-specific education grants and financial aid programs."}'::jsonb,
    '{"overview": "Planning for a new baby in Ohio involves understanding the financial benefits and programs available to support your child''s future. Ohio offers several tax advantages and savings plans, such as the CollegeAdvantage 529 Savings Plan, which provides tax-free growth and withdrawals for education expenses. Additionally, Ohio''s Medicaid and CHIP programs ensure that healthcare is accessible to all families, providing peace of mind for new parents.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File for state tax deductions by April 15"], "action_items": ["Open a CollegeAdvantage 529 Savings Plan", "Enroll your newborn in health insurance", "Explore Ohio''s Medicaid and CHIP programs"], "resources": ["https://www.collegeadvantage.com/", "https://medicaid.ohio.gov/", "https://www.benefits.gov/benefit/1608"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Oklahoma
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Oklahoma',
    'OK',
    'Oklahoma 529 College Savings Plan',
    'The Oklahoma 529 College Savings Plan is designed to help families save for future education expenses with tax advantages. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions above the annual limit can be carried forward for up to five years."}'::jsonb,
    'https://www.ok4saving.org/',
    '{"state_income_tax": "0.25% to 4.75%", "child_tax_credit": "Oklahoma does not offer a state-specific child tax credit, but federal credits apply.", "dependent_care_credit": "Oklahoma offers a percentage of the federal credit for child and dependent care expenses.", "earned_income_credit": "Oklahoma provides a refundable Earned Income Credit equal to 5% of the federal credit.", "unique_deductions": ["529 plan contributions", "adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "SoonerCare", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s SoonerCare plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Oklahoma does not currently offer a prepaid tuition plan.", "matching_grants": "Oklahoma does not offer matching grants for 529 contributions.", "scholarships": "Oklahoma''s Promise offers scholarships for students from low-income families who meet academic and conduct requirements.", "other": "The Oklahoma Tuition Equalization Grant Program provides grants to students attending private colleges."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their financial future is an important step. In Oklahoma, parents have access to a variety of financial benefits and programs to help ease the cost of raising a child. From the Oklahoma 529 College Savings Plan to state tax benefits, there are many ways to save for your child''s education and future expenses. Additionally, health insurance programs like SoonerCare ensure that your child has access to necessary medical care.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Annual tax filing deadlines for state deductions"], "action_items": ["Open an Oklahoma 529 College Savings Plan account", "Review eligibility for SoonerCare", "Explore Oklahoma''s Promise scholarship program"], "resources": ["https://www.ok4saving.org/", "https://www.oklahoma.gov/ohca/individuals/programs/soonercare.html", "https://www.okhighered.org/okpromise/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Oregon
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Oregon',
    'OR',
    'Oregon College Savings Plan',
    'The Oregon College Savings Plan offers a tax-advantaged way to save for education expenses. It provides flexibility in investment options and can be used at schools nationwide. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Oregon state income tax up to the specified limits."}'::jsonb,
    'https://www.oregoncollegesavings.com/',
    '{"state_income_tax": "4.75% to 9.9%", "child_tax_credit": "Follows federal guidelines, up to $2,000 per qualifying child.", "dependent_care_credit": "Up to 30% of qualifying expenses, based on income.", "earned_income_credit": "8% of the federal EITC amount.", "unique_deductions": ["Oregon Cultural Trust contribution", "Political contribution credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Oregon Health Plan (OHP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "Oregon does not currently offer matching grants for 529 contributions.", "scholarships": "The Oregon Promise Grant provides funding for recent high school graduates and GED recipients to attend community college.", "other": "The Oregon Opportunity Grant is the state''s largest need-based grant program for college students."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future education is an important step. In Oregon, parents can take advantage of the Oregon College Savings Plan, which offers tax benefits and flexible investment options to save for future education expenses. Additionally, understanding the state''s tax benefits and insurance rules can help parents manage costs effectively.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File state taxes by April 15"], "action_items": ["Open an Oregon College Savings Plan account", "Review health insurance coverage for newborn", "Explore state tax credits and deductions"], "resources": ["https://www.oregoncollegesavings.com/", "https://www.oregon.gov/dor/", "https://www.oregon.gov/oha/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Pennsylvania
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Pennsylvania',
    'PA',
    'Pennsylvania 529 Investment Plan',
    'The Pennsylvania 529 Investment Plan (IP) offers families a flexible and tax-advantaged way to save for education expenses. Contributions grow tax-free, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $15,000 per beneficiary per year", "deduction_amount_single": 15000, "deduction_amount_married": 30000, "earnings_tax_free": true, "notes": "Contributions are deductible from Pennsylvania state income tax, up to the annual limit per beneficiary."}'::jsonb,
    'https://www.pa529.com/',
    '{"state_income_tax": "3.07%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "Follows federal guidelines; no additional state credit", "earned_income_credit": "None", "unique_deductions": ["529 plan contributions", "Medical savings account contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Pennsylvania Children''s Health Insurance Program (CHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "PA 529 Guaranteed Savings Plan", "matching_grants": "The Keystone Scholars program provides a $100 starter deposit for every baby born to or adopted by a Pennsylvania family after December 31, 2018.", "scholarships": "The PATH program offers scholarships to students who demonstrate financial need.", "other": "Pennsylvania offers the Keystone Scholars program to encourage early savings for education."}'::jsonb,
    '{"overview": "Planning for a new baby in Pennsylvania involves understanding the financial resources and benefits available to families. The Pennsylvania 529 Investment Plan provides a tax-advantaged way to save for future education expenses, with significant state tax deductions available. Additionally, the state offers health insurance programs like CHIP to ensure children have access to necessary healthcare. By taking advantage of these programs and understanding key deadlines, parents can better prepare for the financial responsibilities of raising a child.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a Pennsylvania 529 Investment Plan account", "Enroll newborn in health insurance", "Explore CHIP and Medicaid options if eligible"], "resources": ["https://www.pa529.com/", "https://www.chipcoverspakids.com/", "https://www.dhs.pa.gov/Services/Assistance/Pages/Medicaid.aspx"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Rhode Island
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Rhode Island',
    'RI',
    'CollegeBound Saver',
    'CollegeBound Saver is Rhode Island''s 529 college savings plan, designed to help families save for future education expenses. The plan offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "amount", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Rhode Island state income tax, subject to limits."}'::jsonb,
    'https://www.collegeboundsaver.com/',
    '{"state_income_tax": "3.75% - 5.99%", "child_tax_credit": "Rhode Island does not offer a state-specific child tax credit.", "dependent_care_credit": "Rhode Island offers a state credit based on a percentage of the federal credit.", "earned_income_credit": "Rhode Island offers a refundable earned income credit equal to 15% of the federal EITC.", "unique_deductions": ["529 plan contributions", "medical expenses exceeding 10% of AGI"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "RIte Care", "medicaid_expansion": true, "special_rules": "Newborns are covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Rhode Island does not currently offer matching grants for 529 contributions.", "scholarships": "The Rhode Island Promise Scholarship provides two years of free tuition at the Community College of Rhode Island for eligible students.", "other": "The state offers various financial aid programs for higher education through the Rhode Island Student Loan Authority."}'::jsonb,
    '{"overview": "Raising a child in Rhode Island involves careful financial planning, especially when considering future education expenses. The CollegeBound Saver 529 plan offers a tax-advantaged way to save for college, with state tax deductions available for contributions. Additionally, Rhode Island provides several tax benefits and credits that can help reduce the financial burden on families. Understanding the state''s insurance rules and unique programs can also aid in securing your child''s future.", "key_deadlines": ["30 days to enroll newborn in health insurance", "April 15th for state tax deductions"], "action_items": ["Open a CollegeBound Saver 529 account", "Review eligibility for RIte Care", "Apply for the Rhode Island Promise Scholarship if applicable"], "resources": ["https://www.collegeboundsaver.com/", "https://healthsourceri.com/", "https://www.ri.gov/taxation/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- South Carolina
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'South Carolina',
    'SC',
    'Future Scholar 529 College Savings Plan',
    'The Future Scholar 529 College Savings Plan is South Carolina''s tax-advantaged savings plan designed to help families save for future education expenses. It offers a range of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "unlimited", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from South Carolina state income tax with no annual limit."}'::jsonb,
    'https://www.futurescholar.com/',
    '{"state_income_tax": "0% - 7%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Up to 7% of eligible expenses, based on income.", "earned_income_credit": "20.83% of the federal EITC for eligible taxpayers.", "unique_deductions": ["Contributions to the Future Scholar 529 Plan", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Partners for Healthy Children", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Not available", "scholarships": "Palmetto Fellows Scholarship, LIFE Scholarship, HOPE Scholarship", "other": "Babynet early intervention program for infants and toddlers with disabilities."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is an exciting time, but it also brings new financial responsibilities. In South Carolina, parents can take advantage of various programs and tax benefits to help manage these costs. From the Future Scholar 529 College Savings Plan to state-specific tax credits, there are numerous ways to plan for your child''s future. Additionally, understanding insurance rules and deadlines is crucial to ensure your newborn''s health coverage.", "key_deadlines": ["60 days to enroll newborn in health insurance", "April 15 for state income tax filing"], "action_items": ["Open a Future Scholar 529 Plan account", "Review health insurance options for your newborn", "Explore state tax credits and deductions"], "resources": ["https://www.futurescholar.com/", "https://www.scdhhs.gov/", "https://dor.sc.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- South Dakota
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'South Dakota',
    'SD',
    'CollegeAccess 529 Plan',
    'The CollegeAccess 529 Plan is South Dakota''s tax-advantaged college savings plan, offering a variety of investment options to help families save for future education expenses. It is open to residents of any state and provides tax-free growth on contributions.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "There is no state income tax in South Dakota, so no state tax deduction is available."}'::jsonb,
    'https://www.collegeaccess529.com',
    '{"state_income_tax": "none", "child_tax_credit": "South Dakota follows federal guidelines for the child tax credit.", "dependent_care_credit": "South Dakota does not offer a state-specific dependent care credit.", "earned_income_credit": "South Dakota does not offer a state-specific earned income credit.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30", "automatic_coverage_period": "30", "chip_program": "South Dakota CHIP", "medicaid_expansion": true, "special_rules": "Parents should apply for Medicaid or CHIP within 30 days of birth for continuous coverage."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "No state matching grants are available for the 529 plan.", "scholarships": "The South Dakota Opportunity Scholarship provides up to $6,500 over four years for eligible students.", "other": "South Dakota offers the Jump Start Scholarship for students who graduate high school early."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in South Dakota. While the state does not have an income tax, making it unique in its tax structure, parents can still take advantage of federal tax benefits and the CollegeAccess 529 Plan to save for their child''s education. Understanding the available insurance programs, such as Medicaid and CHIP, ensures that your newborn has the necessary health coverage from the start.", "key_deadlines": ["Enroll your newborn in health insurance within 30 days of birth.", "Apply for Medicaid or CHIP as soon as possible after birth."], "action_items": ["Open a CollegeAccess 529 Plan to start saving for education.", "Review federal tax credits and deductions applicable to new parents.", "Ensure your newborn is covered by health insurance within the first 30 days."], "resources": ["https://www.collegeaccess529.com", "https://dss.sd.gov/medicaid/children/chip.aspx", "https://www.sdsos.gov/scholarships/SDOpportunityScholarship.aspx"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Tennessee
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Tennessee',
    'TN',
    'TNStars College Savings 529 Program',
    'The TNStars College Savings 529 Program offers families a flexible and tax-advantaged way to save for future education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Tennessee does not have a state income tax, so there are no state tax deductions for contributions."}'::jsonb,
    'https://www.tnstars.com/',
    '{"state_income_tax": "none", "child_tax_credit": "Federal child tax credit up to $2,000 per qualifying child.", "dependent_care_credit": "Federal credit available for up to 35% of qualifying expenses.", "earned_income_credit": "Federal EITC available based on income and number of children.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "CoverKids", "medicaid_expansion": true, "special_rules": "Parents must apply within 30 days of birth to ensure continuous coverage."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "TNStars offers occasional promotions with matching contributions.", "scholarships": "Tennessee Promise provides last-dollar scholarships for community college.", "other": "Tennessee HOPE Scholarship for eligible students attending in-state colleges."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is crucial. In Tennessee, parents have access to the TNStars College Savings 529 Program, which offers a tax-advantaged way to save for education. Although Tennessee does not have a state income tax, the 529 plan provides federal tax benefits, with earnings growing tax-free when used for qualified education expenses. Additionally, programs like CoverKids ensure that your child has access to healthcare coverage from birth.", "key_deadlines": ["Enroll newborn in health insurance within 30 days of birth.", "Consider opening a 529 plan as early as possible to maximize growth."], "action_items": ["Apply for a Social Security number for your newborn.", "Enroll your newborn in a health insurance plan within 30 days.", "Open a TNStars 529 College Savings account to start saving for education.", "Explore eligibility for programs like Tennessee Promise and HOPE Scholarship."], "resources": ["https://www.tnstars.com/", "https://www.tn.gov/coverkids.html", "https://www.tn.gov/collegepays/financial-aid.html", "https://www.tn.gov/tnpromise.html"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Utah
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Utah',
    'UT',
    'my529',
    'my529 is Utah''s official 529 college savings plan, offering tax-advantaged savings for education expenses. It provides a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions to my529 are eligible for a Utah state income tax credit."}'::jsonb,
    'https://my529.org',
    '{"state_income_tax": "4.85%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Up to 15% of the federal credit for child and dependent care expenses.", "earned_income_credit": "10% of the federal earned income credit for eligible taxpayers.", "unique_deductions": ["Utah Educational Savings Plan credit", "Retirement savings contributions credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Utah Children''s Health Insurance Program (CHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s health insurance plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Not available", "scholarships": "Utah offers various scholarships through the Utah System of Higher Education.", "other": "Utah Educational Savings Plan offers a state tax credit for contributions."}'::jsonb,
    '{"overview": "Planning for a baby''s future in Utah involves understanding the financial tools and benefits available to new parents. Utah offers a robust 529 plan, my529, which allows parents to save for future educational expenses with tax advantages. Additionally, the state provides several tax credits and deductions that can ease the financial burden of raising a child. Health insurance coverage for newborns is also a critical consideration, with specific enrollment deadlines and automatic coverage periods to be aware of.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File for state tax credits by April 15"], "action_items": ["Open a my529 account", "Review health insurance options for newborn", "Explore state tax credits and deductions"], "resources": ["https://my529.org", "https://health.utah.gov/chip", "https://tax.utah.gov"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Vermont
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Vermont',
    'VT',
    'Vermont Higher Education Investment Plan',
    'The Vermont Higher Education Investment Plan is the state''s 529 college savings plan, offering tax-advantaged savings for education expenses. It provides a variety of investment options managed by Intuition College Savings Solutions.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Vermont state income tax, up to the specified limits."}'::jsonb,
    'https://www.vheip.org/',
    '{"state_income_tax": "3.35% - 8.75%", "child_tax_credit": "Vermont offers a state-level child tax credit of $1,000 per qualifying child under age 5.", "dependent_care_credit": "Vermont provides a dependent care credit equal to 24% of the federal credit.", "earned_income_credit": "Vermont offers a state earned income tax credit equal to 36% of the federal EITC.", "unique_deductions": ["Social Security benefits deduction", "Charitable contributions deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Dr. Dynasaur", "medicaid_expansion": true, "special_rules": "Vermont provides coverage for pregnant women and children under Dr. Dynasaur, with income-based eligibility."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "The Vermont Higher Education Investment Plan offers a matching grant program for eligible low-income families.", "scholarships": "Vermont Student Assistance Corporation (VSAC) offers various scholarships for Vermont residents.", "other": "VSAC also provides career and education counseling services."}'::jsonb,
    '{"overview": "Welcoming a new baby is a joyous occasion, and planning for their future is an important step for Vermont parents. Understanding the financial landscape can help you make informed decisions about saving for education, managing healthcare, and taking advantage of tax benefits. Vermont offers a variety of programs and incentives to support families, including the Vermont Higher Education Investment Plan for college savings, state tax credits, and healthcare programs like Dr. Dynasaur.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a Vermont 529 plan account", "Review eligibility for Dr. Dynasaur", "Claim applicable tax credits on state tax return"], "resources": ["https://www.vheip.org/", "https://www.vtvsac.org/", "https://www.greenmountaincare.org/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Virginia
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Virginia',
    'VA',
    'Virginia529',
    'Virginia529 is the official 529 college savings plan for the state of Virginia, offering tax-advantaged savings options for education expenses. The plan provides flexibility with various investment options and can be used for qualified education expenses nationwide.',
    '{"state_tax_deduction": "up to $4,000 per account per year", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Unused deductions can be carried forward to future tax years until the full amount is deducted."}'::jsonb,
    'https://www.virginia529.com/',
    '{"state_income_tax": "2% to 5.75%", "child_tax_credit": "Up to $500 per qualifying child", "dependent_care_credit": "20% to 35% of qualifying expenses, up to $3,000 for one child or $6,000 for two or more children", "earned_income_credit": "20% of the federal EITC, non-refundable", "unique_deductions": ["529 plan contributions", "Virginia Education Savings Trust contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "FAMIS (Family Access to Medical Insurance Security)", "medicaid_expansion": true, "special_rules": "Virginia provides automatic coverage for newborns under the mother''s health plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Virginia529 Prepaid", "matching_grants": "Virginia529 offers a scholarship program for eligible low-income families.", "scholarships": "Virginia529 offers scholarships through its SOAR Virginia program for high school students.", "other": "Virginia529 also offers the Invest529 program with various investment options."}'::jsonb,
    '{"overview": "Planning for a new baby in Virginia involves understanding the financial resources and benefits available to support your child''s future. Virginia offers a robust 529 plan, Virginia529, which provides tax advantages for saving for education expenses. Additionally, the state provides various tax credits and deductions to ease the financial burden on families. Health insurance coverage for newborns is crucial, and Virginia has specific rules to ensure your child is covered from birth.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth", "Consider opening a Virginia529 account as early as possible"], "action_items": ["Review and enroll in a health insurance plan for your newborn", "Open a Virginia529 account to start saving for education", "Explore eligibility for state tax credits and deductions"], "resources": ["https://www.virginia529.com/", "https://www.coverva.org/", "https://www.tax.virginia.gov/individual-income-tax"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Washington
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Washington',
    'WA',
    'DreamAhead College Investment Plan',
    'The DreamAhead College Investment Plan is Washington''s 529 college savings plan, offering a variety of investment options to help families save for future education expenses. It provides flexibility in contributions and withdrawals for qualified education expenses.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Washington does not have a state income tax, so there are no state tax deductions for contributions."}'::jsonb,
    'https://wastate529.wa.gov/dreamahead',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines, up to $2,000 per qualifying child.", "dependent_care_credit": "Follows federal guidelines, up to $3,000 for one child or $6,000 for two or more children.", "earned_income_credit": "Follows federal guidelines, varies based on income and number of children.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Apple Health for Kids", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered for 30 days under the mother''s plan."}'::jsonb,
    '{"prepaid_plan": "GET (Guaranteed Education Tuition) Program", "matching_grants": "No state matching grants available.", "scholarships": "The Washington College Grant provides financial aid to eligible students.", "other": "Washington offers the College Bound Scholarship for eligible low-income students."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future is an important step for new parents in Washington. Understanding the financial tools and resources available can help you prepare for your child''s education and healthcare needs. Washington offers the DreamAhead College Investment Plan, a flexible 529 savings plan, and the GET Program, a prepaid tuition plan, to help families save for college. Additionally, the state provides various healthcare programs to ensure your child is covered from birth.", "key_deadlines": ["Enroll newborns in health insurance within 60 days of birth.", "Consider opening a 529 plan as early as possible to maximize savings."], "action_items": ["Research and choose between the DreamAhead 529 Plan and the GET Program.", "Enroll your newborn in a health insurance plan within the 60-day window.", "Explore eligibility for the Washington College Grant and College Bound Scholarship."], "resources": ["https://wastate529.wa.gov/", "https://www.hca.wa.gov/health-care-services-supports/apple-health-medicaid-coverage", "https://wsac.wa.gov/college-bound"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- West Virginia
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'West Virginia',
    'WV',
    'SMART529 WV Direct College Savings Plan',
    'The SMART529 WV Direct College Savings Plan is a tax-advantaged savings plan designed to help families save for future education expenses. It offers a variety of investment options and is managed by The Hartford Financial Services Group, Inc.',
    '{"state_tax_deduction": "up to $5,000 per year per account holder", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible in the year they are made, and earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.smart529.com',
    '{"state_income_tax": "3% to 6.5%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child", "dependent_care_credit": "20% to 35% of qualifying expenses, following federal rules", "earned_income_credit": "Follows federal guidelines; up to 20% of the federal EITC", "unique_deductions": ["Deduction for contributions to WV 529 plans", "Deduction for Social Security benefits"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "West Virginia Children''s Health Insurance Program (WVCHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s policy for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "Occasional promotions may offer matching contributions for new accounts", "scholarships": "Various state-sponsored scholarships available for residents", "other": "West Virginia Invests Grant covers tuition and fees for certain certificate and associate degree programs"}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In West Virginia, parents can take advantage of several state-specific programs and tax benefits to help manage the costs of raising a child. The SMART529 WV Direct College Savings Plan offers a tax-advantaged way to save for future education expenses. Additionally, West Virginia provides a range of tax credits and deductions that can ease the financial burden on families. Understanding these benefits and planning accordingly can help ensure a secure financial future for your child.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to a 529 plan by December 31 for tax benefits"], "action_items": ["Open a SMART529 account and start contributing", "Review eligibility for WVCHIP and Medicaid", "Explore available scholarships and grants"], "resources": ["https://www.smart529.com", "https://www.wvchip.org", "https://www.wvinvests.org"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Wisconsin
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Wisconsin',
    'WI',
    'Edvest College Savings Plan',
    'The Edvest College Savings Plan is Wisconsin''s official 529 college savings plan, offering tax-advantaged savings options for education expenses. It provides a range of investment options managed by TIAA-CREF, designed to help families save for future education costs.',
    '{"state_tax_deduction": "up to $3,860 per beneficiary", "deduction_amount_single": 3860, "deduction_amount_married": 7720, "earnings_tax_free": true, "notes": "Contributions are deductible from Wisconsin state income tax up to the stated limits per beneficiary."}'::jsonb,
    'https://www.edvest.com/',
    '{"state_income_tax": "3.54% - 7.65%", "child_tax_credit": "Wisconsin does not have a state-specific child tax credit, but federal credits apply.", "dependent_care_credit": "Up to 50% of the federal credit, non-refundable.", "earned_income_credit": "A percentage of the federal EITC, ranging from 4% to 34% depending on the number of children.", "unique_deductions": ["Tuition and fee deduction", "Wisconsin Homestead Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "BadgerCare Plus", "medicaid_expansion": true, "special_rules": "BadgerCare Plus covers children up to 300% of the federal poverty level."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "Edvest occasionally offers promotions with matching contributions for new accounts.", "scholarships": "Wisconsin offers various state scholarships, such as the Wisconsin Grant for low-income students.", "other": "Wisconsin residents can benefit from the Wisconsin Covenant, which provides support for students who meet certain academic and community service criteria."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their financial future is an important step for Wisconsin parents. From saving for college with the Edvest 529 Plan to understanding state tax benefits, there are many resources available to help manage the costs of raising a child. Additionally, Wisconsin offers health coverage options through BadgerCare Plus, ensuring that your child has access to necessary healthcare services.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Contribute to Edvest by December 31 for tax benefits"], "action_items": ["Open an Edvest 529 account", "Review health insurance options", "Explore state tax benefits and credits"], "resources": ["https://www.edvest.com/", "https://www.dhs.wisconsin.gov/badgercareplus/", "https://www.revenue.wi.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Wyoming
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Wyoming',
    'WY',
    'CollegeInvest Direct Portfolio College Savings Plan',
    'The CollegeInvest Direct Portfolio College Savings Plan offers a range of investment options managed by Vanguard and is designed to help families save for future education expenses. It provides flexibility in contributions and tax advantages for growth.',
    '{"state_tax_deduction": false, "deduction_amount_single": 0, "deduction_amount_married": 0, "earnings_tax_free": true, "notes": "Wyoming does not offer a state income tax deduction for contributions to 529 plans."}'::jsonb,
    'https://www.collegeinvest.org/',
    '{"state_income_tax": "none", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Follows federal guidelines; up to 35% of qualifying expenses.", "earned_income_credit": "Wyoming does not have a state EIC; follows federal EIC guidelines.", "unique_deductions": []}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Kid Care CHIP", "medicaid_expansion": false, "special_rules": "Wyoming has not expanded Medicaid under the ACA."}'::jsonb,
    '{"prepaid_plan": "None available", "matching_grants": "No state matching grants available for 529 plans.", "scholarships": "Wyoming Hathaway Scholarship Program provides merit-based scholarships for Wyoming students attending the University of Wyoming or Wyoming community colleges.", "other": "Wyoming offers the Hathaway Scholarship, which is a unique benefit for residents."}'::jsonb,
    '{"overview": "As new parents in Wyoming, planning for your child''s future education and financial security is crucial. While Wyoming does not have a state income tax, it offers unique opportunities like the Hathaway Scholarship Program for higher education. Additionally, the CollegeInvest Direct Portfolio College Savings Plan allows you to save for college with tax-free growth on earnings. Understanding your insurance options, such as enrolling your newborn in health coverage within 60 days, is also important.", "key_deadlines": ["Enroll newborn in health insurance within 60 days of birth.", "Consider opening a 529 plan as early as possible to maximize growth potential."], "action_items": ["Research and consider opening a CollegeInvest 529 plan.", "Ensure your newborn is added to your health insurance plan within 60 days.", "Explore the Hathaway Scholarship Program for future educational planning."], "resources": ["https://www.collegeinvest.org/", "https://health.wyo.gov/healthcarefin/chip/", "https://edu.wyoming.gov/beyond-the-classroom/college-career/hathaway-scholarship-program/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

