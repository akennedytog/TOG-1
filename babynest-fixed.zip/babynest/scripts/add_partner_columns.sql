-- Add partner columns to profiles table

ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS has_partner BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS partner_name TEXT,
ADD COLUMN IF NOT EXISTS partner_email TEXT;

-- Create partner_invites table for tracking
CREATE TABLE IF NOT EXISTS partner_invites (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  inviting_user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  partner_email TEXT NOT NULL,
  partner_name TEXT,
  invite_token TEXT UNIQUE,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'expired')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  accepted_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS on partner_invites
ALTER TABLE partner_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own partner invites" ON partner_invites 
  FOR SELECT USING (auth.uid() = inviting_user_id);

CREATE POLICY "Users can create partner invites" ON partner_invites 
  FOR INSERT WITH CHECK (auth.uid() = inviting_user_id);

SELECT 'Partner columns added successfully!' as status;
