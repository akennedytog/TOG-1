-- BabyNest Complete Database Setup
-- Run this in Supabase SQL Editor

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- TABLES
-- ============================================

-- Users table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  state VARCHAR(2),
  due_date DATE,
  income_bracket VARCHAR(50),
  family_size INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- States content table
CREATE TABLE IF NOT EXISTS states (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  abbreviation VARCHAR(2) NOT NULL UNIQUE,
  plan_529_name TEXT,
  plan_529_description TEXT,
  plan_529_tax_benefits JSONB,
  plan_529_link TEXT,
  tax_benefits JSONB,
  insurance_rules JSONB,
  unique_programs JSONB,
  content JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  due_date DATE,
  category VARCHAR(50) NOT NULL CHECK (category IN ('insurance', '529', 'tax', 'legal', 'general')),
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'overdue')),
  priority VARCHAR(10) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  state_specific BOOLEAN DEFAULT FALSE,
  state VARCHAR(2),
  estimated_time INTEGER,
  completion_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Documents table
CREATE TABLE IF NOT EXISTS documents (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL CHECK (type IN ('insurance_card', 'birth_certificate', 'ssn', 'tax_document', 'other')),
  filename TEXT NOT NULL,
  url TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  metadata JSONB,
  ocr_data JSONB,
  extracted_info JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversations (AI chat history)
CREATE TABLE IF NOT EXISTS conversations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  messages JSONB NOT NULL DEFAULT '[]',
  summary TEXT,
  category VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  status VARCHAR(20) DEFAULT 'incomplete' CHECK (status IN ('incomplete', 'active', 'canceled', 'past_due')),
  price_id TEXT,
  current_period_start TIMESTAMP WITH TIME ZONE,
  current_period_end TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Waitlist table
CREATE TABLE IF NOT EXISTS waitlist (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  state VARCHAR(2),
  due_date DATE,
  source VARCHAR(50),
  notes TEXT,
  contacted BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insurance card OCR cache
CREATE TABLE IF NOT EXISTS insurance_cards (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
  provider TEXT,
  member_id TEXT,
  group_number TEXT,
  plan_type TEXT,
  plan_name TEXT,
  coverage_details JSONB,
  explanation TEXT,
  confidence_score FLOAT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE insurance_cards ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can only see their own profile
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Tasks: Users can CRUD their own tasks
DROP POLICY IF EXISTS "Users can CRUD own tasks" ON tasks;
CREATE POLICY "Users can CRUD own tasks"
  ON tasks FOR ALL
  USING (auth.uid() = user_id);

-- Documents: Users can CRUD their own documents
DROP POLICY IF EXISTS "Users can CRUD own documents" ON documents;
CREATE POLICY "Users can CRUD own documents"
  ON documents FOR ALL
  USING (auth.uid() = user_id);

-- Conversations: Users can CRUD their own conversations
DROP POLICY IF EXISTS "Users can CRUD own conversations" ON conversations;
CREATE POLICY "Users can CRUD own conversations"
  ON conversations FOR ALL
  USING (auth.uid() = user_id);

-- Subscriptions: Users can view own subscription
DROP POLICY IF EXISTS "Users can view own subscription" ON subscriptions;
CREATE POLICY "Users can view own subscription"
  ON subscriptions FOR SELECT
  USING (auth.uid() = user_id);

-- Insurance cards: Users can CRUD their own
DROP POLICY IF EXISTS "Users can CRUD own insurance cards" ON insurance_cards;
CREATE POLICY "Users can CRUD own insurance cards"
  ON insurance_cards FOR ALL
  USING (auth.uid() = user_id);

-- States is public read-only
DROP POLICY IF EXISTS "States are public" ON states;
CREATE POLICY "States are public"
  ON states FOR SELECT
  TO PUBLIC
  USING (true);

-- Waitlist is insert-only for public
DROP POLICY IF EXISTS "Anyone can join waitlist" ON waitlist;
CREATE POLICY "Anyone can join waitlist"
  ON waitlist FOR INSERT
  TO PUBLIC
  WITH CHECK (true);

-- ============================================
-- FUNCTIONS
-- ============================================

-- Update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_tasks_updated_at ON tasks;
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_states_updated_at ON states;
CREATE TRIGGER update_states_updated_at BEFORE UPDATE ON states
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_conversations_updated_at ON conversations;
CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_subscriptions_updated_at ON subscriptions;
CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- SAMPLE DATA - Top 5 States
-- ============================================

-- Insert sample states data
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content) 
VALUES 
('Florida', 'FL', 'Sage Scholars Florida 529 Savings Plan', 'Floridas direct-sold 529 plan with low fees and multiple investment options.', '{"state_tax_deduction": false, "no_state_income_tax": true, "earnings_tax_free": true}'::jsonb, 'https://www.florida529plans.com/', '{"no_state_income_tax": true, "homestead_exemption": true, "no_inheritance_tax": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "chip_program": "Florida KidCare"}'::jsonb, '{"prepaid_plan": "Florida Prepaid College Plan", "enrollment_window": "October_to_January"}'::jsonb, '{"overview": "Florida offers unique advantages for new parents. With no state income tax, you keep more of your earnings.", "key_deadlines": ["60 days after birth: Add baby to health insurance", "October-January: Florida Prepaid enrollment window"], "action_items": ["Contact HR within 60 days of birth", "Research Florida Prepaid vs Sage Scholars 529"], "resources": ["https://www.florida529plans.com/"]}'::jsonb),

('California', 'CA', 'ScholarShare 529', 'Californias direct-sold 529 plan managed by TIAA.', '{"state_tax_deduction": false, "earnings_tax_free": true}'::jsonb, 'https://www.scholarshare529.com/', '{"california_earned_income_tax_credit": true, "young_child_tax_credit": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "covered_california": true}'::jsonb, '{"calkids": "Up to $1500 for children born after July 2023"}'::jsonb, '{"overview": "California offers strong benefits including CalKIDS and Paid Family Leave.", "key_deadlines": ["60 days after birth: Add baby to insurance", "90 days: CalKIDS account created"], "action_items": ["Claim CalKIDS account", "Apply for Paid Family Leave"], "resources": ["https://www.scholarshare529.com/"]}'::jsonb),

('Texas', 'TX', 'Texas College Savings Plan', 'Texans can choose from multiple 529 plans.', '{"state_tax_deduction": false, "no_state_income_tax": true, "earnings_tax_free": true}'::jsonb, 'https://www.texas.gov/', '{"no_state_income_tax": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "chip_program": "CHIP"}'::jsonb, '{"texas_tuition_promise_fund": "Prepaid tuition plan available"}'::jsonb, '{"overview": "Texas has no state income tax. Texas Tuition Promise Fund locks in tuition rates.", "key_deadlines": ["60 days: Add baby to insurance", "Sep 1-Feb 28: Tuition Promise Fund enrollment"], "action_items": ["Apply for SSN", "Research Tuition Promise Fund"], "resources": ["https://www.texastuitionpromise.org/"]}'::jsonb),

('New York', 'NY', 'New Yorks 529 College Savings Program', 'Direct-sold and advisor-sold options with state tax deduction.', '{"state_tax_deduction": {"amount": 5000, "married_amount": 10000}, "earnings_tax_free": true}'::jsonb, 'https://www.nysaves.org/', '{"earned_income_credit": true, "child_and_dependent_care_credit": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "ny_state_of_health": true}'::jsonb, '{"529_direct": "Direct plan with tax deduction", "529_advisor": "Advisor-guided option"}'::jsonb, '{"overview": "NY offers generous 529 tax deduction up to $10,000 for married couples.", "key_deadlines": ["Dec 31: 529 contribution deadline", "60 days: Insurance enrollment"], "action_items": ["Open NY 529 account", "Apply for Empire State Child Credit"], "resources": ["https://www.nysaves.org/"]}'::jsonb),

('Illinois', 'IL', 'Bright Start 529', 'Illinois offers both direct-sold and advisor-sold 529 plans.', '{"state_tax_deduction": {"amount": 10000, "married_amount": 20000}, "earnings_tax_free": true}'::jsonb, 'https://www.brightstartsavings.com/', '{"earned_income_credit": true, "property_tax_credit": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "chip_program": "All Kids"}'::jsonb, '{"bright_directions": "Advisor-sold option available"}'::jsonb, '{"overview": "Illinois allows 529 deduction for ANY states plan, up to $20,000 for married couples.", "key_deadlines": ["Dec 31: 529 contribution deadline", "60 days: Insurance enrollment"], "action_items": ["Open any states 529 for IL deduction", "Apply for All Kids if eligible"], "resources": ["https://www.brightstartsavings.com/"]}'::jsonb)
ON CONFLICT (abbreviation) DO NOTHING;

-- Insert sample tasks for Florida
INSERT INTO tasks (title, description, category, priority, state_specific, state, estimated_time) 
VALUES
('Add baby to health insurance', 'Contact your insurance provider within 60 days of birth to add your newborn. Required documents: birth certificate, SSN (or application proof). Most plans cover newborns automatically for first 30 days.', 'insurance', 'urgent', true, 'FL', 30),
('Set up Florida 529 plan', 'Open a Sage Scholars 529 account. Florida has no state income tax so no state deduction, but earnings grow tax-free. Consider Florida Prepaid for tuition lock-in (enrollment Oct-Jan).', '529', 'high', true, 'FL', 45),
('Apply for Florida KidCare', 'Check eligibility for Florida KidCare (CHIP) for low-cost health coverage. Income limits vary by family size. Can supplement private insurance.', 'insurance', 'medium', true, 'FL', 20),
('Update tax withholding', 'Add new dependent to your W-4. Child tax credit may reduce withholding. Consider adjusting for additional child tax credit if eligible.', 'tax', 'medium', false, NULL, 15),
('Create or update will', 'Name guardians for your child. Florida requires specific formalities. Consider trust to manage assets until child is mature.', 'legal', 'high', true, 'FL', 60),
('Apply for SSN', 'Apply for baby Social Security number. Hospital may help with paperwork, or apply at SSA.gov. Required for tax purposes and many accounts.', 'general', 'high', false, NULL, 30),
('Open custodial account (UTMA)', 'Consider UTMA account for non-education savings. Assets transfer to child at 18 in Florida. First $1,250 of unearned income is tax-free.', '529', 'low', true, 'FL', 30),
('Review life insurance needs', 'Calculate needed coverage: 10-12x income for primary earner. Term life recommended over whole life. Beneficiary designation updates.', 'insurance', 'medium', false, NULL, 45)
ON CONFLICT DO NOTHING;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_documents_user_id ON documents(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_states_abbreviation ON states(abbreviation);

-- ============================================
-- COMPLETE!
-- ============================================

SELECT 'Database setup complete!' as status;
SELECT COUNT(*) as states_count FROM states;
SELECT COUNT(*) as tasks_count FROM tasks;