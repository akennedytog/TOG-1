-- BabyNest State Content - Batch 4 (States 28-36)
-- States: NM, NC, ND, OH, OK, OR, PA, RI, SC
-- Run this in Supabase SQL Editor

-- New Mexico
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'New Mexico',
    'NM',
    'The Education Plan',
    'The Education Plan is New Mexico''s 529 college savings plan, designed to help families save for future education expenses. It offers tax advantages and a variety of investment options to fit different risk preferences.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from New Mexico state income tax."}'::jsonb,
    'https://www.theeducationplan.com/',
    '{"state_income_tax": "1.7% - 5.9%", "child_tax_credit": "Follows federal guidelines, no additional state credit", "dependent_care_credit": "Up to 40% of the federal credit", "earned_income_credit": "10% of the federal EITC", "unique_deductions": ["529 plan contributions", "Medical care expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "New MexiKids", "medicaid_expansion": true, "special_rules": "Newborns are covered under the mother''s Medicaid for the first year if the mother was on Medicaid at the time of birth."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None", "scholarships": "The New Mexico Legislative Lottery Scholarship provides tuition assistance to New Mexico residents.", "other": "New Mexico offers the Bridge to Success Scholarship for students transitioning from high school to college."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In New Mexico, parents have access to various programs and tax benefits that can help ease the financial burden of raising a child. From the state''s 529 college savings plan to tax credits and health insurance options, there are many resources available to support your family''s financial planning.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Consider opening a 529 plan as early as possible"], "action_items": ["Review and update your health insurance policy", "Open a 529 college savings account", "Explore eligibility for state tax credits and deductions"], "resources": ["https://www.theeducationplan.com/", "https://www.yes.state.nm.us/", "https://www.nmlegis.gov/", "https://www.bewellnm.com/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- North Carolina
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'North Carolina',
    'NC',
    'NC 529 Plan',
    'The NC 529 Plan is North Carolina''s tax-advantaged college savings plan, designed to help families save for future education expenses. It offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": false, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are not deductible on North Carolina state taxes, but earnings grow tax-free if used for qualified education expenses."}'::jsonb,
    'https://www.cfnc.org/save-for-college/nc-529-plan/',
    '{"state_income_tax": "4.75%", "child_tax_credit": "North Carolina does not have a state-specific child tax credit, but federal credits apply.", "dependent_care_credit": "North Carolina offers a state credit of up to 7% of eligible expenses, depending on income.", "earned_income_credit": "North Carolina does not offer a state EITC, but federal EITC is available.", "unique_deductions": ["529 plan earnings tax-free", "Child and Dependent Care Credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "NC Health Choice", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "No state matching grants available.", "scholarships": "The North Carolina Education Lottery Scholarship is available for eligible students attending a UNC System university.", "other": "North Carolina offers the NC Promise Tuition Plan, which reduces tuition costs at select universities."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, but it also comes with financial responsibilities. In North Carolina, parents can take advantage of various programs and tax benefits to ease the financial burden of raising a child. The NC 529 Plan is a flexible and tax-advantaged way to save for your child''s future education expenses. Additionally, understanding state tax benefits and insurance rules can help you plan effectively.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Consider opening a 529 plan early to maximize savings"], "action_items": ["Open an NC 529 Plan account", "Review health insurance options for your newborn", "Explore eligibility for NC Health Choice"], "resources": ["https://www.cfnc.org", "https://www.ncdhhs.gov", "https://www.nclottery.com/Education"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- North Dakota
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'North Dakota',
    'ND',
    'College SAVE',
    'College SAVE is North Dakota''s 529 college savings plan, designed to help families save for future education expenses. The plan offers tax advantages and a variety of investment options to suit different risk preferences.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from North Dakota state income tax, and earnings grow tax-free when used for qualified education expenses."}'::jsonb,
    'https://www.collegesave4u.com/',
    '{"state_income_tax": "1.10% - 2.90%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "20% of the federal credit", "earned_income_credit": "10% of the federal credit", "unique_deductions": ["529 plan contributions", "medical expenses exceeding 7.5% of AGI"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Healthy Steps", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "The College SAVE plan offers a matching grant for eligible families, providing up to $300 in matching funds.", "scholarships": "The College SAVE plan offers scholarships through the BND Match Program for qualifying families.", "other": "The College SAVE plan provides a $25 initial contribution for new accounts opened for babies under one year old."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is a joyous occasion, but it also comes with financial responsibilities. In North Dakota, parents can take advantage of several financial planning tools to prepare for their child''s future. From the College SAVE 529 plan to state-specific tax benefits, there are numerous ways to save for education and manage the costs of raising a child. Understanding insurance rules and available state programs can also help ensure your child is covered and your family is financially secure.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Open a College SAVE account early to maximize benefits"], "action_items": ["Set up a College SAVE 529 plan", "Review health insurance coverage options", "Explore eligibility for CHIP and Medicaid"], "resources": ["https://www.collegesave4u.com/", "https://www.nd.gov/dhs/services/medicalserv/chip/", "https://www.nd.gov/dhs/services/financialhelp/eitc.html"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Ohio
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Ohio',
    'OH',
    'CollegeAdvantage 529 Savings Plan',
    'The CollegeAdvantage 529 Savings Plan is Ohio''s tax-advantaged college savings plan, offering a variety of investment options to help families save for higher education expenses. Contributions grow tax-free, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $4,000 per beneficiary, per year", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions over $4,000 per beneficiary can be carried forward to future years."}'::jsonb,
    'https://www.collegeadvantage.com/',
    '{"state_income_tax": "2.765% - 3.99%", "child_tax_credit": "Up to $2,000 per qualifying child under federal guidelines", "dependent_care_credit": "Up to 25% of the federal credit, depending on income", "earned_income_credit": "10% of the federal credit", "unique_deductions": ["Adoption credit", "Disability income exclusion"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "Healthy Start", "medicaid_expansion": true, "special_rules": "Ohio allows retroactive Medicaid coverage for up to 3 months prior to application if eligible."}'::jsonb,
    '{"prepaid_plan": "Ohio Tuition Trust Authority Prepaid Plan", "matching_grants": "CollegeAdvantage offers periodic matching grants and promotions.", "scholarships": "Ohio offers various state-funded scholarships for residents attending in-state colleges.", "other": "Ohio offers a variety of state-specific education grants and financial aid programs."}'::jsonb,
    '{"overview": "Planning for a new baby in Ohio involves understanding the financial benefits and programs available to support your child''s future. Ohio offers several tax advantages and savings plans, such as the CollegeAdvantage 529 Savings Plan, which provides tax-free growth and withdrawals for education expenses. Additionally, Ohio''s Medicaid and CHIP programs ensure that healthcare is accessible to all families, providing peace of mind for new parents.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File for state tax deductions by April 15"], "action_items": ["Open a CollegeAdvantage 529 Savings Plan", "Enroll your newborn in health insurance", "Explore Ohio''s Medicaid and CHIP programs"], "resources": ["https://www.collegeadvantage.com/", "https://medicaid.ohio.gov/", "https://www.benefits.gov/benefit/1608"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Oklahoma
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Oklahoma',
    'OK',
    'Oklahoma 529 College Savings Plan',
    'The Oklahoma 529 College Savings Plan is designed to help families save for future education expenses with tax advantages. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "up to $10,000", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions above the annual limit can be carried forward for up to five years."}'::jsonb,
    'https://www.ok4saving.org/',
    '{"state_income_tax": "0.25% to 4.75%", "child_tax_credit": "Oklahoma does not offer a state-specific child tax credit, but federal credits apply.", "dependent_care_credit": "Oklahoma offers a percentage of the federal credit for child and dependent care expenses.", "earned_income_credit": "Oklahoma provides a refundable Earned Income Credit equal to 5% of the federal credit.", "unique_deductions": ["529 plan contributions", "adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "SoonerCare", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s SoonerCare plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Oklahoma does not currently offer a prepaid tuition plan.", "matching_grants": "Oklahoma does not offer matching grants for 529 contributions.", "scholarships": "Oklahoma''s Promise offers scholarships for students from low-income families who meet academic and conduct requirements.", "other": "The Oklahoma Tuition Equalization Grant Program provides grants to students attending private colleges."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their financial future is an important step. In Oklahoma, parents have access to a variety of financial benefits and programs to help ease the cost of raising a child. From the Oklahoma 529 College Savings Plan to state tax benefits, there are many ways to save for your child''s education and future expenses. Additionally, health insurance programs like SoonerCare ensure that your child has access to necessary medical care.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "Annual tax filing deadlines for state deductions"], "action_items": ["Open an Oklahoma 529 College Savings Plan account", "Review eligibility for SoonerCare", "Explore Oklahoma''s Promise scholarship program"], "resources": ["https://www.ok4saving.org/", "https://www.oklahoma.gov/ohca/individuals/programs/soonercare.html", "https://www.okhighered.org/okpromise/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Oregon
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Oregon',
    'OR',
    'Oregon College Savings Plan',
    'The Oregon College Savings Plan offers a tax-advantaged way to save for education expenses. It provides flexibility in investment options and can be used at schools nationwide. Contributions grow tax-deferred, and withdrawals for qualified education expenses are tax-free.',
    '{"state_tax_deduction": "amount or false", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Oregon state income tax up to the specified limits."}'::jsonb,
    'https://www.oregoncollegesavings.com/',
    '{"state_income_tax": "4.75% to 9.9%", "child_tax_credit": "Follows federal guidelines, up to $2,000 per qualifying child.", "dependent_care_credit": "Up to 30% of qualifying expenses, based on income.", "earned_income_credit": "8% of the federal EITC amount.", "unique_deductions": ["Oregon Cultural Trust contribution", "Political contribution credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Oregon Health Plan (OHP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "Oregon does not currently offer matching grants for 529 contributions.", "scholarships": "The Oregon Promise Grant provides funding for recent high school graduates and GED recipients to attend community college.", "other": "The Oregon Opportunity Grant is the state''s largest need-based grant program for college students."}'::jsonb,
    '{"overview": "Welcoming a new baby is an exciting time, and planning for their future education is an important step. In Oregon, parents can take advantage of the Oregon College Savings Plan, which offers tax benefits and flexible investment options to save for future education expenses. Additionally, understanding the state''s tax benefits and insurance rules can help parents manage costs effectively.", "key_deadlines": ["Enroll newborn in health insurance within 60 days", "File state taxes by April 15"], "action_items": ["Open an Oregon College Savings Plan account", "Review health insurance coverage for newborn", "Explore state tax credits and deductions"], "resources": ["https://www.oregoncollegesavings.com/", "https://www.oregon.gov/dor/", "https://www.oregon.gov/oha/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Pennsylvania
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Pennsylvania',
    'PA',
    'Pennsylvania 529 Investment Plan',
    'The Pennsylvania 529 Investment Plan (IP) offers families a flexible and tax-advantaged way to save for education expenses. Contributions grow tax-free, and withdrawals are tax-free when used for qualified education expenses.',
    '{"state_tax_deduction": "up to $15,000 per beneficiary per year", "deduction_amount_single": 15000, "deduction_amount_married": 30000, "earnings_tax_free": true, "notes": "Contributions are deductible from Pennsylvania state income tax, up to the annual limit per beneficiary."}'::jsonb,
    'https://www.pa529.com/',
    '{"state_income_tax": "3.07%", "child_tax_credit": "Follows federal guidelines; no additional state credit", "dependent_care_credit": "Follows federal guidelines; no additional state credit", "earned_income_credit": "None", "unique_deductions": ["529 plan contributions", "Medical savings account contributions"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days", "chip_program": "Pennsylvania Children''s Health Insurance Program (CHIP)", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s insurance for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "PA 529 Guaranteed Savings Plan", "matching_grants": "The Keystone Scholars program provides a $100 starter deposit for every baby born to or adopted by a Pennsylvania family after December 31, 2018.", "scholarships": "The PATH program offers scholarships to students who demonstrate financial need.", "other": "Pennsylvania offers the Keystone Scholars program to encourage early savings for education."}'::jsonb,
    '{"overview": "Planning for a new baby in Pennsylvania involves understanding the financial resources and benefits available to families. The Pennsylvania 529 Investment Plan provides a tax-advantaged way to save for future education expenses, with significant state tax deductions available. Additionally, the state offers health insurance programs like CHIP to ensure children have access to necessary healthcare. By taking advantage of these programs and understanding key deadlines, parents can better prepare for the financial responsibilities of raising a child.", "key_deadlines": ["Enroll newborn in health insurance within 30 days", "Contribute to 529 plan by December 31 for tax benefits"], "action_items": ["Open a Pennsylvania 529 Investment Plan account", "Enroll newborn in health insurance", "Explore CHIP and Medicaid options if eligible"], "resources": ["https://www.pa529.com/", "https://www.chipcoverspakids.com/", "https://www.dhs.pa.gov/Services/Assistance/Pages/Medicaid.aspx"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Rhode Island
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Rhode Island',
    'RI',
    'CollegeBound Saver',
    'CollegeBound Saver is Rhode Island''s 529 college savings plan, designed to help families save for future education expenses. The plan offers a variety of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "amount", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from Rhode Island state income tax, subject to limits."}'::jsonb,
    'https://www.collegeboundsaver.com/',
    '{"state_income_tax": "3.75% - 5.99%", "child_tax_credit": "Rhode Island does not offer a state-specific child tax credit.", "dependent_care_credit": "Rhode Island offers a state credit based on a percentage of the federal credit.", "earned_income_credit": "Rhode Island offers a refundable earned income credit equal to 15% of the federal EITC.", "unique_deductions": ["529 plan contributions", "medical expenses exceeding 10% of AGI"]}'::jsonb,
    '{"newborn_enrollment_deadline": "30 days", "automatic_coverage_period": "30 days of automatic coverage", "chip_program": "RIte Care", "medicaid_expansion": true, "special_rules": "Newborns are covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Rhode Island does not currently offer matching grants for 529 contributions.", "scholarships": "The Rhode Island Promise Scholarship provides two years of free tuition at the Community College of Rhode Island for eligible students.", "other": "The state offers various financial aid programs for higher education through the Rhode Island Student Loan Authority."}'::jsonb,
    '{"overview": "Raising a child in Rhode Island involves careful financial planning, especially when considering future education expenses. The CollegeBound Saver 529 plan offers a tax-advantaged way to save for college, with state tax deductions available for contributions. Additionally, Rhode Island provides several tax benefits and credits that can help reduce the financial burden on families. Understanding the state''s insurance rules and unique programs can also aid in securing your child''s future.", "key_deadlines": ["30 days to enroll newborn in health insurance", "April 15th for state tax deductions"], "action_items": ["Open a CollegeBound Saver 529 account", "Review eligibility for RIte Care", "Apply for the Rhode Island Promise Scholarship if applicable"], "resources": ["https://www.collegeboundsaver.com/", "https://healthsourceri.com/", "https://www.ri.gov/taxation/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- South Carolina
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, 
plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'South Carolina',
    'SC',
    'Future Scholar 529 College Savings Plan',
    'The Future Scholar 529 College Savings Plan is South Carolina''s tax-advantaged savings plan designed to help families save for future education expenses. It offers a range of investment options and is open to residents of any state.',
    '{"state_tax_deduction": "unlimited", "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "Contributions are deductible from South Carolina state income tax with no annual limit."}'::jsonb,
    'https://www.futurescholar.com/',
    '{"state_income_tax": "0% - 7%", "child_tax_credit": "Follows federal guidelines; up to $2,000 per qualifying child.", "dependent_care_credit": "Up to 7% of eligible expenses, based on income.", "earned_income_credit": "20.83% of the federal EITC for eligible taxpayers.", "unique_deductions": ["Contributions to the Future Scholar 529 Plan", "Adoption expenses"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Partners for Healthy Children", "medicaid_expansion": true, "special_rules": "Newborns are automatically covered under the mother''s plan for the first 30 days."}'::jsonb,
    '{"prepaid_plan": "Not available", "matching_grants": "Not available", "scholarships": "Palmetto Fellows Scholarship, LIFE Scholarship, HOPE Scholarship", "other": "Babynet early intervention program for infants and toddlers with disabilities."}'::jsonb,
    '{"overview": "Welcoming a new baby into your family is an exciting time, but it also brings new financial responsibilities. In South Carolina, parents can take advantage of various programs and tax benefits to help manage these costs. From the Future Scholar 529 College Savings Plan to state-specific tax credits, there are numerous ways to plan for your child''s future. Additionally, understanding insurance rules and deadlines is crucial to ensure your newborn''s health coverage.", "key_deadlines": ["60 days to enroll newborn in health insurance", "April 15 for state income tax filing"], "action_items": ["Open a Future Scholar 529 Plan account", "Review health insurance options for your newborn", "Explore state tax credits and deductions"], "resources": ["https://www.futurescholar.com/", "https://www.scdhhs.gov/", "https://dor.sc.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();
