#!/bin/bash
# BabyNest Deployment Script
# Run this after setting up environment variables

set -e

echo "🚀 BabyNest Deployment"
echo "======================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo -e "${RED}Error: package.json not found. Are you in the babynest directory?${NC}"
    exit 1
fi

echo ""
echo "Step 1: Installing dependencies..."
npm install

echo ""
echo "Step 2: Checking environment variables..."
if [ -f ".env.local" ]; then
    echo -e "${GREEN}✓ .env.local found${NC}"
else
    echo -e "${YELLOW}⚠ .env.local not found. Creating from template...${NC}"
    cp .env.example .env.local
    echo -e "${RED}Please fill in your API keys in .env.local before continuing${NC}"
    exit 1
fi

echo ""
echo "Step 3: Building the app..."
npm run build

echo ""
echo "Step 4: Running tests (if any)..."
# npm test

echo ""
echo "Step 5: Deploying to Vercel..."
if ! command -v vercel &> /dev/null; then
    echo "Installing Vercel CLI..."
    npm i -g vercel
fi

echo ""
read -p "Is this your first deploy? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Running initial deploy..."
    vercel
else
    echo "Running production deploy..."
    vercel --prod
fi

echo ""
echo -e "${GREEN}✓ Deployment complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Check your Vercel dashboard for the deployed URL"
echo "2. Update Supabase Auth redirect URLs with the new domain"
echo "3. Update Stripe webhook URL"
echo "4. Test the app!"
echo ""
echo "Happy deploying! 🎉"