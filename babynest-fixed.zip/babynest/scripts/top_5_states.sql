-- BabyNest State Content - Top 5 States
-- Generated: May 10, 2026
-- Run this in Supabase SQL Editor

-- Florida
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Florida',
    'FL',
    'Sage Scholars Florida 529 Savings Plan',
    'Florida''s direct-sold 529 plan offers multiple investment options with low fees. No minimum contribution required. Managed by Florida Prepaid College Board.',
    '{"state_tax_deduction": false, "no_state_income_tax": true, "earnings_tax_free": true, "notes": "Florida has no state income tax, so no state deduction. Earnings grow tax-free for qualified education expenses."}'::jsonb,
    'https://www.florida529plans.com/',
    '{"state_income_tax": "none", "child_tax_credit": "No state credit, but federal child tax credit applies", "dependent_care_credit": "No state credit", "earned_income_credit": "No state credit", "unique_deductions": ["No state income tax means no deductions needed", "Homestead exemption on property taxes"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Florida KidCare", "medicaid_expansion": false, "special_rules": "Most employer plans cover newborns automatically for first 30 days. Must notify insurer within 60 days of birth."}'::jsonb,
    '{"prepaid_plan": "Florida Prepaid College Plan", "prepaid_enrollment": "October to January only", "prepaid_details": "Lock in future tuition at today''s prices. Open enrollment is limited to specific window.", "matching_grants": "None at state level", "scholarships": "Bright Futures Scholarship available for Florida residents", "other": "Florida KidCare offers subsidized health insurance for children in working families"}'::jsonb,
    '{"overview": "Florida offers unique advantages for new parents. With no state income tax, you keep more of your earnings. The Florida Prepaid College Plan allows you to lock in tuition rates, though enrollment is only open October through January. Florida KidCare provides affordable health coverage options for children in working families.", "key_deadlines": ["60 days after birth: Add baby to health insurance", "30 days: Automatic coverage period ends for most plans", "October-January: Florida Prepaid enrollment window", "April 15: Tax filing deadline (federal only for FL residents)", "End of year: 529 contribution deadline"], "action_items": ["Contact HR or insurance provider within 30 days of birth", "Apply for baby''s SSN at hospital or SSA office", "Research Florida Prepaid vs Sage Scholars 529", "Check eligibility for Florida KidCare", "Update tax withholding with employer", "Create or update will and name guardians"], "resources": ["https://www.florida529plans.com/", "https://www.myfloridaprepaid.com/", "https://www.floridakidcare.org/", "https://www.ssa.gov/", "Florida Bar: Finding estate planning attorneys"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- California
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'California',
    'CA',
    'ScholarShare 529',
    'California''s 529 college savings plan, managed by TIAA. Offers age-based, individual fund, and socially responsible investment options.',
    '{"state_tax_deduction": false, "earnings_tax_free": true, "notes": "California does not offer state tax deduction for 529 contributions, but earnings grow tax-free for qualified expenses"}'::jsonb,
    'https://www.scholarshare529.com/',
    '{"state_income_tax": "1-13.3% progressive", "child_tax_credit": "California Young Child Tax Credit (YCTC) up to $1,000 for children under 6", "dependent_care_credit": "California Child and Dependent Care Expenses Credit", "earned_income_credit": "California Earned Income Tax Credit (CalEITC)", "unique_deductions": ["YCTC: Young Child Tax Credit for families with children under 6", "CalEITC for low-to-moderate income families", "Child and dependent care expenses credit"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Covered California", "medicaid_expansion": true, "special_rules": "California Medi-Cal expansion provides coverage to more families. Covered California offers subsidized plans."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "CalKIDS: Automatic $500-$1500 for children born after July 2023", "calKIDS_details": "California provides newborns with a CalKIDS college savings account funded with $500-$1500 automatically", "scholarships": "Cal Grant available for California residents", "other": "Paid Family Leave provides up to 8 weeks of partial pay for new parents"}'::jsonb,
    '{"overview": "California offers strong benefits for new parents including the Young Child Tax Credit (up to $1,000), CalKIDS automatic college savings ($500-$1500), and Paid Family Leave. However, California has high state income tax (up to 13.3%) and does not offer 529 tax deductions. Focus on maximizing federal benefits and state-specific credits.", "key_deadlines": ["60 days after birth: Add baby to health insurance", "90 days after birth: CalKIDS account automatically created", "April 15: Tax filing deadline", "Before return to work: Apply for Paid Family Leave", "Open enrollment: Review Covered California options"], "action_items": ["Claim CalKIDS account for your baby", "Apply for California Paid Family Leave", "Research Covered California if employer insurance is expensive", "Apply for Young Child Tax Credit on state taxes", "Set up ScholarShare 529 if desired", "Update tax withholding for additional credits"], "resources": ["https://www.scholarshare529.com/", "https://www.calkids.org/", "https://www.coveredca.com/", "https://edd.ca.gov/Disability/Paid_Family_Leave/", "https://www.ftb.ca.gov/"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Texas
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Texas',
    'TX',
    'Texas College Savings Plan',
    'Texas offers multiple 529 plan options including direct-sold and advisor-sold plans. No state tax benefits, but federal tax advantages apply.',
    '{"state_tax_deduction": false, "no_state_income_tax": true, "earnings_tax_free": true, "notes": "Texas has no state income tax, so no state deduction. Federal tax benefits still apply."}'::jsonb,
    'https://www.texas.gov/',
    '{"state_income_tax": "none", "child_tax_credit": "No state credit, but federal applies", "dependent_care_credit": "No state credit", "earned_income_credit": "No state credit", "unique_deductions": ["No state income tax", "No state property tax on certain items"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "CHIP", "medicaid_expansion": false, "special_rules": "Texas did not expand Medicaid under ACA. CHIP provides coverage for children in working families."}'::jsonb,
    '{"prepaid_plan": "Texas Tuition Promise Fund", "prepaid_details": "Lock in tuition at Texas public colleges at today''s prices", "matching_grants": "None at state level", "scholarships": "Various state scholarship programs available", "other": "CHIP provides low-cost health coverage for children in families that earn too much for Medicaid"}'::jsonb,
    '{"overview": "Texas is tax-friendly for families with no state income tax. While there''s no state 529 deduction, you can invest in any state''s plan. The Texas Tuition Promise Fund lets you lock in future tuition costs. CHIP provides health coverage for children in working families who don''t qualify for Medicaid.", "key_deadlines": ["60 days after birth: Add baby to health insurance", "30 days: Automatic coverage ends for most plans", "September 1: Texas Tuition Promise Fund enrollment opens", "February 28: Tuition Promise Fund enrollment closes", "April 15: Federal tax filing deadline"], "action_items": ["Contact insurance within 60 days of birth", "Apply for baby''s SSN", "Research Texas Tuition Promise Fund", "Check CHIP eligibility if needed", "Compare any state''s 529 plan (not limited to Texas)", "Create or update estate plan"], "resources": ["https://www.texastuitionpromise.org/", "https://www.chipmedicaid.org/", "https://www.texas.gov/", "https://www.ssa.gov/", "Texas State Bar: Estate planning resources"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- New York
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'New York',
    'NY',
    'New York''s 529 College Savings Program',
    'New York offers both Direct and Advisor-Guided 529 plans. One of the best state tax deductions in the country.',
    '{"state_tax_deduction": true, "deduction_amount_single": 5000, "deduction_amount_married": 10000, "earnings_tax_free": true, "notes": "One of the highest state tax deductions in the US. Up to $10,000 deduction for married couples filing jointly."}'::jsonb,
    'https://www.nysaves.org/',
    '{"state_income_tax": "4-10.9% progressive", "child_tax_credit": "Empire State Child Credit up to $330 per child", "dependent_care_credit": "New York Child and Dependent Care Credit", "earned_income_credit": "New York State EITC", "unique_deductions": ["529 deduction up to $10,000 (married)", "Empire State Child Credit", "College tuition credit or deduction"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "Child Health Plus", "medicaid_expansion": true, "special_rules": "New York State of Health marketplace offers comprehensive coverage options. Child Health Plus provides excellent coverage for children."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None at state level", "scholarships": "Excelsior Scholarship for NY residents attending SUNY/CUNY", "other": "529 contributions deductible up to $10,000 per year for married couples"}'::jsonb,
    '{"overview": "New York is one of the best states for college savings due to the generous 529 tax deduction (up to $10,000 for married couples). Combined with the Empire State Child Credit and other benefits, NY parents have strong financial incentives. Child Health Plus offers excellent coverage options for children.", "key_deadlines": ["60 days after birth: Add baby to health insurance", "December 31: 529 contribution deadline for tax deduction", "April 15: Tax filing deadline", "Open enrollment: Child Health Plus year-round", "Before age 1: Set up 529 to maximize tax benefits"], "action_items": ["Open NY 529 account and contribute by December 31", "Apply for Empire State Child Credit", "Research Child Health Plus as alternative to employer insurance", "Update tax withholding for child credit", "Look into Excelsior Scholarship eligibility", "Create or update will and guardianship documents"], "resources": ["https://www.nysaves.org/", "https://www.health.ny.gov/", "https://nyskidsroom.childcare.gov/", "https://www.tax.ny.gov/", "NYS Bar Association: Estate planning"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();

-- Illinois
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs, content)
VALUES (
    'Illinois',
    'IL',
    'Bright Start 529',
    'Illinois offers both Bright Start (direct-sold) and Bright Directions (advisor-sold) 529 plans. Excellent state tax benefits.',
    '{"state_tax_deduction": true, "deduction_amount_single": 10000, "deduction_amount_married": 20000, "earnings_tax_free": true, "notes": "One of the highest 529 deductions in the country: up to $20,000 for married couples."}'::jsonb,
    'https://www.brightstartsavings.com/',
    '{"state_income_tax": "4.95% flat", "child_tax_credit": "Illinois Child Tax Credit available for low-income families", "dependent_care_credit": "Illinois Child and Dependent Care Expense Credit", "earned_income_credit": "Illinois EITC", "unique_deductions": ["529 deduction up to $20,000 (married)", "Education expense deductions", "Property tax credits"]}'::jsonb,
    '{"newborn_enrollment_deadline": "60 days", "automatic_coverage_period": "30 days", "chip_program": "All Kids", "medicaid_expansion": true, "special_rules": "Illinois expanded Medicaid under ACA. All Kids provides comprehensive coverage for children."}'::jsonb,
    '{"prepaid_plan": "None", "matching_grants": "None at state level", "scholarships": "Various state scholarships available", "other": "529 deduction applies to ANY state''s 529 plan, not just Illinois"}'::jsonb,
    '{"overview": "Illinois offers exceptional 529 benefits—the deduction applies to ANY state''s 529 plan (not just Illinois), and married couples can deduct up to $20,000 per year. This flexibility makes Illinois one of the best states for college savings. All Kids provides comprehensive health coverage for Illinois children.", "key_deadlines": ["60 days after birth: Add baby to health insurance", "30 days: Automatic coverage ends", "December 31: 529 contribution deadline", "April 15: Tax filing deadline", "Year-round: All Kids enrollment"], "action_items": ["Open 529 in ANY state (Illinois allows deduction for any plan)", "Contribute up to $20,000 if married for maximum deduction", "Apply for All Kids if employer insurance is expensive", "Claim Illinois Child Tax Credit if eligible", "Update tax withholding", "Set up estate planning documents"], "resources": ["https://www.brightstartsavings.com/", "https://www.allkids.com/", "https://www2.illinois.gov/", "https://www.revenue.state.il.us/", "Illinois State Bar: Estate planning"]}'::jsonb
) ON CONFLICT (abbreviation) DO UPDATE SET
    plan_529_name = EXCLUDED.plan_529_name,
    plan_529_description = EXCLUDED.plan_529_description,
    plan_529_tax_benefits = EXCLUDED.plan_529_tax_benefits,
    plan_529_link = EXCLUDED.plan_529_link,
    tax_benefits = EXCLUDED.tax_benefits,
    insurance_rules = EXCLUDED.insurance_rules,
    unique_programs = EXCLUDED.unique_programs,
    content = EXCLUDED.content,
    updated_at = NOW();