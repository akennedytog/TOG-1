// Test script to verify trimester calculation
// Run: node test-trimester.js

function calculateTimeline(dueDateStr) {
  const due = new Date(dueDateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);
  
  const diffTime = due.getTime() - today.getTime();
  const daysUntilDue = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const weeksUntilDue = Math.floor(daysUntilDue / 7);
  
  // Calculate weeks pregnant (40 weeks total - weeks remaining)
  const weeksPregnant = Math.min(40, Math.max(0, 40 - weeksUntilDue));
  
  console.log(`\nDue date: ${dueDateStr}`);
  console.log(`Today: ${today.toDateString()}`);
  console.log(`Days until due: ${daysUntilDue}`);
  console.log(`Weeks until due: ${weeksUntilDue}`);
  console.log(`Weeks pregnant: ${weeksPregnant}`);
  
  if (daysUntilDue < 0) {
    return 'Baby has arrived!';
  } else if (weeksPregnant >= 27) {
    return `3rd Trimester - ${daysUntilDue} days to go!`;
  } else if (weeksPregnant >= 13) {
    return `2nd Trimester - ${weeksUntilDue} weeks to go`;
  } else {
    return `1st Trimester - ${weeksUntilDue} weeks to go`;
  }
}

// Test cases
console.log('=== TRIMESTER CALCULATION TESTS ===');

const today = new Date();
const in3Days = new Date(today);
in3Days.setDate(today.getDate() + 3);

const in30Days = new Date(today);
in30Days.setDate(today.getDate() + 30);

const in90Days = new Date(today);
in90Days.setDate(today.getDate() + 90);

const in180Days = new Date(today);
in180Days.setDate(today.getDate() + 180);

console.log(calculateTimeline(in3Days.toISOString().split('T')[0]));
console.log(calculateTimeline(in30Days.toISOString().split('T')[0]));
console.log(calculateTimeline(in90Days.toISOString().split('T')[0]));
console.log(calculateTimeline(in180Days.toISOString().split('T')[0]));

console.log('\n=== EXPECTED RESULTS ===');
console.log('Due in 3 days: 39 weeks pregnant = 3RD TRIMESTER');
console.log('Due in 30 days: ~35 weeks pregnant = 3RD TRIMESTER');
console.log('Due in 90 days: ~27 weeks pregnant = 3RD TRIMESTER');
console.log('Due in 180 days: ~14 weeks pregnant = 2ND TRIMESTER');