-- Create benefit_documents table to store uploaded insurance documents
CREATE TABLE IF NOT EXISTS benefit_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    document_type TEXT NOT NULL, -- medical, hospital_indemnity, life, etc.
    file_data TEXT, -- base64 encoded file or reference
    analysis JSONB, -- store the AI analysis results
    status TEXT DEFAULT 'active', -- active, archived
    uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create action_items table linked to documents
CREATE TABLE IF NOT EXISTS action_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    document_id UUID REFERENCES benefit_documents(id) ON DELETE CASCADE,
    task_text TEXT NOT NULL,
    category TEXT DEFAULT 'insurance', -- insurance, benefit, financial
    priority TEXT DEFAULT 'medium', -- low, medium, high, urgent
    status TEXT DEFAULT 'pending', -- pending, in_progress, completed
    due_date TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_benefit_docs_user_id ON benefit_documents(user_id);
CREATE INDEX IF NOT EXISTS idx_benefit_docs_type ON benefit_documents(document_type);
CREATE INDEX IF NOT EXISTS idx_action_items_user_id ON action_items(user_id);
CREATE INDEX IF NOT EXISTS idx_action_items_status ON action_items(status);
CREATE INDEX IF NOT EXISTS idx_action_items_document_id ON action_items(document_id);

-- Verify tables created
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('benefit_documents', 'action_items');
