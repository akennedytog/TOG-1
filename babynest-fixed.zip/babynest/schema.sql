-- BabyNest Database Schema
-- Run this in Supabase SQL Editor

-- Enable RLS (Row Level Security)
ALTER DATABASE postgres SET "app.jwt_secret" TO 'your-jwt-secret';

-- Users table (extends auth.users)
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  state VARCHAR(2),
  due_date DATE,
  income_bracket VARCHAR(50),
  family_size INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- States content table
CREATE TABLE states (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  abbreviation VARCHAR(2) NOT NULL UNIQUE,
  plan_529_name TEXT,
  plan_529_description TEXT,
  plan_529_tax_benefits JSONB,
  plan_529_link TEXT,
  tax_benefits JSONB,
  insurance_rules JSONB,
  unique_programs JSONB,
  content JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tasks table
CREATE TABLE tasks (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  due_date DATE,
  category VARCHAR(50) NOT NULL CHECK (category IN ('insurance', '529', 'tax', 'legal', 'general')),
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'overdue')),
  priority VARCHAR(10) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  state_specific BOOLEAN DEFAULT FALSE,
  state VARCHAR(2),
  estimated_time INTEGER, -- minutes
  completion_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Documents table
CREATE TABLE documents (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL CHECK (type IN ('insurance_card', 'birth_certificate', 'ssn', 'tax_document', 'other')),
  filename TEXT NOT NULL,
  url TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  metadata JSONB,
  ocr_data JSONB,
  extracted_info JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversations (AI chat history)
CREATE TABLE conversations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  messages JSONB NOT NULL DEFAULT '[]',
  summary TEXT,
  category VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Subscriptions table
CREATE TABLE subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  status VARCHAR(20) DEFAULT 'incomplete' CHECK (status IN ('incomplete', 'active', 'canceled', 'past_due')),
  price_id TEXT,
  current_period_start TIMESTAMP WITH TIME ZONE,
  current_period_end TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Waitlist table
CREATE TABLE waitlist (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  state VARCHAR(2),
  due_date DATE,
  source VARCHAR(50),
  notes TEXT,
  contacted BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insurance card OCR cache
CREATE TABLE insurance_cards (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
  provider TEXT,
  member_id TEXT,
  group_number TEXT,
  plan_type TEXT,
  plan_name TEXT,
  coverage_details JSONB,
  explanation TEXT,
  confidence_score FLOAT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE insurance_cards ENABLE ROW LEVEL SECURITY;

-- Action items table (from document analysis)
CREATE TABLE action_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
  task_text TEXT NOT NULL,
  category VARCHAR(50),
  priority VARCHAR(10),
  status VARCHAR(20) DEFAULT 'pending',
  due_date DATE,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

ALTER TABLE action_items ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Profiles: Users can only see their own profile
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Tasks: Users can CRUD their own tasks
CREATE POLICY "Users can CRUD own tasks"
  ON tasks FOR ALL
  USING (auth.uid() = user_id);

-- Documents: Users can CRUD their own documents
CREATE POLICY "Users can CRUD own documents"
  ON documents FOR ALL
  USING (auth.uid() = user_id);

-- Conversations: Users can CRUD their own conversations
CREATE POLICY "Users can CRUD own conversations"
  ON conversations FOR ALL
  USING (auth.uid() = user_id);

-- Subscriptions: Users can view own subscription
CREATE POLICY "Users can view own subscription"
  ON subscriptions FOR SELECT
  USING (auth.uid() = user_id);

-- Action items: Users can CRUD their own
CREATE POLICY "Users can CRUD own action items"
  ON action_items FOR ALL
  USING (auth.uid() = user_id);

-- Insurance cards: Users can CRUD their own
CREATE POLICY "Users can CRUD own insurance cards"
  ON insurance_cards FOR ALL
  USING (auth.uid() = user_id);

-- Benefit documents table
CREATE TABLE benefit_documents (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  document_type VARCHAR(50) NOT NULL,
  file_data TEXT,
  analysis JSONB,
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'archived')),
  uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE benefit_documents ENABLE ROW LEVEL SECURITY;

-- Benefit documents: Users can CRUD their own
CREATE POLICY "Users can CRUD own benefit documents"
  ON benefit_documents FOR ALL
  USING (auth.uid() = user_id);

-- Expenses table (Budget Tracker)
CREATE TABLE expenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL,
  category VARCHAR(50) NOT NULL CHECK (category IN ('medical', 'gear', 'childcare', 'diapers', 'clothing', 'toys', 'savings', 'other')),
  description TEXT,
  merchant TEXT,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  is_recurring BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- Expenses: Users can CRUD their own
CREATE POLICY "Users can CRUD own expenses"
  ON expenses FOR ALL
  USING (auth.uid() = user_id);

-- Budget settings table
CREATE TABLE budget_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  monthly_budget DECIMAL(10,2) NOT NULL DEFAULT 1000,
  alert_threshold INTEGER DEFAULT 80,
  category_budgets JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE budget_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can CRUD own budget settings"
  ON budget_settings FOR ALL
  USING (auth.uid() = user_id);

-- Trigger for expenses updated_at
CREATE TRIGGER update_expenses_updated_at BEFORE UPDATE ON expenses
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger for budget_settings updated_at
CREATE TRIGGER update_budget_settings_updated_at BEFORE UPDATE ON budget_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Index for expenses
CREATE INDEX idx_expenses_user_id ON expenses(user_id);
CREATE INDEX idx_expenses_date ON expenses(date);
CREATE INDEX idx_expenses_category ON expenses(category);

-- Savings Goals table
CREATE TABLE savings_goals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  target_amount DECIMAL(10,2) NOT NULL,
  current_amount DECIMAL(10,2) DEFAULT 0,
  target_date DATE,
  goal_type VARCHAR(50) NOT NULL CHECK (goal_type IN ('529', 'emergency', 'leave', 'medical', 'general', 'custom')),
  monthly_contribution DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE savings_goals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can CRUD own savings goals"
  ON savings_goals FOR ALL
  USING (auth.uid() = user_id);

-- Trigger for savings_goals updated_at
CREATE TRIGGER update_savings_goals_updated_at BEFORE UPDATE ON savings_goals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Index for savings goals
CREATE INDEX idx_savings_goals_user_id ON savings_goals(user_id);

-- Family Sharing Tables

-- Family members table for partner/family sharing
CREATE TABLE family_members (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  invited_email TEXT NOT NULL,
  invited_user_id UUID REFERENCES profiles(id),
  relationship VARCHAR(50), -- 'partner', 'grandparent', 'support'
  permission_level VARCHAR(20) DEFAULT 'viewer', -- 'admin', 'editor', 'viewer'
  status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'accepted', 'declined', 'removed'
  invite_token TEXT UNIQUE,
  invited_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  accepted_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Family activity log for tracking shared actions
CREATE TABLE family_activity (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  family_member_id UUID REFERENCES family_members(id),
  action_type VARCHAR(50), -- 'expense_added', 'goal_updated', 'task_completed', 'comment_added', 'document_uploaded', 'invite_sent', 'invite_accepted'
  action_details JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Comments table for expenses and goals
CREATE TABLE family_comments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  family_member_id UUID REFERENCES family_members(id),
  item_type VARCHAR(50) NOT NULL, -- 'expense', 'goal', 'task'
  item_id UUID NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Shared document vault (extends existing documents with sharing)
CREATE TABLE family_documents (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  family_member_id UUID REFERENCES family_members(id),
  document_type VARCHAR(50) NOT NULL, -- 'insurance_card', 'birth_certificate', 'ssn', 'tax_document', 'shared_note', 'other'
  title TEXT NOT NULL,
  content TEXT,
  url TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security on family tables
ALTER TABLE family_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_documents ENABLE ROW LEVEL SECURITY;

-- RLS Policies for family_members
-- Users can see family members they invited OR where they are the invited member
CREATE POLICY "Users can view family members they invited"
  ON family_members FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view family memberships they were invited to"
  ON family_members FOR SELECT
  USING (auth.uid() = invited_user_id);

CREATE POLICY "Users can insert family members"
  ON family_members FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update family members they invited"
  ON family_members FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own family membership status"
  ON family_members FOR UPDATE
  USING (auth.uid() = invited_user_id);

CREATE POLICY "Users can delete family members they invited"
  ON family_members FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for family_activity
-- Users can see activity for their own family members
CREATE POLICY "Users can view activity for family members they invited"
  ON family_activity FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM family_members fm
    WHERE fm.id = family_activity.family_member_id
    AND (fm.user_id = auth.uid() OR fm.invited_user_id = auth.uid())
  ));

CREATE POLICY "Users can insert family activity"
  ON family_activity FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for family_comments
CREATE POLICY "Users can view comments on shared items"
  ON family_comments FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM family_members fm
    WHERE fm.id = family_comments.family_member_id
    AND (fm.user_id = auth.uid() OR fm.invited_user_id = auth.uid())
    AND fm.status = 'accepted'
  ) OR user_id = auth.uid());

CREATE POLICY "Users can insert comments on shared items"
  ON family_comments FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM family_members fm
    WHERE fm.id = family_comments.family_member_id
    AND (fm.user_id = auth.uid() OR fm.invited_user_id = auth.uid())
    AND fm.status = 'accepted'
  ));

CREATE POLICY "Users can update their own comments"
  ON family_comments FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comments"
  ON family_comments FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for family_documents
CREATE POLICY "Users can view family documents"
  ON family_documents FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM family_members fm
    WHERE fm.id = family_documents.family_member_id
    AND (fm.user_id = auth.uid() OR fm.invited_user_id = auth.uid())
    AND fm.status = 'accepted'
  ) OR user_id = auth.uid());

CREATE POLICY "Users can insert family documents"
  ON family_documents FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM family_members fm
    WHERE fm.id = family_documents.family_member_id
    AND (fm.user_id = auth.uid() OR fm.invited_user_id = auth.uid())
    AND fm.status = 'accepted'
  ) OR user_id = auth.uid());

CREATE POLICY "Users can update family documents they created"
  ON family_documents FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete family documents they created"
  ON family_documents FOR DELETE
  USING (auth.uid() = user_id);

-- Indexes for family tables
CREATE INDEX idx_family_members_user_id ON family_members(user_id);
CREATE INDEX idx_family_members_invited_user_id ON family_members(invited_user_id);
CREATE INDEX idx_family_members_status ON family_members(status);
CREATE INDEX idx_family_members_token ON family_members(invite_token);
CREATE INDEX idx_family_activity_user_id ON family_activity(user_id);
CREATE INDEX idx_family_activity_family_member_id ON family_activity(family_member_id);
CREATE INDEX idx_family_activity_created_at ON family_activity(created_at);
CREATE INDEX idx_family_comments_item ON family_comments(item_type, item_id);
CREATE INDEX idx_family_documents_user_id ON family_documents(user_id);
CREATE INDEX idx_family_documents_family_member_id ON family_documents(family_member_id);

-- Triggers for updated_at timestamps
CREATE TRIGGER update_family_members_updated_at BEFORE UPDATE ON family_members
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_family_comments_updated_at BEFORE UPDATE ON family_comments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_family_documents_updated_at BEFORE UPDATE ON family_documents
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Notification preferences table
CREATE TABLE notification_preferences (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  task_reminders BOOLEAN DEFAULT TRUE,
  task_due_alerts BOOLEAN DEFAULT TRUE,
  weekly_digest BOOLEAN DEFAULT TRUE,
  daily_digest BOOLEAN DEFAULT FALSE,
  quiet_hours_start TIME DEFAULT '20:00',
  quiet_hours_end TIME DEFAULT '08:00',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;

-- Users can only view/update their own notification preferences
CREATE POLICY "Users can view own notification preferences"
  ON notification_preferences FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notification preferences"
  ON notification_preferences FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own notification preferences"
  ON notification_preferences FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Trigger for notification_preferences updated_at
CREATE TRIGGER update_notification_preferences_updated_at BEFORE UPDATE ON notification_preferences
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- States is public read-only
CREATE POLICY "States are public"
  ON states FOR SELECT
  TO PUBLIC
  USING (true);

-- Waitlist is insert-only for public
CREATE POLICY "Anyone can join waitlist"
  ON waitlist FOR INSERT
  TO PUBLIC
  WITH CHECK (true);

-- Functions

-- Update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_states_updated_at BEFORE UPDATE ON states
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_benefit_documents_updated_at BEFORE UPDATE ON benefit_documents
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert sample states data
INSERT INTO states (name, abbreviation, plan_529_name, plan_529_description, plan_529_tax_benefits, plan_529_link, tax_benefits, insurance_rules, unique_programs) VALUES
('Florida', 'FL', 'Sage Scholars Florida 529 Savings Plan', 'Floridas direct-sold 529 plan with low fees and multiple investment options.', '{"state_tax_deduction": false, "no_state_income_tax": true, "earnings_tax_free": true}'::jsonb, 'https://www.florida529plans.com/', '{"no_state_income_tax": true, "homestead_exemption": true, "no_inheritance_tax": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "chip_program": "Florida KidCare"}'::jsonb, '{"prepaid_plan": "Florida Prepaid College Plan", "enrollment_window": "October_to_January"}'::jsonb),

('California', 'CA', 'ScholarShare 529', 'Californias direct-sold 529 plan managed by TIAA.', '{"state_tax_deduction": false, "earnings_tax_free": true}'::jsonb, 'https://www.scholarshare529.com/', '{"california_earned_income_tax_credit": true, "young_child_tax_credit": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "covered_california": true}'::jsonb, '{"calkids": "Up to $1500 for children born after July 2023"}'::jsonb),

('Texas', 'TX', 'Texas College Savings Plan', 'Texans can choose from multiple 529 plans including direct-sold and advisor-sold options.', '{"state_tax_deduction": false, "no_state_income_tax": true, "earnings_tax_free": true}'::jsonb, 'https://www.texas.gov/', '{"no_state_income_tax": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "chip_program": "CHIP"}'::jsonb, '{"texas_tomorrow_fund": "Prepaid tuition plan available"}'::jsonb),

('New York', 'NY', 'New Yorks 529 College Savings Program', 'Direct-sold and advisor-sold options with state tax deduction.', '{"state_tax_deduction": {"amount": 5000, "married_amount": 10000}, "earnings_tax_free": true}'::jsonb, 'https://www.nysaves.org/', '{"earned_income_credit": true, "child_and_dependent_care_credit": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "ny_state_of_health": true}'::jsonb, '{"529_direct": "Direct plan with tax deduction", "529_advisor": "Advisor-guided option"}'::jsonb),

('Illinois', 'IL', 'Bright Start 529', 'Illinois offers both direct-sold and advisor-sold 529 plans.', '{"state_tax_deduction": {"amount": 10000, "married_amount": 20000}, "earnings_tax_free": true}'::jsonb, 'https://www.brightstartsavings.com/', '{"earned_income_credit": true, "property_tax_credit": true}'::jsonb, '{"newborn_enrollment_deadline": "60_days", "chip_program": "All Kids"}'::jsonb, '{"bright_directions": "Advisor-sold option available"}'::jsonb);

-- Insert sample tasks for Florida
INSERT INTO tasks (title, description, category, priority, state_specific, state, estimated_time) VALUES
('Add baby to health insurance', 'Contact your insurance provider within 60 days of birth to add your newborn. Required documents: birth certificate, SSN (or application proof). Most plans cover newborns automatically for first 30 days.', 'insurance', 'urgent', true, 'FL', 30),

('Set up Florida 529 plan', 'Open a Sage Scholars 529 account. Florida has no state income tax so no state deduction, but earnings grow tax-free. Consider Florida Prepaid for tuition lock-in (enrollment Oct-Jan).', '529', 'high', true, 'FL', 45),

('Apply for Florida KidCare', 'Check eligibility for Florida KidCare (CHIP) for low-cost health coverage. Income limits vary by family size. Can supplement private insurance.', 'insurance', 'medium', true, 'FL', 20),

('Update tax withholding', 'Add new dependent to your W-4. Child tax credit may reduce withholding. Consider adjusting for additional child tax credit if eligible.', 'tax', 'medium', false, NULL, 15),

('Create or update will', 'Name guardians for your child. Florida requires specific formalities. Consider trust to manage assets until child is mature.', 'legal', 'high', true, 'FL', 60),

('Apply for SSN', 'Apply for baby Social Security number. Hospital may help with paperwork, or apply at SSA.gov. Required for tax purposes and many accounts.', 'general', 'high', false, NULL, 30),

('Open custodial account (UTMA)', 'Consider UTMA account for non-education savings. Assets transfer to child at 18 in Florida. First $1,250 of unearned income is tax-free.', '529', 'low', true, 'FL', 30),

('Review life insurance needs', 'Calculate needed coverage: 10-12x income for primary earner. Term life recommended over whole life. Beneficiary designation updates.', 'insurance', 'medium', false, NULL, 45);

-- Birth Plan Vaccines table
CREATE TABLE birth_plan_vaccines (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  vaccine_id TEXT NOT NULL,
  vaccine_name TEXT NOT NULL,
  timing TEXT NOT NULL,
  description TEXT,
  preference TEXT NOT NULL CHECK (preference IN ('standard', 'delay', 'decline')),
  discuss_with_doctor BOOLEAN DEFAULT FALSE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security on birth_plan_vaccines
ALTER TABLE birth_plan_vaccines ENABLE ROW LEVEL SECURITY;

-- RLS Policies for birth_plan_vaccines
CREATE POLICY "Users can view own birth plan vaccines"
  ON birth_plan_vaccines FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own birth plan vaccines"
  ON birth_plan_vaccines FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own birth plan vaccines"
  ON birth_plan_vaccines FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own birth plan vaccines"
  ON birth_plan_vaccines FOR DELETE
  USING (auth.uid() = user_id);

-- Trigger for birth_plan_vaccines updated_at
CREATE TRIGGER update_birth_plan_vaccines_updated_at BEFORE UPDATE ON birth_plan_vaccines
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Index for birth_plan_vaccines
CREATE INDEX idx_birth_plan_vaccines_user_id ON birth_plan_vaccines(user_id);

-- Create indexes for performance
CREATE INDEX idx_tasks_user_id ON tasks(user_id);
CREATE INDEX idx_tasks_due_date ON tasks(due_date);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_documents_user_id ON documents(user_id);
CREATE INDEX idx_conversations_user_id ON conversations(user_id);
CREATE INDEX idx_states_abbreviation ON states(abbreviation);

-- Additional tables for new features (Phase 2)

-- Action Items from Insurance Analysis
CREATE TABLE action_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
  task_text TEXT NOT NULL,
  category VARCHAR(50),
  priority VARCHAR(10) DEFAULT 'medium',
  status VARCHAR(20) DEFAULT 'pending',
  due_date DATE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE action_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can CRUD own action items"
  ON action_items FOR ALL
  USING (auth.uid() = user_id);

-- Notification Preferences
CREATE TABLE notification_preferences (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  task_reminders BOOLEAN DEFAULT TRUE,
  task_due_alerts BOOLEAN DEFAULT TRUE,
  weekly_digest BOOLEAN DEFAULT TRUE,
  daily_digest BOOLEAN DEFAULT FALSE,
  quiet_hours_start TIME DEFAULT '20:00',
  quiet_hours_end TIME DEFAULT '08:00',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notification preferences"
  ON notification_preferences FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notification preferences"
  ON notification_preferences FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own notification preferences"
  ON notification_preferences FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Benefit Documents
CREATE TABLE benefit_documents (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  document_type VARCHAR(50) NOT NULL,
  file_data TEXT,
  analysis JSONB,
  status VARCHAR(20) DEFAULT 'active',
  uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE benefit_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can CRUD own benefit documents"
  ON benefit_documents FOR ALL
  USING (auth.uid() = user_id);

CREATE TRIGGER update_benefit_documents_updated_at BEFORE UPDATE ON benefit_documents
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Expenses for Budget Tracker
CREATE TABLE expenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL,
  category VARCHAR(50) NOT NULL,
  description TEXT,
  merchant TEXT,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  is_recurring BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can CRUD own expenses"
  ON expenses FOR ALL
  USING (auth.uid() = user_id);

-- Sent Notifications Log
CREATE TABLE sent_notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  subject TEXT NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  opened_at TIMESTAMP WITH TIME ZONE
);

ALTER TABLE sent_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own sent notifications"
  ON sent_notifications FOR SELECT
  USING (auth.uid() = user_id);

-- Additional indexes
CREATE INDEX idx_action_items_user_id ON action_items(user_id);
CREATE INDEX idx_expenses_user_id ON expenses(user_id);
CREATE INDEX idx_expenses_date ON expenses(date);
CREATE INDEX idx_savings_goals_user_id ON savings_goals(user_id);

-- ============================================
-- PUSH NOTIFICATIONS TABLES
-- ============================================

-- Push Subscriptions
CREATE TABLE push_subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  enabled BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own push subscriptions"
  ON push_subscriptions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own push subscriptions"
  ON push_subscriptions FOR DELETE
  USING (auth.uid() = user_id);

-- Add updated_at trigger
CREATE TRIGGER update_push_subscriptions_updated_at BEFORE UPDATE ON push_subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Add push notification columns to notification_preferences
ALTER TABLE notification_preferences 
  ADD COLUMN IF NOT EXISTS push_enabled BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS push_task_reminders BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS push_kick_reminders BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS push_contraction_alerts BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS push_weekly_summary BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS push_goal_milestones BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS push_partner_activity BOOLEAN DEFAULT TRUE;

-- Scheduled Notifications
CREATE TABLE scheduled_notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  payload JSONB NOT NULL,
  scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed', 'cancelled', 'no_subscription', 'quiet_hours')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE scheduled_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own scheduled notifications"
  ON scheduled_notifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own scheduled notifications"
  ON scheduled_notifications FOR DELETE
  USING (auth.uid() = user_id);

-- Indexes for push notifications
CREATE INDEX idx_push_subscriptions_user_id ON push_subscriptions(user_id);
CREATE INDEX idx_push_subscriptions_endpoint ON push_subscriptions(endpoint);
CREATE INDEX idx_scheduled_notifications_user_id ON scheduled_notifications(user_id);
CREATE INDEX idx_scheduled_notifications_status ON scheduled_notifications(status);
CREATE INDEX idx_scheduled_notifications_scheduled_at ON scheduled_notifications(scheduled_at);