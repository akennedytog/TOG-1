'use client';

import { useState, useEffect, useCallback } from 'react';
import { supabase, Task } from '@/lib/supabase';

export function useTasks(userId?: string) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchTasks = useCallback(async () => {
    if (!userId) {
      setTasks([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', userId)
        .order('due_date', { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchTasks();

    // Subscribe to real-time changes
    if (userId) {
      const subscription = supabase
        .channel('tasks_changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'tasks',
            filter: `user_id=eq.${userId}`,
          },
          (payload) => {
            fetchTasks();
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [userId, fetchTasks]);

  const updateTaskStatus = async (taskId: string, status: Task['status']) => {
    const updates: any = { status };
    if (status === 'completed') {
      updates.completion_date = new Date().toISOString();
    }

    const { error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', taskId);

    if (error) throw error;

    // Optimistically update local state
    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId ? { ...task, ...updates } : task
      )
    );
  };

  const createTask = async (task: Omit<Task, 'id' | 'created_at' | 'updated_at'>) => {
    const { data, error } = await supabase
      .from('tasks')
      .insert(task)
      .select()
      .single();

    if (error) throw error;

    setTasks((prev) => [...prev, data]);
    return data;
  };

  const deleteTask = async (taskId: string) => {
    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', taskId);

    if (error) throw error;

    setTasks((prev) => prev.filter((task) => task.id !== taskId));
  };

  // Computed values
  const pendingTasks = tasks.filter((t) => t.status !== 'completed');
  const urgentTasks = tasks.filter((t) => t.priority === 'urgent' && t.status !== 'completed');
  const completedTasks = tasks.filter((t) => t.status === 'completed');
  const overdueTasks = tasks.filter(
    (t) =>
      t.status !== 'completed' &&
      t.due_date &&
      new Date(t.due_date) < new Date()
  );

  return {
    tasks,
    loading,
    error,
    pendingTasks,
    urgentTasks,
    completedTasks,
    overdueTasks,
    refresh: fetchTasks,
    updateTaskStatus,
    createTask,
    deleteTask,
  };
}
