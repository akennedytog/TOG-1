# BabyNest Complete Financial Planning Checklist
## The Ultimate Guide for New Parents

---

## IMMEDIATE (First 30 Days)

### Healthcare & Insurance
- [ ] **Add baby to health insurance** (30-60 days deadline - CRITICAL)
- [ ] **Understand automatic coverage period** (usually 30 days under mother's plan)
- [ ] **Apply for baby's own policy** if not covered under family plan
- [ ] **Get CHIP/Medicaid info** if household income qualifies
- [ ] **Understand NICU coverage** if baby was in intensive care
- [ ] **Add dental/vision** if separate from medical

### Legal & Identity
- [ ] **Get Social Security Number** (can apply at hospital or SSA office)
- [ ] **Get birth certificate** (multiple certified copies)
- [ ] **Apply for passport** if international travel planned
- [ ] **Freeze child's credit** with all 3 bureaus (prevent identity theft)

### Tax & Government
- [ ] **Update W-4 with employer** (add dependent, adjust withholding)
- [ ] **Register for child tax credit** ($2,000/year federal)
- [ ] **Check state tax credits** (varies by state)
- [ ] **Apply for EITC if eligible** (Earned Income Tax Credit)

---

## SHORT TERM (1-6 Months)

### Insurance & Protection
- [ ] **Get term life insurance** ($500k-$1M, cheaper when young)
- [ ] **Review/update disability insurance**
- [ ] **Check if employer offers legal insurance** (for will/trust creation)
- [ ] **Consider umbrella liability policy** ($1-2M coverage)
- [ ] **Maximize FSA/HSA** ($3,050 FSA, $8,300 HSA family limit)

### Legal Documents
- [ ] **Create/update will** (name guardians, beneficiaries)
- [ ] **Create healthcare proxy for child** (medical decision authority)
- [ ] **Update all beneficiary designations** (401k, IRA, life insurance)
- [ ] **Consider living trust** (avoid probate)
- [ ] **Create power of attorney** (if traveling without child)
- [ ] **Document childcare instructions** (for babysitters/grandparents)

### Banking & Savings
- [ ] **Open 529 college savings plan** (state tax benefits vary)
- [ ] **Consider 529 superfunding** (5-year gift tax election, $85k at once)
- [ ] **Open UTMA/UGMA custodial account** (flexible but counts against aid)
- [ ] **Set up automatic savings** (even $50/month adds up)
- [ ] **Open high-yield savings account** for baby expenses
- [ ] **Consider custodial Roth IRA** (if baby has earned income)

---

## MEDIUM TERM (6-12 Months)

### Tax Optimization
- [ ] **Review tax withholding** after first year with child
- [ ] **Document childcare expenses** for dependent care credit
- [ ] **Track medical expenses** for tax deduction if over 7.5% AGI
- [ ] **Consider bunching deductions** if itemizing
- [ ] **Research Dependent Care FSA** if both parents work

### Education Planning
- [ ] **Research 529 plan options** (your state vs. best nationwide)
- [ ] **Look into prepaid tuition plans** (if available in your state)
- [ ] **Understand Coverdell ESA** ($2k/year limit, more flexible than 529)
- [ ] **Research ABLE accounts** if child has disabilities
- [ ] **Check for state matching grants** (some states contribute to 529s)

### Estate Planning
- [ ] **Review guardianship designation** annually
- [ ] **Update will after major life changes**
- [ ] **Consider life insurance trust** for minor children
- [ ] **Document digital assets** (what happens to social media, photos, etc.)
- [ ] **Create letter of intent** (your wishes for child's care)

---

## LONG TERM (1-5 Years)

### Advanced Strategies
- [ ] **Roth IRA for baby** (if they have earned income from modeling, acting, etc.)
- [ ] **529-to-Roth rollover** (starting 2024, unused 529 funds can roll to Roth)
- [ ] **Front-load 529 contributions** (time in market > timing market)
- [ ] **Consider whole life insurance** for cash value (debatable strategy)
- [ ] **Explore family limited partnerships** (for wealthy families)

### Financial Aid Optimization
- [ ] **Understand FAFSA/SAR** and how assets are counted
- [ ] **Optimize asset location** (529s vs. taxable accounts for aid purposes)
- [ ] **Consider income timing** in base year before college
- [ ] **Research merit-based aid opportunities** early

### Career & Income
- [ ] **Negotiate flexible work arrangements**
- [ ] **Consider side hustles** that qualify for Roth IRA contributions
- [ ] **Review life insurance through employer** (not portable)
- [ ] **Understand parental leave policies** for future children

---

## MISCELLANEOUS & ADVANCED

### Unique Opportunities
- [ ] **Baby modeling/acting income** → Roth IRA contributions
- [ ] **Family business employment** → earned income for retirement accounts
- [ ] **Gift tax planning** ($18k/year per person, $36k/couple)
- [ ] **529 gifting from grandparents** (5-year superfunding strategy)

### Protection & Security
- [ ] **Home inventory** for insurance purposes
- [ ] **Document valuables** with photos/appraisals
- [ ] **Review homeowners/renters insurance** (increased liability with kids)
- [ ] **Consider cyber insurance** (identity theft coverage)

### Future Considerations
- [ ] **Special needs planning** if applicable
- [ ] **529 for private K-12** (federal law allows, some states don't)
- [ ] **Apprenticeship programs** (529 funds can be used)
- [ ] **International education** (some 529s allow foreign schools)

---

## TAX BENEFITS SUMMARY

### Federal
- Child Tax Credit: Up to $2,000/child
- Child and Dependent Care Credit: Up to $1,050-2,100
- Earned Income Tax Credit: Up to $7,830 (3+ kids)
- Adoption Tax Credit: Up to $15,950

### State (Varies)
- 529 tax deductions (some states)
- Dependent exemptions (some states)
- Additional child credits (some states)

---

## DEADLINES TO REMEMBER

- **30-60 days**: Add baby to health insurance
- **Before tax season**: Update W-4
- **April 15**: Tax filing (or extension)
- **December 31**: 529 contributions for tax year
- **Annual**: Review insurance beneficiaries
- **Every 5 years**: Update will

---

## QUESTIONS TO ASK PROFESSIONALS

### For Financial Advisor
- How should we balance 529 vs. retirement savings?
- What's optimal asset location for college aid?
- Should we consider a 529 superfund?

### For Tax Professional
- Are we maximizing all available credits?
- How does our income affect aid eligibility?
- Should we adjust withholding or estimated taxes?

### For Insurance Agent
- Do we have enough life insurance?
- Should we get umbrella liability coverage?
- What's the best strategy for long-term disability?

### For Estate Attorney
- Is our will sufficient or do we need a trust?
- Have we properly named guardians?
- Should we create powers of attorney?

---

## RED FLAGS TO AVOID

- [ ] **Don't skip life insurance** (term is cheap)
- [ ] **Don't forget beneficiary updates** (bypass probate)
- [ ] **Don't miss insurance deadline** (30-60 days)
- [ ] **Don't put off will creation** (court decides guardianship)
- [ ] **Don't ignore 529 state tax benefits** (some offer deductions)
- [ ] **Don't forget to freeze child's credit** (identity theft risk)
- [ ] **Don't keep 529 in child's name** (counts against aid heavily)

---

## KEY MONEY-SAVING TIPS

1. **529 first, then taxable** (tax-free growth)
2. **Front-load if possible** (compound growth)
3. **Term life > whole life** (more coverage, less cost)
4. **FSA for known expenses** (HSA if high-deductible plan)
5. **Roth IRA for baby** (if they have earned income)
6. **Credit freeze is free** (all 3 bureaus)
7. **Group life isn't enough** (not portable, usually 1-2x salary)

---

## RESOURCES

### Government
- SSA.gov (Social Security)
- IRS.gov (taxes)
- Healthcare.gov (insurance)
- StudentAid.gov (college financing)

### Financial
- SEC.gov (investment info)
- FINRA.org (broker check)
- CFP Board (find certified planner)

### Insurance
- NAIC.org (insurance regulation)
- State insurance departments

---

*Last Updated: 2026-05-10*
*This is a comprehensive guide. Consult with qualified professionals for personalized advice.*