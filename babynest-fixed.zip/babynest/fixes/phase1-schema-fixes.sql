-- Phase 1: Critical Schema Fixes for BabyNest
-- Run this in Supabase SQL Editor

-- ============================================
-- FIX 1: Add missing columns to tasks table
-- ============================================

-- Add order column for task ordering
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS "order" INTEGER DEFAULT 0;

-- Add icon column for task icons
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS icon TEXT DEFAULT 'file';

-- ============================================
-- FIX 2: Expand category CHECK constraint on tasks
-- ============================================

-- First, drop existing constraint
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_category_check;

-- Add expanded constraint with all categories used in TaskManager
ALTER TABLE tasks ADD CONSTRAINT tasks_category_check 
CHECK (category IN ('insurance', '529', 'tax', 'legal', 'general', 'education', 'investment'));

-- Update any existing rows with invalid categories to 'general'
UPDATE tasks SET category = 'general' 
WHERE category NOT IN ('insurance', '529', 'tax', 'legal', 'general', 'education', 'investment');

-- ============================================
-- FIX 3: Fix registry_items category CHECK
-- ============================================

-- Drop existing constraint
ALTER TABLE registry_items DROP CONSTRAINT IF EXISTS registry_items_category_check;

-- Add expanded constraint with diapering and safety
ALTER TABLE registry_items ADD CONSTRAINT registry_items_category_check 
CHECK (category IN ('gear', 'clothing', 'feeding', 'nursery', 'bath', 'health', 'toys', 'books', 'other', 'diapering', 'safety'));

-- Update any existing rows with invalid categories
UPDATE registry_items SET category = 'other' 
WHERE category NOT IN ('gear', 'clothing', 'feeding', 'nursery', 'bath', 'health', 'toys', 'books', 'other', 'diapering', 'safety');

-- ============================================
-- FIX 4: Fix registry_items source CHECK
-- ============================================

-- Drop existing constraint
ALTER TABLE registry_items DROP CONSTRAINT IF EXISTS registry_items_source_check;

-- Add babylist to allowed sources
ALTER TABLE registry_items ADD CONSTRAINT registry_items_source_check 
CHECK (source IN ('amazon', 'target', 'buybuybaby', 'walmart', 'custom', 'babylist'));

-- Update any existing rows with invalid sources
UPDATE registry_items SET source = 'custom' 
WHERE source NOT IN ('amazon', 'target', 'buybuybaby', 'walmart', 'custom', 'babylist');

-- ============================================
-- FIX 5: Add priority_weight column for proper sorting
-- ============================================

ALTER TABLE tasks ADD COLUMN IF NOT EXISTS priority_weight INTEGER DEFAULT 2;

-- Update existing tasks with proper weights
UPDATE tasks SET priority_weight = 4 WHERE priority = 'urgent';
UPDATE tasks SET priority_weight = 3 WHERE priority = 'high';
UPDATE tasks SET priority_weight = 2 WHERE priority = 'medium';
UPDATE tasks SET priority_weight = 1 WHERE priority = 'low';

-- ============================================
-- FIX 6: Remove duplicate table definitions check
-- ============================================

-- Check for duplicate indexes
SELECT tablename, indexname 
FROM pg_indexes 
WHERE schemaname = 'public' 
AND tablename IN ('expenses', 'action_items', 'notification_preferences', 'benefit_documents')
ORDER BY tablename, indexname;

-- ============================================
-- VERIFY FIXES
-- ============================================

-- Check tasks table columns
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'tasks';

-- Check registry_items constraints
SELECT conname, pg_get_constraintdef(oid) 
FROM pg_constraint 
WHERE conrelid = 'registry_items'::regclass;

-- Check tasks constraints
SELECT conname, pg_get_constraintdef(oid) 
FROM pg_constraint 
WHERE conrelid = 'tasks'::regclass;
