-- STEP 1: Create registry_items table
-- STEP 2: Update constraints

-- Create function first
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- CREATE registry_items table
-- ============================================
CREATE TABLE IF NOT EXISTS registry_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT CHECK (category IN ('gear', 'clothing', 'feeding', 'nursery', 'bath', 'health', 'toys', 'books', 'other', 'diapering', 'safety')),
    price NUMERIC(10, 2),
    quantity INTEGER DEFAULT 1,
    source TEXT CHECK (source IN ('amazon', 'target', 'buybuybaby', 'walmart', 'custom', 'babylist')),
    external_url TEXT,
    image_url TEXT,
    status TEXT NOT NULL DEFAULT 'wanted' CHECK (status IN ('wanted', 'gifted', 'purchased', 'received')),
    priority TEXT DEFAULT 'nice-to-have' CHECK (priority IN ('essential', 'nice-to-have', 'optional')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_registry_items_user_id ON registry_items(user_id);
CREATE INDEX IF NOT EXISTS idx_registry_items_status ON registry_items(status);
CREATE INDEX IF NOT EXISTS idx_registry_items_category ON registry_items(category);

-- Enable RLS
ALTER TABLE registry_items ENABLE ROW LEVEL SECURITY;

-- ============================================
-- FIX tasks table
-- ============================================

-- Add order column if not exists
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'tasks' AND column_name = 'order'
    ) THEN
        ALTER TABLE tasks ADD COLUMN "order" INTEGER DEFAULT 0;
    END IF;
END $$;

-- Add icon column if not exists
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'tasks' AND column_name = 'icon'
    ) THEN
        ALTER TABLE tasks ADD COLUMN icon TEXT DEFAULT 'file';
    END IF;
END $$;

-- Add priority_weight column if not exists
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'tasks' AND column_name = 'priority_weight'
    ) THEN
        ALTER TABLE tasks ADD COLUMN priority_weight INTEGER DEFAULT 2;
    END IF;
END $$;

-- Update tasks category constraint
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_category_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_category_check 
CHECK (category IN ('insurance', '529', 'tax', 'legal', 'general', 'benefit', 'education', 'investment'));

-- ============================================
-- VERIFY
-- ============================================
SELECT 'Tables updated successfully' AS status;
