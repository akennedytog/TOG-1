-- Phase 2: Persistence tables for state-only components
-- Run this in Supabase SQL Editor

-- ============================================
-- 1. Hospital Bag Items (per-user list)
-- ============================================
CREATE TABLE IF NOT EXISTS hospital_bag_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  item_key TEXT NOT NULL,        -- 'mom-1', 'baby-1', or 'custom-xxx'
  name TEXT NOT NULL,
  category TEXT NOT NULL,        -- mom/baby/partner/tech/comfort/documents
  essential BOOLEAN DEFAULT FALSE,
  checked BOOLEAN DEFAULT FALSE,
  is_custom BOOLEAN DEFAULT FALSE,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, item_key)
);

CREATE INDEX IF NOT EXISTS idx_hospital_bag_items_user ON hospital_bag_items(user_id);

ALTER TABLE hospital_bag_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own bag items" ON hospital_bag_items;
CREATE POLICY "Users can manage their own bag items"
  ON hospital_bag_items FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- 2. Kick Sessions
-- ============================================
CREATE TABLE IF NOT EXISTS kick_sessions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  kick_count INTEGER DEFAULT 0,
  duration_ms BIGINT DEFAULT 0,
  completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_kick_sessions_user ON kick_sessions(user_id, started_at DESC);

ALTER TABLE kick_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own kick sessions" ON kick_sessions;
CREATE POLICY "Users can manage their own kick sessions"
  ON kick_sessions FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- 3. Contractions
-- ============================================
CREATE TABLE IF NOT EXISTS contractions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  duration_ms BIGINT DEFAULT 0,
  intensity TEXT CHECK (intensity IN ('mild', 'moderate', 'strong')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_contractions_user ON contractions(user_id, started_at DESC);

ALTER TABLE contractions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own contractions" ON contractions;
CREATE POLICY "Users can manage their own contractions"
  ON contractions FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- 4. Birth Plans (one row per user; full plan as JSONB)
-- ============================================
CREATE TABLE IF NOT EXISTS birth_plans (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL UNIQUE,
  sections JSONB DEFAULT '[]'::jsonb,
  notes TEXT,
  vaccines JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_birth_plans_user ON birth_plans(user_id);

ALTER TABLE birth_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own birth plan" ON birth_plans;
CREATE POLICY "Users can manage their own birth plan"
  ON birth_plans FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- 5. Pregnancy Tracking (vaccinations checked, etc.)
-- ============================================
CREATE TABLE IF NOT EXISTS pregnancy_tracking (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL UNIQUE,
  completed_vaccine_ids TEXT[] DEFAULT ARRAY[]::TEXT[],
  data JSONB DEFAULT '{}'::jsonb, -- room for future tracking fields
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pregnancy_tracking_user ON pregnancy_tracking(user_id);

ALTER TABLE pregnancy_tracking ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage their own pregnancy tracking" ON pregnancy_tracking;
CREATE POLICY "Users can manage their own pregnancy tracking"
  ON pregnancy_tracking FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- 6. Update triggers for updated_at
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS hospital_bag_items_updated_at ON hospital_bag_items;
CREATE TRIGGER hospital_bag_items_updated_at
  BEFORE UPDATE ON hospital_bag_items
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS birth_plans_updated_at ON birth_plans;
CREATE TRIGGER birth_plans_updated_at
  BEFORE UPDATE ON birth_plans
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS pregnancy_tracking_updated_at ON pregnancy_tracking;
CREATE TRIGGER pregnancy_tracking_updated_at
  BEFORE UPDATE ON pregnancy_tracking
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
