# BabyNest Quickstart

## ⚡ 5-Minute Setup

### Step 1: Create Supabase Project (2 min)
```bash
1. Go to https://supabase.com
2. Click "New Project"
3. Name: babynest
4. Password: (auto-generate)
5. Region: East US (N. Virginia)
```

### Step 2: Get API Keys (1 min)
```bash
# In Supabase Dashboard:
Settings → API → Copy these:

Project URL: https://xxxx.supabase.co
  → NEXT_PUBLIC_SUPABASE_URL

Anon public: eyJxxx...
  → NEXT_PUBLIC_SUPABASE_ANON_KEY

service_role secret: eyJxxx...
  → SUPABASE_SERVICE_ROLE_KEY
```

### Step 3: Set Up Database (1 min)
```bash
# In Supabase Dashboard:
SQL Editor → New Query

# Copy contents of scripts/setup_supabase.sql
# Paste and click "Run"
```

### Step 4: Configure Environment (1 min)
```bash
cd /Users/aleckennedy/.openclaw/workspace/babynest
cp .env.example .env.local

# Edit .env.local and add your keys
```

### Step 5: Run App (1 min)
```bash
npm install
npm run dev

# Open http://localhost:3000
```

## 🎉 You're Live!

- Landing page: http://localhost:3000
- Dashboard: http://localhost:3000/dashboard
- Sign up: http://localhost:3000/auth/signup

---

## 🚀 Production Deploy

### Option A: Vercel (Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

### Option B: Manual Deploy
1. Push to GitHub
2. Connect GitHub to Vercel
3. Add environment variables in Vercel settings
4. Deploy

---

## 📋 Complete Checklist

- [ ] Supabase project created
- [ ] Database schema run
- [ ] `.env.local` configured
- [ ] `npm install` complete
- [ ] `npm run dev` working
- [ ] Sign up test account
- [ ] Upload test insurance card
- [ ] Chat with AI assistant
- [ ] Deploy to production

---

## 🔧 Troubleshooting

**"Cannot find module" errors:**
```bash
rm -rf node_modules package-lock.json
npm install
```

**Database connection errors:**
- Check Supabase URL and keys in `.env.local`
- Verify tables exist in Supabase Table Editor

**Build errors:**
```bash
npm run build
# Check the error message and fix
```

---

## 📚 Documentation

- Full guide: `DEPLOYMENT.md`
- Database schema: `scripts/setup_supabase.sql`
- State content: `scripts/top_5_states.sql`

---

**Need help?** Check `DEPLOYMENT.md` for detailed instructions.