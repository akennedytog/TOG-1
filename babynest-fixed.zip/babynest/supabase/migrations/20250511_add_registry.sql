-- Baby Registry Migration
-- Created: 2025-05-11
-- Adds registry_items table with RLS policies

-- ============================================
-- Table: registry_items
-- ============================================
CREATE TABLE IF NOT EXISTS registry_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT CHECK (category IN ('gear', 'clothing', 'feeding', 'nursery', 'bath', 'health', 'toys', 'books', 'other')),
    price NUMERIC(10, 2),
    quantity INTEGER DEFAULT 1,
    source TEXT CHECK (source IN ('amazon', 'target', 'buybuybaby', 'walmart', 'custom')),
    external_url TEXT,
    image_url TEXT,
    status TEXT NOT NULL DEFAULT 'wanted' CHECK (status IN ('wanted', 'gifted', 'purchased', 'received')),
    priority TEXT DEFAULT 'nice-to-have' CHECK (priority IN ('essential', 'nice-to-have', 'optional')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for faster user lookups
CREATE INDEX IF NOT EXISTS idx_registry_items_user_id ON registry_items(user_id);
CREATE INDEX IF NOT EXISTS idx_registry_items_status ON registry_items(status);
CREATE INDEX IF NOT EXISTS idx_registry_items_category ON registry_items(category);

-- ============================================
-- RLS Policies
-- ============================================

-- Enable RLS
ALTER TABLE registry_items ENABLE ROW LEVEL SECURITY;

-- Policy: Users can select their own registry items
CREATE POLICY registry_items_select_own ON registry_items
    FOR SELECT
    USING (auth.uid() = user_id);

-- Policy: Users can insert their own registry items
CREATE POLICY registry_items_insert_own ON registry_items
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own registry items
CREATE POLICY registry_items_update_own ON registry_items
    FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- Policy: Users can delete their own registry items
CREATE POLICY registry_items_delete_own ON registry_items
    FOR DELETE
    USING (auth.uid() = user_id);

-- ============================================
-- Trigger: Update updated_at timestamp
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_registry_items_updated_at
    BEFORE UPDATE ON registry_items
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- Migration Instructions
-- ============================================
--
-- To run this migration:
--
-- Option 1: Using Supabase CLI (recommended)
--   supabase db push
--
-- Option 2: Via Supabase Dashboard SQL Editor
--   1. Go to your Supabase project dashboard
--   2. Navigate to SQL Editor → New query
--   3. Paste the contents of this file
--   4. Click "Run"
--
-- Option 3: Using psql
--   psql -d YOUR_DATABASE_URL -f 20250511_add_registry.sql
--
-- ============================================
