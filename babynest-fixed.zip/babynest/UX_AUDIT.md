# BabyNest UX/UI Audit — May 2026

## Executive Summary

BabyNest has solid bones (good visual design, thoughtful features, working integrations) but suffers from **navigation overload**, **information fragmentation**, and **stale dashboard data**. The biggest seamlessness wins will come from: (1) collapsing the tab system, (2) making the dashboard a true command center with real-time data, and (3) reducing cognitive load through smarter defaults and progressive disclosure.

---

## 🔴 CRITICAL ISSUES (Fix Immediately)

### 1. Dashboard Stat Cards Show Fake Data
**Problem**: The "Savings Goals" card shows `$2,450 saved` and `+12% this month`, and "Monthly Budget" shows `$850 spent of $1,200 budget` — these are **hard-coded** for every user.

**Files**: `app/dashboard/page.tsx` lines 460-500

**Fix**: Either query real data from `savings_goals` and `budget_entries` tables, or remove these cards entirely until real data is wired up. Showing fake numbers destroys trust the instant a user notices.

**Impact**: 🔥 Critical — undermines product credibility

---

### 2. Tab Navigation is Overwhelming (10 destinations)
**Problem**: The current nav has Registry, Tasks, Insurance, Finance (3 sub-tabs), Planning (2 sub-tabs), Tracking (2 sub-tabs) = **10 destinations across 4 different patterns** (tabs + dropdowns). Users must remember which dropdown a feature lives under.

**Fix**: Reorganize around the **3 phases of pregnancy**:
- **Now** (active tasks, urgent insurance deadlines, current week)
- **Financial** (savings, budget, calculator, insurance review)
- **Birth Prep** (hospital bag, birth plan, vaccinations, pregnancy tracker)
- **Registry** (standalone — different purpose)

Or use a **left sidebar** instead of horizontal tabs — far easier to scan, no nested dropdowns needed.

**Impact**: 🔥 Critical — affects every user every session

---

### 3. No Mobile Hamburger / Tabs Wrap Awkwardly
**Problem**: On mobile, tabs wrap to 2-3 rows. Header gets crowded with due date + state + week + Family + signout buttons. The "hidden md:flex" hides profile info entirely on mobile, but the chat sidebar takes 1/3 of the screen on tablet.

**Fix**:
- Mobile: Bottom nav bar (5 most-used: Tasks, Finance, Planning, Registry, More)
- Tablet/desktop: Left sidebar
- Chat: Floating action button (FAB) on mobile, side drawer on desktop

**Impact**: 🔥 Critical — ~60% of pregnancy app usage is mobile

---

## 🟠 HIGH PRIORITY (Fix This Week)

### 4. Welcome Banner Wastes Prime Real Estate
**Problem**: "Welcome back, [Name]! Your all-in-one pregnancy companion. Track costs, manage savings, and stay organized." — this is **marketing copy on the dashboard**. Users already signed up.

**Fix**: Replace with a **personalized "Today" card**:
- "Week 24 • 16 weeks until your due date"
- 1 most urgent task with quick-complete button
- Current trimester milestone or tip
- Quick stat: tasks completed this week

**Impact**: 🟠 High — makes dashboard feel personal, not generic

---

### 5. Floating Quick Action Bar Duplicates Functionality
**Problem**: The bottom floating bar shows "Review Insurance", "Add Savings", "Pack Hospital Bag" — but these just switch tabs (same as clicking the tab). It's visual noise that adds no real shortcut value.

**Fix**: Make these **action shortcuts**, not navigation:
- "Add Savings" → opens "Add Savings Goal" modal directly
- "Pack Hospital Bag" → opens a quick-add item input
- "Review Insurance" → opens upload dialog directly

Or remove it entirely. The dashboard urgent task cards already serve this purpose.

**Impact**: 🟠 High — reduces UI clutter and adds real utility

---

### 6. Vaccination/Birth Plan Have Two Modes But One Tab
**Problem**: VaccinationTracker has "Info Mode" vs "Birth Plan Mode" toggle inside the component, but there's also a separate "Birth Plan" tab in nav. Users get confused about where to manage their birth plan vaccines.

**Fix**: 
- Vaccinations tab = info + tracking what baby received (post-birth)
- Birth Plan tab = single source for birth plan vaccine prefs
- Remove the mode toggle from VaccinationTracker
- The Birth Plan should embed the vaccine prefs section, not duplicate it

**Impact**: 🟠 High — eliminates user confusion

---

### 7. No "What's Next?" Guidance
**Problem**: After completing tasks, users see "You completed X tasks!" but no clear answer to "what should I do next?" The Smart Recommendation banner is good but easily missed.

**Fix**: Add a **"Next Step" CTA card** that updates dynamically:
- If pregnancy week < 12: "Schedule your first prenatal appointment"
- If insurance not uploaded: "Upload your insurance to find pregnancy benefits"
- If no savings goal: "Set up your first savings goal — even $25/week adds up"
- Use the Stripe-style "complete your setup" pattern

**Impact**: 🟠 High — drives engagement and feature adoption

---

### 8. Registry Tab is Aspirational (Doesn't Work)
**Problem**: As acknowledged, the registry import is blocked by bot protection. The tab exists as a "vision placeholder" but new users will hit the broken feature, get frustrated, and leave.

**Fix**:
- Add a clear banner: "Direct registry sync coming soon! For now, [add items manually] or [paste from your registry]"
- Move Registry behind the "More" / hidden tab until it's functional
- Or build the manual entry flow to be genuinely delightful (drag-and-drop image upload, AI-suggested items by week, etc.)

**Impact**: 🟠 High — broken features hurt more than missing features

---

## 🟡 MEDIUM PRIORITY (Fix This Month)

### 9. Loading States Are Inconsistent
**Problem**: Some components use spinners (Loader2), some use skeletons, some show nothing. Dashboard urgent tasks have skeleton, but Insurance Analyzer and Hospital Bag Planner show blank screens during load.

**Fix**: Standardize on **skeletons** for content that has shape (tasks, items, cards), **inline spinners** for buttons/actions. Create a `<LoadingState>` component used everywhere.

**Impact**: 🟡 Medium — affects perceived performance

---

### 10. Chat Sidebar Hogs Space When Empty
**Problem**: Chat sidebar takes 1/3 of dashboard even when unused. The "Ask AI" button is clear but the always-open chat panel feels presumptuous.

**Fix**:
- Default to **closed** state on first visit
- Show as floating button (lower-right) until clicked
- Once opened, remember preference per session
- On mobile, make it full-screen overlay, not sidebar

**Impact**: 🟡 Medium — gives users 33% more dashboard real estate

---

### 11. Color Coding Has No Consistent Meaning
**Problem**: Tasks use red/amber/blue, but so do Insurance (cyan), Savings (amber), Budget (blue), Registry (purple), Tracking (indigo)... Color = category, not severity. Users get visual fatigue.

**Fix**: Define **two color systems**:
- **Categories**: muted tones (these can vary)
- **States**: consistent red=urgent/error, amber=warning, green=success, blue=info

Apply the state system universally. Use category colors only for category icons, not banners or borders.

**Impact**: 🟡 Medium — improves scannability

---

### 12. Onboarding is 6 Steps But Could Be 3
**Problem**: Welcome → State → Personal → Insurance → Review → Tour. The "Welcome" and "Tour" steps add friction. Insurance step asks for plan type before user knows what BabyNest will do with it.

**Fix**:
- Step 1: State + Due Date (only required fields, 30 seconds)
- Step 2: Optional details (income, partner, insurance) — let user skip
- Drop the Tour — use empty-state tooltips on the dashboard instead
- Get user to value (their personalized task list) in < 60 seconds

**Impact**: 🟡 Medium — better activation rate

---

### 13. No Search / Quick Command
**Problem**: With 10+ features and growing, there's no way to quickly jump to a specific task or feature. Power users have to navigate manually.

**Fix**: Add a **Cmd+K command palette**:
- Search tasks ("find my insurance task")
- Jump to features ("savings goals")
- Quick actions ("add task", "log kick count")

**Impact**: 🟡 Medium — high power-user value

---

### 14. Empty States Are Generic
**Problem**: "No tasks yet!", "No documents uploaded", etc. — these tell users WHAT, not WHY they should care.

**Fix**: Educational empty states:
- Tasks: "Tasks help you save thousands and avoid missing critical deadlines. Add your first one below 👇 [3 suggested starter tasks]"
- Insurance: "Upload your insurance now and we'll find $2,000+ in pregnancy benefits you might be missing"
- Registry: "Your baby registry will live here. [Browse popular items by trimester]"

**Impact**: 🟡 Medium — increases activation

---

## 🟢 NICE TO HAVE (Polish)

### 15. Animations Are Inconsistent
- Some transitions use framer-motion, others use CSS
- Tab switches are abrupt
- Add fade-in on tab content (200ms ease-out)

### 16. Typography Hierarchy is Flat
- Headers use similar weights/sizes
- Add more contrast between H1 (28px bold), H2 (20px semibold), body (14px)

### 17. Mobile Touch Targets
- Some buttons are 32px tall (below 44px minimum)
- Checkboxes especially are hard to tap on mobile
- Increase all interactive elements to 44x44px minimum

### 18. Form Validation is Quiet
- Errors appear after submit, not on blur
- Add inline validation (red border + helper text below field)
- Show success states (green checkmark) for completed fields

### 19. Accessibility Gaps
- Color contrast on `text-warm-500` is borderline (4.3:1 — below AAA)
- No skip-to-content link
- Modals don't trap focus
- Add `aria-live` regions for toast notifications

### 20. Notifications Don't Exist
- No push notifications for insurance deadlines
- No email digests
- Add weekly "Your BabyNest Update" email with: completed tasks, upcoming deadlines, week-specific tips

---

## 🎯 RECOMMENDED OVERHAUL: "Three-Pillar Dashboard"

Instead of incremental fixes, consider this restructure:

### Top: **Today** (always visible)
- Current pregnancy week + days until due date
- 1-3 actionable cards: "Complete your insurance review" / "Pack your hospital bag" / "Add Q2 savings"
- One-click completion

### Left Sidebar: **Navigation**
```
🏠 Today
📋 Tasks
💰 Money
   ├ Savings
   ├ Budget  
   └ Cost Calculator
🛡️ Insurance
🤰 Pregnancy
   ├ Tracker
   └ Vaccinations
🏥 Birth Prep
   ├ Hospital Bag
   └ Birth Plan
🎁 Registry
⚙️ Settings
```

### Main Area: **Current Section**
- Single focused view (no tabs within tabs)
- Breadcrumbs for sub-sections
- Inline search

### Right: **AI Assistant** (collapsible)
- Closed by default
- Floating FAB when collapsed
- Context-aware suggestions based on current page

---

## 📊 QUICK WINS (Can Ship Tomorrow)

1. **Remove fake stat numbers** from Savings/Budget cards (5 min)
2. **Default chat sidebar to closed** for new users (5 min)
3. **Add "Skip Tour" button** to onboarding (10 min)
4. **Replace welcome banner** with personalized "Today" card (30 min)
5. **Add Cmd+K** placeholder ("Coming soon: press Cmd+K") (15 min)
6. **Standardize loading states** to skeletons (1 hour)
7. **Mobile: bigger checkboxes** + 44px touch targets (30 min)
8. **Empty state copy** rewrites (1 hour)
9. **Registry banner**: "Manual entry for now, direct sync coming soon" (10 min)
10. **Fix mobile profile chips**: stack vertically instead of hiding (20 min)

---

## 🚀 TOP 3 RECOMMENDATIONS

If you can only do three things:

1. **Kill the fake data on dashboard stat cards** — biggest credibility issue
2. **Replace tab nav with sidebar nav** — solves 5+ navigation problems at once  
3. **Replace welcome banner with a personalized "Today" card** — makes the dashboard feel alive

These three changes alone would transform the perceived quality of the product.
