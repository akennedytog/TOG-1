# BabyNest Deployment Guide

## Step 1: Set Up Supabase Project

### 1.1 Create Supabase Account
1. Go to https://supabase.com
2. Sign up with GitHub or email
3. Create a new project
   - Project name: `babynest`
   - Database password: (generate strong password)
   - Region: Choose closest to your users (US East for Florida)

### 1.2 Get API Keys
After project creation:
1. Go to Project Settings → API
2. Copy these values:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role secret` → `SUPABASE_SERVICE_ROLE_KEY`

### 1.3 Run Database Schema
1. Go to SQL Editor (left sidebar)
2. Click "New query"
3. Copy entire contents of `schema.sql`
4. Click "Run"
5. Verify tables created in Table Editor

### 1.4 Enable Email Auth
1. Go to Authentication → Settings
2. Under "Site URL", add:
   - `http://localhost:3000` (for dev)
   - `https://your-domain.com` (for production)
3. Under "Redirect URLs", add:
   - `http://localhost:3000/auth/callback`
   - `https://your-domain.com/auth/callback`

---

## Step 2: Set Up Stripe (Payments)

### 2.1 Create Stripe Account
1. Go to https://stripe.com
2. Sign up and complete verification
3. Get API keys from Developers → API keys

### 2.2 Create Products & Prices
Go to Products → Create product:

**Pro Plan - Monthly**
- Name: "BabyNest Pro - Monthly"
- Price: $9.99
- Billing: Recurring, Monthly

**Pro Plan - Yearly**
- Name: "BabyNest Pro - Yearly"  
- Price: $99.00
- Billing: Recurring, Yearly

**Family Plan - Monthly**
- Name: "BabyNest Family - Monthly"
- Price: $14.99
- Billing: Recurring, Monthly

**Family Plan - Yearly**
- Name: "BabyNest Family - Yearly"
- Price: $149.00
- Billing: Recurring, Yearly

### 2.3 Get Price IDs
After creating, copy the Price IDs (they start with `price_`):
- Pro Monthly → `STRIPE_PRICE_PRO_MONTHLY`
- Pro Yearly → `STRIPE_PRICE_PRO_YEARLY`
- Family Monthly → `STRIPE_PRICE_FAMILY_MONTHLY`
- Family Yearly → `STRIPE_PRICE_FAMILY_YEARLY`

### 2.4 Set Up Webhook
1. Go to Developers → Webhooks
2. Add endpoint: `https://your-domain.com/api/stripe/webhook`
3. Select events:
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
   - `customer.subscription.deleted`
4. Copy webhook signing secret → `STRIPE_WEBHOOK_SECRET`

---

## Step 3: Set Up OpenAI

1. Go to https://platform.openai.com
2. Sign up and add payment method
3. Create API key
4. Copy key → `OPENAI_API_KEY`

---

## Step 4: Configure Environment Variables

### 4.1 Local Development
Create `.env.local` file:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# OpenAI
OPENAI_API_KEY=sk-...

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_STRIPE_PRICE_PRO_MONTHLY=price_...
NEXT_PUBLIC_STRIPE_PRICE_PRO_YEARLY=price_...
NEXT_PUBLIC_STRIPE_PRICE_FAMILY_MONTHLY=price_...
NEXT_PUBLIC_STRIPE_PRICE_FAMILY_YEARLY=price_...

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 4.2 Vercel Production
1. Go to Vercel project → Settings → Environment Variables
2. Add all variables from above
3. Change `NEXT_PUBLIC_APP_URL` to your production URL

---

## Step 5: Run Locally

```bash
# Navigate to project
cd /Users/aleckennedy/.openclaw/workspace/babynest

# Install dependencies
npm install

# Run development server
npm run dev

# Open http://localhost:3000
```

---

## Step 6: Deploy to Vercel

### 6.1 Install Vercel CLI
```bash
npm i -g vercel
```

### 6.2 Deploy
```bash
# Login (first time)
vercel login

# Deploy
vercel --prod
```

### 6.3 Configure Project
1. Go to Vercel Dashboard
2. Select your project
3. Settings → General:
   - Framework Preset: Next.js
   - Build Command: `next build`
   - Output Directory: `.next`

4. Settings → Environment Variables:
   - Add all variables from `.env.local`

### 6.4 Update Supabase
Add production URL to Supabase Auth settings:
- `https://your-vercel-domain.com`
- `https://your-vercel-domain.com/auth/callback`

---

## Step 7: Post-Deploy Checklist

- [ ] Sign up test account
- [ ] Create test subscription
- [ ] Upload insurance card
- [ ] Chat with AI assistant
- [ ] Complete a task
- [ ] Check Stripe webhook delivery
- [ ] Test password reset email
- [ ] Verify all 5 states load correctly

---

## Troubleshooting

**Database connection errors:**
- Check Supabase URL and keys
- Verify tables exist in SQL Editor
- Check RLS policies

**Stripe webhook errors:**
- Verify webhook URL is accessible
- Check webhook secret matches
- Test in Stripe CLI: `stripe listen --forward-to localhost:3000/api/stripe/webhook`

**AI chat not working:**
- Verify OpenAI API key
- Check API usage limits
- Review Vercel function logs

**Auth redirects failing:**
- Update Supabase Auth redirect URLs
- Check NEXT_PUBLIC_APP_URL matches actual domain