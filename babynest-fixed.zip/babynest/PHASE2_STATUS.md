# Phase 2 Fixes Summary for BabyNest

## ✅ COMPLETED:

### Previously done
1. **Task checkboxes work** — fixed category constraints and completion_date column
2. **SmartTaskManager Add Task** — Modal + form submission working
3. **Registry import** — Kept as feature placeholder (sites block scraping)

### Phase 2 (latest)
4. **Vaccine Details Modal** — `components/VaccinationTracker.tsx` already had a
   Dialog modal showing importance, side effects, doses, description, and the
   CDC link for every vaccine in the VACCINES array. Clicking any vaccine row
   (or the "View details" link) opens it.
5. **Vaccination ↔ Birth Plan Sync** — Lifted `completedVaccines` state into
   `app/dashboard/page.tsx` and passed it both ways:
     - `VaccinationTracker` receives `completedVaccineIds` + `onCompletedChange`
     - `BirthPlanBuilder` receives `completedVaccineIds` + `onCompletedVaccinesChange`
     - State is hydrated from / persisted to `localStorage` so it survives reloads
     - Birth-plan item `b7` ("Hepatitis B vaccine") is wired to vaccine `hepb`
       via `BIRTH_PLAN_ITEM_TO_VACCINE` — checking either side updates the other
6. **Removed hard-coded urgent tasks** — `app/dashboard/page.tsx` no longer
   shows a fake "Review insurance policy" / "Schedule prenatal appointment"
   sample. Real urgent/high-priority unfinished tasks are now pulled from the
   user's Supabase `tasks` table (top 4, sorted by priority_weight + due_date).
   Due-date label is computed from the actual due_date.
7. **Loading skeletons** — Added `components/ui/skeleton.tsx` (shadcn-style).
   Used it in:
     - Dashboard urgent-tasks list while real tasks load
     - `SmartTaskManager` task list (replaces the spinner-only state)
8. **PDF analysis fix** — `app/api/analyze-insurance-doc/route.ts`:
     - Switched runtime from `edge` to `nodejs` (required for `pdf-parse`)
     - Added `pdf-parse` (v2 API: `new PDFParse({ data }).getText()`)
     - For PDFs: extract text first, then pass through `analyzeInsuranceText`
       (which already supports 120k chars and uses GPT-4o w/ 128k context)
     - Falls back to legacy base64-vision path if extraction yields <50 chars
       (e.g., scanned/image-only PDFs), and surfaces a clear message asking the
       user to paste text or upload page screenshots in that case

## 🧪 Verification:
- `npx tsc --noEmit` → clean
- `npx next build` → succeeds. `/api/analyze-insurance-doc` now runs on the
  Node.js runtime (λ) so `pdf-parse` works.

## 🟡 Still open (not in this phase):
- Persistence for HospitalBagPlanner, KickCounter, ContractionTimer,
  PregnancyTracker (currently in-memory only)
