import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const PreferencesSchema = z.object({
  task_reminders: z.boolean().default(true),
  task_due_alerts: z.boolean().default(true),
  weekly_digest: z.boolean().default(true),
  daily_digest: z.boolean().default(false),
  quiet_hours_start: z.string().default('20:00'),
  quiet_hours_end: z.string().default('08:00'),
});

// GET /api/notifications/preferences?userId=xxx
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      );
    }

    // Validate UUID
    const uuidSchema = z.string().uuid();
    if (!uuidSchema.safeParse(userId).success) {
      return NextResponse.json(
        { error: 'Invalid userId format' },
        { status: 400 }
      );
    }

    const { data, error } = await supabase
      .from('notification_preferences')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      return NextResponse.json(
        { error: 'Failed to fetch preferences' },
        { status: 500 }
      );
    }

    // Return defaults if no preferences found
    return NextResponse.json({
      preferences: data || {
        task_reminders: true,
        task_due_alerts: true,
        weekly_digest: true,
        daily_digest: false,
        quiet_hours_start: '20:00',
        quiet_hours_end: '08:00'
      }
    });

  } catch (error) {
    console.error('GET preferences error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch preferences' },
      { status: 500 }
    );
  }
}

// PATCH /api/notifications/preferences
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, preferences } = body;

    if (!userId || !preferences) {
      return NextResponse.json(
        { error: 'userId and preferences are required' },
        { status: 400 }
      );
    }

    // Validate UUID
    const uuidSchema = z.string().uuid();
    if (!uuidSchema.safeParse(userId).success) {
      return NextResponse.json(
        { error: 'Invalid userId format' },
        { status: 400 }
      );
    }

    // Validate preferences
    const validationResult = PreferencesSchema.safeParse(preferences);
    if (!validationResult.success) {
      return NextResponse.json(
        { error: 'Invalid preferences data', details: validationResult.error.issues },
        { status: 400 }
      );
    }

    const { data, error } = await supabase
      .from('notification_preferences')
      .upsert({
        user_id: userId,
        ...validationResult.data,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'user_id'
      })
      .select()
      .single();

    if (error) {
      console.error('PATCH preferences error:', error);
      return NextResponse.json(
        { error: 'Failed to update preferences' },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true, preferences: data });

  } catch (error) {
    console.error('PATCH preferences error:', error);
    return NextResponse.json(
      { error: 'Failed to update preferences' },
      { status: 500 }
    );
  }
}
