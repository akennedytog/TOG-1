'use client';

import { Suspense } from 'react';
import { LegalDisclaimer } from '@/components/LegalDisclaimer';
import { BabyNamesContent } from './BabyNamesContent';

export default function BabyNamesPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-cream-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-warm-600">Loading baby names...</p>
        </div>
      </div>
    }>
      <BabyNamesContent />
      <LegalDisclaimer type="general" message="Name meanings and origins are for reference only." />
    </Suspense>
  );
}
