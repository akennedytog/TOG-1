'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  Baby,
  Calendar,
  MapPin,
  TrendingUp,
  Users,
  BookOpen,
  MessageSquare,
  Calculator,
  Briefcase,
  Menu,
  X,
  ChevronDown,
  User,
  Sparkles,
  DollarSign,
  Building2,
  CheckCircle2,
  ListChecks,
  Heart,
  Shield,
  Settings,
  LogOut,
  Star,
} from 'lucide-react';
import { supabase, Profile } from '@/lib/supabase';
import { formatDate } from '@/lib/utils';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { updateProfile } from '@/lib/supabase';

/* ------------------------------------------------------------------ */
/*  Navigation Schema                                                  */
/* ------------------------------------------------------------------ */

type NavItem = {
  href: string;
  label: string;
  icon: any;
  description?: string;
  featured?: boolean;
};

type NavGroup = {
  label: string;
  icon: any;
  items: NavItem[];
};

// The 6 differentiation features — highlighted everywhere.
const FEATURED_LINKS: NavItem[] = [
  {
    href: '/financial-timeline',
    label: 'Financial Timeline',
    icon: DollarSign,
    description: 'Personalized money roadmap by week',
    featured: true,
  },
  {
    href: '/hospital-costs',
    label: 'Hospital Costs',
    icon: Building2,
    description: 'Estimate delivery + birth bills',
    featured: true,
  },
  {
    href: '/readiness',
    label: 'Readiness Score',
    icon: CheckCircle2,
    description: 'How prepared are you, really?',
    featured: true,
  },
  {
    href: '/milestones',
    label: 'Milestones',
    icon: ListChecks,
    description: 'Track every important step',
    featured: true,
  },
  {
    href: '/baby-name',
    label: 'Baby Name',
    icon: Heart,
    description: 'AI-powered name discovery',
    featured: true,
  },
  {
    href: '/providers',
    label: 'Insurance & Providers',
    icon: Shield,
    description: 'Find OBs, pediatricians, coverage',
    featured: true,
  },
];

// Quick top-level links (always visible on desktop).
const PRIMARY_LINKS: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: Baby },
];

// Grouped extras under "More".
const MORE_GROUPS: NavGroup[] = [
  {
    label: 'Tools',
    icon: Calculator,
    items: [
      {
        href: '/leave-calculator',
        label: 'Maternity Leave Calculator',
        icon: Calculator,
        description: 'Plan your time off',
      },
      {
        href: '/due-date-calculator',
        label: 'Due Date Calculator',
        icon: Calendar,
        description: 'Calculate your due date',
      },
      {
        href: '/week-by-week',
        label: 'Week-by-Week Guide',
        icon: Sparkles,
        description: 'Track pregnancy week by week',
      },
      {
        href: '/is-it-safe',
        label: 'Is It Safe?',
        icon: Shield,
        description: 'Safety database for pregnancy',
      },
      {
        href: '/registry',
        label: 'Registry Tracker',
        icon: Star,
        description: 'Import & manage your registry',
      },
    ],
  },
  {
    label: 'Community',
    icon: Users,
    items: [
      {
        href: '/community',
        label: 'Community Q&A',
        icon: MessageSquare,
        description: 'Ask other parents',
      },
      {
        href: '/baby-names',
        label: 'Baby Names',
        icon: Heart,
        description: 'Browse and save baby names',
      },
      {
        href: '/blog',
        label: 'Blog & Guides',
        icon: BookOpen,
        description: 'Articles and resources',
      },
    ],
  },
];

/* ------------------------------------------------------------------ */
/*  Header Component                                                   */
/* ------------------------------------------------------------------ */

export function SharedHeader() {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [featuresOpen, setFeaturesOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const featuresRef = useRef<HTMLDivElement | null>(null);
  const moreRef = useRef<HTMLDivElement | null>(null);
  const userRef = useRef<HTMLDivElement | null>(null);

  // Profile edit modal state
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [editDueDate, setEditDueDate] = useState('');
  const [editState, setEditState] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      setUser(user);

      if (user) {
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileData) setProfile(profileData);
      }
    };
    fetchUser();
  }, []);

  // Close menus when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
    setFeaturesOpen(false);
    setMoreOpen(false);
    setUserMenuOpen(false);
  }, [pathname]);

  // Click-outside handler for dropdowns
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      const target = e.target as Node;
      if (featuresRef.current && !featuresRef.current.contains(target)) {
        setFeaturesOpen(false);
      }
      if (moreRef.current && !moreRef.current.contains(target)) {
        setMoreOpen(false);
      }
      if (userRef.current && !userRef.current.contains(target)) {
        setUserMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const weeksPregnant = profile?.due_date
    ? Math.max(
        0,
        40 -
          Math.ceil(
            (new Date(profile.due_date).getTime() - Date.now()) /
              (1000 * 60 * 60 * 24 * 7)
          )
      )
    : null;

  const trimester = weeksPregnant
    ? weeksPregnant <= 12
      ? 1
      : weeksPregnant <= 27
      ? 2
      : 3
    : null;

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/');
  };

  const isActive = (href: string) =>
    pathname === href || pathname.startsWith(href + '/');

  // Don't show header on landing page
  if (pathname === '/') return null;

  const openProfileEditor = () => {
    setEditDueDate(profile?.due_date || '');
    setEditState(profile?.state || '');
    setShowEditProfile(true);
    setUserMenuOpen(false);
  };

  return (
    <>
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md border-b border-warm-100 sticky top-0 z-40 shadow-soft">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link
              href="/dashboard"
              className="flex items-center gap-2 group shrink-0"
              aria-label="BabyNest home"
            >
              <div className="w-9 h-9 bg-gradient-to-br from-primary-400 to-primary-500 rounded-xl flex items-center justify-center shadow-soft group-hover:shadow-md transition-shadow">
                <Baby className="w-5 h-5 text-white" />
              </div>
              <div className="hidden sm:block">
                <h1 className="font-bold text-warm-900 text-sm leading-tight">
                  BabyNest
                </h1>
                <p className="text-[10px] text-warm-600 -mt-0.5">
                  Financial Planning
                </p>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              {/* Dashboard */}
              {PRIMARY_LINKS.map((link) => {
                const Icon = link.icon;
                const active = isActive(link.href);
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      'flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all',
                      active
                        ? 'bg-primary-100 text-primary-700'
                        : 'text-warm-700 hover:bg-warm-50 hover:text-warm-900'
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{link.label}</span>
                  </Link>
                );
              })}

              {/* Features Mega-Dropdown */}
              <div className="relative" ref={featuresRef}>
                <button
                  onClick={() => {
                    setFeaturesOpen((v) => !v);
                    setMoreOpen(false);
                  }}
                  className={cn(
                    'flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all',
                    FEATURED_LINKS.some((l) => isActive(l.href))
                      ? 'bg-primary-100 text-primary-700'
                      : 'text-warm-700 hover:bg-warm-50 hover:text-warm-900'
                  )}
                  aria-expanded={featuresOpen}
                  aria-haspopup="true"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Features</span>
                  <ChevronDown
                    className={cn(
                      'w-3.5 h-3.5 transition-transform',
                      featuresOpen && 'rotate-180'
                    )}
                  />
                </button>

                {featuresOpen && (
                  <div className="absolute left-0 mt-2 w-[560px] bg-white rounded-2xl shadow-soft-lg border border-warm-100 p-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="px-2 pt-1 pb-2 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-primary-500" />
                      <span className="text-[11px] uppercase tracking-wider font-semibold text-primary-600">
                        Core Features
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-1">
                      {FEATURED_LINKS.map((link) => {
                        const Icon = link.icon;
                        const active = isActive(link.href);
                        return (
                          <Link
                            key={link.href}
                            href={link.href}
                            onClick={() => setFeaturesOpen(false)}
                            className={cn(
                              'flex items-start gap-3 p-3 rounded-xl transition-all group',
                              active
                                ? 'bg-primary-50'
                                : 'hover:bg-warm-50'
                            )}
                          >
                            <div
                              className={cn(
                                'w-9 h-9 rounded-lg flex items-center justify-center shrink-0 transition-colors',
                                active
                                  ? 'bg-primary-500 text-white'
                                  : 'bg-primary-50 text-primary-600 group-hover:bg-primary-100'
                              )}
                            >
                              <Icon className="w-4.5 h-4.5" strokeWidth={2.2} />
                            </div>
                            <div className="min-w-0">
                              <div
                                className={cn(
                                  'text-sm font-semibold leading-tight',
                                  active
                                    ? 'text-primary-700'
                                    : 'text-warm-900'
                                )}
                              >
                                {link.label}
                              </div>
                              {link.description && (
                                <div className="text-xs text-warm-600 mt-0.5 leading-snug">
                                  {link.description}
                                </div>
                              )}
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* More Dropdown */}
              <div className="relative" ref={moreRef}>
                <button
                  onClick={() => {
                    setMoreOpen((v) => !v);
                    setFeaturesOpen(false);
                  }}
                  className={cn(
                    'flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all',
                    MORE_GROUPS.some((g) =>
                      g.items.some((i) => isActive(i.href))
                    )
                      ? 'bg-primary-100 text-primary-700'
                      : 'text-warm-700 hover:bg-warm-50 hover:text-warm-900'
                  )}
                  aria-expanded={moreOpen}
                  aria-haspopup="true"
                >
                  <span>More</span>
                  <ChevronDown
                    className={cn(
                      'w-3.5 h-3.5 transition-transform',
                      moreOpen && 'rotate-180'
                    )}
                  />
                </button>

                {moreOpen && (
                  <div className="absolute left-0 mt-2 w-72 bg-white rounded-2xl shadow-soft-lg border border-warm-100 p-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    {MORE_GROUPS.map((group) => (
                      <div key={group.label} className="mb-2 last:mb-0">
                        <div className="px-2 pt-1 pb-1.5 text-[11px] uppercase tracking-wider font-semibold text-warm-500">
                          {group.label}
                        </div>
                        {group.items.map((item) => {
                          const Icon = item.icon;
                          const active = isActive(item.href);
                          return (
                            <Link
                              key={item.href}
                              href={item.href}
                              onClick={() => setMoreOpen(false)}
                              className={cn(
                                'flex items-center gap-3 px-2 py-2 rounded-lg text-sm transition-colors',
                                active
                                  ? 'bg-primary-50 text-primary-700 font-semibold'
                                  : 'text-warm-700 hover:bg-warm-50'
                              )}
                            >
                              <Icon className="w-4 h-4 shrink-0" />
                              <span>{item.label}</span>
                            </Link>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </nav>

            {/* Right Side */}
            <div className="flex items-center gap-2">
              {/* Compact pregnancy stats - desktop only */}
              {profile && (weeksPregnant !== null || profile.state) && (
                <div className="hidden xl:flex items-center gap-1.5">
                  {weeksPregnant !== null && (
                    <div className="flex items-center gap-1 px-2.5 py-1.5 bg-gradient-to-r from-primary-50 to-accent-50 rounded-lg border border-primary-200 text-xs">
                      <TrendingUp className="w-3 h-3 text-primary-600" />
                      <span className="font-semibold text-primary-700">
                        W{weeksPregnant} · T{trimester}
                      </span>
                    </div>
                  )}
                  {profile.state && (
                    <button
                      onClick={openProfileEditor}
                      className="flex items-center gap-1 px-2.5 py-1.5 bg-accent-50 rounded-lg border border-accent-200 text-xs hover:bg-accent-100 transition-colors"
                    >
                      <MapPin className="w-3 h-3 text-accent-600" />
                      <span className="font-semibold text-accent-700">
                        {profile.state}
                      </span>
                    </button>
                  )}
                </div>
              )}

              {/* User Menu - Desktop */}
              {user && (
                <div className="relative hidden lg:block" ref={userRef}>
                  <button
                    onClick={() => setUserMenuOpen((v) => !v)}
                    className="flex items-center gap-1.5 p-1.5 rounded-lg hover:bg-warm-50 transition-colors"
                    aria-label="Account menu"
                    aria-expanded={userMenuOpen}
                  >
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary-400 to-accent-400 flex items-center justify-center text-white text-xs font-semibold">
                      {(user.email || '?').charAt(0).toUpperCase()}
                    </div>
                    <ChevronDown
                      className={cn(
                        'w-3.5 h-3.5 text-warm-500 transition-transform',
                        userMenuOpen && 'rotate-180'
                      )}
                    />
                  </button>

                  {userMenuOpen && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-soft-lg border border-warm-100 p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                      <div className="px-3 py-2 border-b border-warm-100 mb-1">
                        <div className="text-xs text-warm-500">Signed in as</div>
                        <div className="text-sm font-semibold text-warm-900 truncate">
                          {user.email}
                        </div>
                        {profile?.due_date && (
                          <div className="text-xs text-primary-600 mt-1 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            Due {formatDate(profile.due_date)}
                          </div>
                        )}
                      </div>
                      <button
                        onClick={openProfileEditor}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-warm-700 hover:bg-warm-50 transition-colors"
                      >
                        <User className="w-4 h-4" />
                        <span>Edit Profile</span>
                      </button>
                      <Link
                        href="/settings"
                        onClick={() => setUserMenuOpen(false)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-warm-700 hover:bg-warm-50 transition-colors"
                      >
                        <Settings className="w-4 h-4" />
                        <span>Settings</span>
                      </Link>
                      <Link
                        href="/pricing"
                        onClick={() => setUserMenuOpen(false)}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-warm-700 hover:bg-warm-50 transition-colors"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>Upgrade</span>
                      </Link>
                      <div className="my-1 border-t border-warm-100" />
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-red-600 hover:bg-red-50 transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Sign out</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2.5 rounded-lg hover:bg-warm-100 active:bg-warm-200 transition-colors -mr-1"
                aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? (
                  <X className="w-5 h-5 text-warm-700" />
                ) : (
                  <Menu className="w-5 h-5 text-warm-700" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <>
          <div
            className="lg:hidden fixed inset-0 bg-black/30 backdrop-blur-sm z-30 animate-in fade-in duration-150"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <div className="lg:hidden fixed inset-x-0 top-16 bottom-0 bg-white z-40 overflow-y-auto animate-in slide-in-from-top duration-200">
            <div className="px-4 py-5 space-y-6">
              {/* Profile summary */}
              {profile && (
                <div className="p-4 rounded-2xl bg-gradient-to-br from-primary-50 to-accent-50 border border-primary-100">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-xs text-warm-600 mb-1">
                        Your pregnancy
                      </div>
                      {weeksPregnant !== null ? (
                        <div className="text-lg font-bold text-warm-900">
                          Week {weeksPregnant}
                          <span className="text-warm-600 font-normal text-sm">
                            {' '}
                            · Trimester {trimester}
                          </span>
                        </div>
                      ) : (
                        <div className="text-sm text-warm-700">
                          Add your due date to get started
                        </div>
                      )}
                      <div className="flex flex-wrap items-center gap-3 mt-1.5 text-xs text-warm-700">
                        {profile.due_date && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {formatDate(profile.due_date)}
                          </span>
                        )}
                        {profile.state && (
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {profile.state}
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={openProfileEditor}
                      className="shrink-0 px-3 py-1.5 rounded-lg bg-white text-primary-700 text-xs font-semibold border border-primary-200 hover:bg-primary-50 transition-colors"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              )}

              {/* Dashboard */}
              <div>
                {PRIMARY_LINKS.map((link) => {
                  const Icon = link.icon;
                  const active = isActive(link.href);
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className={cn(
                        'flex items-center gap-3 px-4 py-3 rounded-xl text-base font-semibold transition-all',
                        active
                          ? 'bg-primary-100 text-primary-700'
                          : 'text-warm-800 hover:bg-warm-50 active:bg-warm-100'
                      )}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{link.label}</span>
                    </Link>
                  );
                })}
              </div>

              {/* Featured 6 */}
              <div>
                <div className="px-2 mb-2 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-primary-500" />
                  <span className="text-xs uppercase tracking-wider font-bold text-primary-600">
                    Core Features
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {FEATURED_LINKS.map((link) => {
                    const Icon = link.icon;
                    const active = isActive(link.href);
                    return (
                      <Link
                        key={link.href}
                        href={link.href}
                        onClick={() => setMobileMenuOpen(false)}
                        className={cn(
                          'flex flex-col gap-2 p-3.5 rounded-2xl border transition-all min-h-[96px]',
                          active
                            ? 'bg-primary-50 border-primary-200 shadow-sm'
                            : 'bg-white border-warm-100 hover:border-primary-200 hover:bg-primary-50/40 active:bg-primary-50'
                        )}
                      >
                        <div
                          className={cn(
                            'w-9 h-9 rounded-xl flex items-center justify-center',
                            active
                              ? 'bg-primary-500 text-white'
                              : 'bg-primary-50 text-primary-600'
                          )}
                        >
                          <Icon className="w-5 h-5" strokeWidth={2.2} />
                        </div>
                        <div>
                          <div
                            className={cn(
                              'text-sm font-semibold leading-tight',
                              active ? 'text-primary-700' : 'text-warm-900'
                            )}
                          >
                            {link.label}
                          </div>
                          {link.description && (
                            <div className="text-[11px] text-warm-600 mt-0.5 leading-snug">
                              {link.description}
                            </div>
                          )}
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </div>

              {/* Grouped extras */}
              {MORE_GROUPS.map((group) => (
                <div key={group.label}>
                  <div className="px-2 mb-2 text-xs uppercase tracking-wider font-bold text-warm-500">
                    {group.label}
                  </div>
                  <div className="space-y-1">
                    {group.items.map((item) => {
                      const Icon = item.icon;
                      const active = isActive(item.href);
                      return (
                        <Link
                          key={item.href}
                          href={item.href}
                          onClick={() => setMobileMenuOpen(false)}
                          className={cn(
                            'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all',
                            active
                              ? 'bg-primary-100 text-primary-700'
                              : 'text-warm-700 hover:bg-warm-50 active:bg-warm-100'
                          )}
                        >
                          <Icon className="w-5 h-5 shrink-0" />
                          <span>{item.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              ))}

              {/* Account section */}
              {user && (
                <div>
                  <div className="px-2 mb-2 text-xs uppercase tracking-wider font-bold text-warm-500">
                    Account
                  </div>
                  <div className="space-y-1">
                    <Link
                      href="/settings"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-warm-700 hover:bg-warm-50 active:bg-warm-100"
                    >
                      <Settings className="w-5 h-5 shrink-0" />
                      <span>Settings</span>
                    </Link>
                    <Link
                      href="/pricing"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-warm-700 hover:bg-warm-50 active:bg-warm-100"
                    >
                      <Sparkles className="w-5 h-5 shrink-0" />
                      <span>Upgrade</span>
                    </Link>
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        handleLogout();
                      }}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 active:bg-red-100"
                    >
                      <LogOut className="w-5 h-5 shrink-0" />
                      <span>Sign out</span>
                    </button>
                  </div>
                  <div className="px-4 pt-3 pb-1 text-xs text-warm-500 truncate">
                    {user.email}
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {/* Profile Edit Modal */}
      <Dialog open={showEditProfile} onOpenChange={setShowEditProfile}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="due-date">Due Date</Label>
              <Input
                id="due-date"
                type="date"
                value={editDueDate}
                onChange={(e) => setEditDueDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="state">State</Label>
              <Select
                value={editState}
                onValueChange={(value) => setEditState(value)}
              >
                <SelectTrigger id="state">
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent>
                  {[
                    'Alabama','Alaska','Arizona','Arkansas','California','Colorado',
                    'Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho',
                    'Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana',
                    'Maine','Maryland','Massachusetts','Michigan','Minnesota',
                    'Mississippi','Missouri','Montana','Nebraska','Nevada',
                    'New Hampshire','New Jersey','New Mexico','New York',
                    'North Carolina','North Dakota','Ohio','Oklahoma','Oregon',
                    'Pennsylvania','Rhode Island','South Carolina','South Dakota',
                    'Tennessee','Texas','Utah','Vermont','Virginia','Washington',
                    'West Virginia','Wisconsin','Wyoming','District of Columbia',
                  ].map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setShowEditProfile(false)}>
              Cancel
            </Button>
            <Button
              onClick={async () => {
                if (!user?.id) {
                  alert('Please sign in again');
                  return;
                }
                setSavingProfile(true);
                try {
                  const { error } = await updateProfile(user.id, {
                    due_date: editDueDate || null,
                    state: editState || null,
                  });
                  if (error) {
                    alert('Failed to save: ' + error.message);
                  } else if (profile) {
                    setProfile({
                      ...profile,
                      due_date: editDueDate || null,
                      state: editState || null,
                    });
                    setShowEditProfile(false);
                  }
                } catch (err: any) {
                  alert('Error: ' + err.message);
                } finally {
                  setSavingProfile(false);
                }
              }}
              disabled={savingProfile}
            >
              {savingProfile ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
