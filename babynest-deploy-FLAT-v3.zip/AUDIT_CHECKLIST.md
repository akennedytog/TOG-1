# BabyNest Comprehensive Audit Checklist

## Legal Disclaimers to Add to EVERY Page:

### Global Footer Disclaimer (add to layout.tsx):
```
This app is for educational purposes only. Not medical advice. 
Not HIPAA compliant. Consult healthcare providers for medical decisions.
```

### Page-Specific Disclaimers:

1. **Hospital Costs** (`/hospital-costs`)
   - "Costs shown are estimates for demonstration only. Contact hospitals directly for actual pricing."

2. **Provider Directory** (`/providers`)
   - "Providers listed for demonstration purposes. Verify credentials and availability independently."

3. **Is It Safe?** (`/is-it-safe`)
   - "Always consult your healthcare provider before making decisions about medications, foods, or activities during pregnancy."

4. **Week-by-Week** (`/week-by-week`)
   - "Every pregnancy is different. Consult your healthcare provider for personalized medical advice."

5. **Due Date Calculator** (`/due-date-calculator`)
   - "Estimates only. Confirm due date with your healthcare provider."

6. **Baby Names** (`/baby-names`)
   - "Name meanings and origins are for reference only."

7. **Community Q&A** (`/community`)
   - "Community answers are not medical advice. Always consult professionals."

8. **Financial Timeline** (`/financial-timeline`)
   - "Financial estimates are for planning purposes only. Consult financial advisors."

9. **Readiness Score** (`/readiness`)
   - "Score is for self-assessment only. Not a guarantee of readiness."

10. **Baby Name + 529** (`/baby-name`)
    - "Projections are estimates only. Actual returns may vary."

## Functional Issues to Fix:

### Critical Priority:
- [ ] Verify all 4 fixes from earlier are synced to babynest-full-fixed
- [ ] Add loading states to all async operations
- [ ] Add error handling to all API calls
- [ ] Add confirmation dialogs for delete actions

### High Priority:
- [ ] Test every checkbox on every page
- [ ] Test every form submission
- [ ] Test all modal open/close
- [ ] Verify mobile responsive

### Medium Priority:
- [ ] Add empty state illustrations
- [ ] Add hover states to all buttons
- [ ] Add focus states for accessibility
