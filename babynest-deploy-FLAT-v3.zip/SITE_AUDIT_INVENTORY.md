# BabyNest App - Complete Site Inventory

> **Audit Date:** 2026-05-19  
> **App Type:** Next.js 15+ React Application  
> **Architecture:** App Router (app/ directory)

---

## 📊 Summary Statistics

| Category | Count |
|----------|-------|
| **Total Pages** | 28+ |
| **Route Groups** | 7 |
| **API Routes** | 12 |
| **Main Components** | 40+ |
| **UI Components** | 22 |
| **Animation Components** | 3 |

---

## 🏠 Main Pages (Public & Authenticated)

### Landing & Marketing Pages

| Route | File | Description |
|-------|------|-------------|
| `/` | `app/page.tsx` | **Landing Page** - Marketing homepage with waitlist signup, features showcase, testimonials, pricing tiers, FAQ |
| `/pricing` | `app/pricing/page.tsx` | **Pricing Page** - Plan comparison (Free/Pro/Family), feature matrix, FAQ, trust badges |

### Authentication Pages

| Route | File | Description |
|-------|------|-------------|
| `/auth/signin` | `app/auth/signin/page.tsx` | **Sign In** - Email/password login with Supabase |
| `/auth/signup` | `app/auth/signup/page.tsx` | **Sign Up** - Account creation with state/due date capture |
| `/auth/reset-password` | `app/auth/reset-password/page.tsx` | **Password Reset** - Forgot password flow |
| `/auth/callback` | `app/auth/callback/page.tsx` | **Auth Callback** - OAuth/confirmation handler |

### Onboarding Flow

| Route | File | Description |
|-------|------|-------------|
| `/onboarding` | `app/onboarding/page.tsx` | **Onboarding Wizard** - 6-step flow: Welcome → State → Personal Info → Insurance → Review → Tour |

### Core Dashboard & Tools

| Route | File | Description |
|-------|------|-------------|
| `/dashboard` | `app/dashboard/page.tsx` | **Main Dashboard** - Personalized command center with pregnancy stats, urgent tasks, finance center, tabbed interface for all tools |
| `/settings` | `app/settings/page.tsx` | **Settings** - Notification preferences, family sharing, subscription management |
| `/settings/family` | `app/settings/family/page.tsx` | **Family Settings** - Family sharing management dedicated page |

### Financial Tools

| Route | File | Description |
|-------|------|-------------|
| `/financial-timeline` | `app/financial-timeline/page.tsx` | **Financial Timeline** - Week-by-week pregnancy financial tasks with deadlines |
| `/hospital-costs` | `app/hospital-costs/page.tsx` | **Hospital Cost Estimator** - ZIP-based hospital cost comparison tool |
| `/readiness` | `app/readiness/page.tsx` | **Financial Readiness Score** - Quiz-based assessment (100 points) across insurance/savings/legal/taxes |
| `/baby-name` | `app/baby-name/page.tsx` | **529 Calculator** - Baby name + college savings projection tool |
| `/leave-calculator` | `app/leave-calculator/page.tsx` | **Maternity Leave Calculator** - Leave planning tool |

### Pregnancy Tracking

| Route | File | Description |
|-------|------|-------------|
| `/week-by-week` | `app/week-by-week/page.tsx` | **Week-by-Week Overview** - Grid of 40 weeks, trimester filtering |
| `/week-by-week/[week]` | `app/week-by-week/[week]/page.tsx` | **Week Detail** - Dynamic pregnancy week details: baby development, symptoms, medical milestones, financial deadlines |
| `/due-date-calculator` | `app/due-date-calculator/page.tsx` | **Due Date Calculator** - LMP/conception-based due date estimation |
| `/is-it-safe` | `app/is-it-safe/page.tsx` | **Pregnancy Safety Database** - Searchable safety guide for foods, medications, activities |
| `/milestones` | `app/milestones/page.tsx` | **Development Milestones** - Gamified financial task tracker with points/rewards |
| `/postpartum` | `app/postpartum/page.tsx` | **Postpartum Tracker** - Recovery tasks, baby metrics tracking, milestone tracking |

### Baby Preparation

| Route | File | Description |
|-------|------|-------------|
| `/baby-names` | `app/baby-names/page.tsx` | **Baby Names Explorer** - Name browsing with meanings/origins |
| `/registry` | `app/registry/page.tsx` | **Baby Registry** - Registry tracker and import tools |

### Community & Content

| Route | File | Description |
|-------|------|-------------|
| `/blog` | `app/blog/page.tsx` | **Blog Listing** - Article grid with categories |
| `/blog/[slug]` | `app/blog/[slug]/page.tsx` | **Blog Article** - Individual blog post pages |
| `/community` | `app/community/page.tsx` | **Community Q&A** - Parent discussion forum |
| `/providers` | `app/providers/page.tsx` | **Provider Directory** - Healthcare provider listings |

### Family Features

| Route | File | Description |
|-------|------|-------------|
| `/family/join` | `app/family/join/page.tsx` | **Join Family** - Family invitation token acceptance |

---

## 🔌 API Routes

| Route | File | Purpose |
|-------|------|---------|
| `/api/analyze-insurance-doc` | `app/api/analyze-insurance-doc/route.ts` | AI insurance document analysis |
| `/api/analyze-insurance-text` | `app/api/analyze-insurance-text/route.ts` | Text-based insurance analysis |
| `/api/chat` | `app/api/chat/route.ts` | AI chat assistant endpoint |
| `/api/generate-tasks` | `app/api/generate-tasks/route.ts` | Personalized task generation |
| `/api/newsletter` | `app/api/newsletter/route.ts` | Email newsletter subscription |
| `/api/ocr` | `app/api/ocr/route.ts` | Document OCR processing |
| `/api/push/subscribe` | `app/api/push/subscribe/route.ts` | Push notification subscription |
| `/api/push/unsubscribe` | `app/api/push/unsubscribe/route.ts` | Push notification unsubscription |
| `/api/registry/import` | `app/api/registry/import/route.ts` | Registry import functionality |
| `/api/registry/scrape` | `app/api/registry/scrape/route.ts` | Registry scraping from retailers |
| `/api/stripe/create-checkout` | `app/api/stripe/create-checkout/route.ts` | Stripe payment processing |
| `/api/tasks` | `app/api/tasks/route.ts` | Task CRUD operations |

---

## 🧩 Component Inventory

### Layout & Shell Components

| Component | Location | Purpose |
|-----------|----------|---------|
| `RootLayout` | `app/layout.tsx` | Global layout with metadata, SharedHeader, LegalFooter, Vercel Analytics |
| `OnboardingLayout` | `app/onboarding/layout.tsx` | Onboarding-specific layout wrapper |
| `SharedHeader` | `components/SharedHeader.tsx` | App-wide navigation header |
| `LegalDisclaimer` | `components/LegalDisclaimer.tsx` | Medical/legal disclaimers |

### Dashboard Components (Tab Content)

| Component | Location | Purpose |
|-----------|----------|---------|
| `SmartTaskManager` | `components/SmartTaskManager.tsx` | AI-powered task management with categorization |
| `SavingsGoals` | `components/SavingsGoals.tsx` | 529/college savings goal tracker |
| `BudgetTracker` | `components/BudgetTracker.tsx` | Monthly budget and expense tracking |
| `BabyCostCalculator` | `components/BabyCostCalculator.tsx` | Baby cost estimation tool |
| `HospitalBagPlanner` | `components/HospitalBagPlanner.tsx` | Packing checklist for hospital |
| `PregnancyTracker` | `components/PregnancyTracker.tsx` | Pregnancy progress tracking |
| `VaccinationTracker` | `components/VaccinationTracker.tsx` | Baby vaccination schedule |
| `BirthPlanBuilder` | `components/BirthPlanBuilder.tsx` | Birth plan creation tool |
| `InsuranceDocumentAnalyzer` | `components/InsuranceDocumentAnalyzer.tsx` | AI insurance document parser |
| `RegistryTracker` | `components/RegistryTracker.tsx` | Baby registry management |
| `Chat` | `components/Chat.tsx` | AI assistant chat interface |
| `ContractionTimer` | `components/ContractionTimer.tsx` | Labor contraction timing |
| `KickCounter` | `components/KickCounter.tsx` | Baby kick/movement tracker |
| `DocumentVault` | `components/DocumentVault.tsx` | Document storage |
| `FamilySharingManager` | `components/FamilySharingManager.tsx` | Family member invitations |
| `NotificationSettings` | `components/NotificationSettings.tsx` | Push/email preferences |
| `PushNotificationSettings` | `components/PushNotificationSettings.tsx` | Browser push config |
| `CommunityQA` / `CommunityQandA` | `components/CommunityQA.tsx` / `CommunityQandA.tsx` | Q&A forum components |

### Tool Components

| Component | Location | Purpose |
|-----------|----------|---------|
| `DueDateCalculator` | `app/due-date-calculator/DueDateCalculator.tsx` | Due date calculation logic |
| `IsItSafe` | `app/is-it-safe/IsItSafe.tsx` | Pregnancy safety search interface |
| `BabyNamesContent` | `app/baby-names/BabyNamesContent.tsx` | Baby names list display |
| `MaternityLeaveCalculator` | `components/MaternityLeaveCalculator.tsx` | Leave benefits calculator |
| `InsuranceUploader` | `components/InsuranceUploader.tsx` | Insurance card upload |
| `MyNamesList` | `components/MyNamesList.tsx` | Saved baby names |
| `ProviderDirectory` | `components/ProviderDirectory.tsx` | Healthcare provider search |
| `RegistryImportModal` | `components/RegistryImportModal.tsx` | Import from retailers |
| `Timeline` | `components/Timeline.tsx` | Visual timeline display |
| `StripePricing` | `components/StripePricing.tsx` | Stripe payment integration |
| `TaskManager` | `components/TaskManager.tsx` | Basic task list (legacy) |

### Onboarding Step Components

| Component | Location | Purpose |
|-----------|----------|---------|
| `WelcomeStep` | `app/onboarding/components/WelcomeStep.tsx` | Onboarding welcome screen |
| `StateStep` | `app/onboarding/components/StateStep.tsx` | State selection |
| `PersonalInfoStep` | `app/onboarding/components/PersonalInfoStep.tsx` | Due date, income, family |
| `InsuranceStep` | `app/onboarding/components/InsuranceStep.tsx` | Insurance provider capture |
| `ReviewStep` | `app/onboarding/components/ReviewStep.tsx` | Task preview before generation |
| `TourStep` | `app/onboarding/components/TourStep.tsx` | App feature tour |

### Animation Components

| Component | Location | Purpose |
|-----------|----------|---------|
| `AnimatedBackground` | `components/animations/AnimatedBackground.tsx` | Dynamic gradient backgrounds |
| `ScrollReveal` | `components/animations/ScrollReveal.tsx` | Scroll-triggered animations |
| `StaggerContainer` / `StaggerItem` | `components/animations/StaggerContainer.tsx` | Staggered child animations |

### UI Components (shadcn/ui based)

| Component | Location |
|-----------|----------|
| `Alert` | `components/ui/alert.tsx` |
| `Avatar` | `components/ui/avatar.tsx` |
| `Badge` | `components/ui/badge.tsx` |
| `Button` | `components/ui/button.tsx` |
| `Card` | `components/ui/card.tsx` |
| `Checkbox` | `components/ui/checkbox.tsx` |
| `Collapsible` | `components/ui/collapsible.tsx` |
| `Dialog` | `components/ui/dialog.tsx` |
| `DropdownMenu` | `components/ui/dropdown-menu.tsx` |
| `GlassCard` / `ColoredGlassCard` | `components/ui/GlassCard.tsx` |
| `Input` | `components/ui/input.tsx` |
| `Label` | `components/ui/label.tsx` |
| `Progress` | `components/ui/progress.tsx` |
| `RadioGroup` | `components/ui/radio-group.tsx` |
| `ScrollArea` | `components/ui/scroll-area.tsx` |
| `Select` | `components/ui/select.tsx` |
| `Separator` | `components/ui/separator.tsx` |
| `Skeleton` | `components/ui/skeleton.tsx` |
| `Switch` | `components/ui/switch.tsx` |
| `Tabs` | `components/ui/tabs.tsx` |
| `Textarea` | `components/ui/textarea.tsx` |

---

## 📁 Directory Structure

```
app/
├── page.tsx                    # Landing page
├── layout.tsx                  # Root layout
├── admin/                      # Admin routes (if any)
├── api/                        # API routes
│   ├── analyze-insurance-doc/
│   ├── analyze-insurance-text/
│   ├── chat/
│   ├── generate-tasks/
│   ├── newsletter/
│   ├── ocr/
│   ├── push/
│   │   ├── subscribe/
│   │   └── unsubscribe/
│   ├── registry/
│   │   ├── import/
│   │   └── scrape/
│   ├── stripe/
│   │   └── create-checkout/
│   └── tasks/
├── auth/                       # Authentication pages
│   ├── callback/
│   ├── reset-password/
│   ├── signin/
│   └── signup/
├── baby-name/                  # 529 calculator
├── baby-names/                 # Name explorer
├── blog/                       # Blog
│   ├── [slug]/
│   └── page.tsx
├── community/                  # Q&A forum
├── dashboard/                  # Main dashboard
├── due-date-calculator/        # Due date tool
│   ├── DueDateCalculator.tsx
│   └── page.tsx
├── family/                     # Family features
│   └── join/
├── financial-timeline/         # Financial planning
├── hospital-costs/             # Cost estimator
├── is-it-safe/                 # Safety database
│   ├── IsItSafe.tsx
│   └── page.tsx
├── leave-calculator/           # Leave planning
├── milestones/                 # Gamified milestones
├── onboarding/                 # Onboarding flow
│   ├── components/
│   │   ├── InsuranceStep.tsx
│   │   ├── PersonalInfoStep.tsx
│   │   ├── ReviewStep.tsx
│   │   ├── StateStep.tsx
│   │   ├── TourStep.tsx
│   │   └── WelcomeStep.tsx
│   ├── layout.tsx
│   └── page.tsx
├── postpartum/                 # Postpartum tracking
├── pricing/                    # Pricing page
├── providers/                  # Provider directory
├── readiness/                  # Readiness score
├── registry/                   # Baby registry
├── settings/                 # Settings
│   ├── family/
│   └── page.tsx
└── week-by-week/             # Pregnancy guide
    ├── [week]/
    │   ├── WeekDetailClient.tsx
    │   └── page.tsx
    └── page.tsx

components/
├── animations/                 # Animation components
├── ui/                         # UI primitives
├── BabyCostCalculator.tsx
├── BirthPlanBuilder.tsx
├── BudgetTracker.tsx
├── Chat.tsx
├── CommunityQA.tsx / CommunityQandA.tsx
├── ContractionTimer.tsx
├── DocumentVault.tsx
├── FamilySharingManager.tsx
├── HospitalBagPlanner.tsx
├── InsuranceDocumentAnalyzer.tsx
├── InsuranceUploader.tsx
├── KickCounter.tsx
├── LegalDisclaimer.tsx
├── MaternityLeaveCalculator.tsx
├── MyNamesList.tsx
├── NotificationSettings.tsx
├── PregnancyTracker.tsx
├── ProviderDirectory.tsx
├── PushNotificationSettings.tsx
├── RegistryImportModal.tsx
├── RegistryTracker.tsx
├── SavingsGoals.tsx
├── SharedHeader.tsx
├── SmartTaskManager.tsx
├── StripePricing.tsx
├── TaskManager.tsx
├── Timeline.tsx
└── VaccinationTracker.tsx

lib/                          # Utility libraries
├── supabase.ts              # Supabase client
├── utils.ts / cn.ts         # Utilities
├── onboarding.ts            # Onboarding helpers
├── ai-task-categorizer.ts   # AI task grouping
├── blog-data.ts             # Blog content
└── pregnancy-weeks.ts       # Week data

types/
└── database.ts              # TypeScript types

public/                       # Static assets
```

---

## 🔑 Key Features Summary

### Authentication & User Management
- Email/password authentication via Supabase
- OAuth callbacks for social login
- Profile-based personalization (state, due date, income)
- Family sharing with invite tokens

### Financial Planning
- Week-by-week financial timeline with 40 weeks of tasks
- Hospital cost comparison by ZIP code
- 529 plan calculator with projections
- Budget tracking with monthly goals
- Savings goals for multiple objectives
- Readiness score assessment
- AI-generated personalized task lists

### Pregnancy Tracking
- 40-week pregnancy guide with baby development
- Symptom tracking per week
- Medical milestone reminders
- Due date calculator
- "Is It Safe" searchable database
- Contraction timer
- Kick counter
- Postpartum recovery tracker

### Baby Preparation
- Baby name explorer with 529 projections
- Hospital bag checklist
- Birth plan builder
- Vaccination schedule tracker
- Baby registry tracker with import

### AI Features
- Chat assistant for pregnancy/baby questions
- Insurance document analyzer (OCR + AI)
- Task generation based on user profile
- Smart task categorization (urgent, quick wins, etc.)

### Community & Content
- Blog with SEO-optimized articles
- Community Q&A forum
- Provider directory

---

## 🎨 UI/UX Patterns

- **Design System:** Warm, baby-friendly color palette (cream, pink, blue, amber)
- **Components:** shadcn/ui with custom glassmorphism (`GlassCard`, `ColoredGlassCard`)
- **Animations:** Framer Motion for transitions, staggered reveals, scroll effects
- **Responsive:** Mobile-first with responsive grids
- **Accessibility:** Proper labels, keyboard navigation, focus states

---

## 🔗 External Integrations

| Service | Usage |
|---------|-------|
| **Supabase** | Auth, database, storage |
| **Stripe** | Payment processing |
| **OpenAI** | AI chat, document analysis |
| **Vercel** | Analytics, Speed Insights |
| **Resend** | Email (newsletter, notifications) |

---

## 📝 Notes

- The app uses Next.js App Router with server and client components
- Many dashboard tools are embedded as tab content within `/dashboard`
- The onboarding flow generates personalized tasks based on user state/due date
- LocalStorage used for some client-side state (checklists, UI preferences)
- Supabase handles real-time data for tasks, metrics, and family sharing

---

*Generated by Site Audit - BabyNest Full Inventory*
