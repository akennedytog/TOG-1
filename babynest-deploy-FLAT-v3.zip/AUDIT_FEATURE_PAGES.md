# Feature Pages Visual Consistency Audit

**Date:** 2026-05-19  
**Audited by:** Subagent Audit Task  
**Scope:** Review visual consistency across 5 feature pages

---

## Summary

| Page | Status | SharedHeader | Loading State | Animation | Color Scheme | Typography |
|------|--------|--------------|---------------|-----------|--------------|------------|
| Financial Timeline | ✅ Consistent | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes | ✅ Yes |
| Milestones | ✅ Consistent | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes | ✅ Yes |
| Hospital Costs | ⚠️ Inconsistent | ❌ No | ❌ No | ❌ None | ⚠️ Partial | ✅ Yes |
| Postpartum | ✅ Consistent | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes | ✅ Yes |
| Insurance | ❌ Missing | - | - | - | - | - |

---

## Detailed Findings

### 1. Financial Timeline (`app/financial-timeline/page.tsx`)

**Status:** ✅ Consistent

**Strengths:**
- Uses `SharedHeader` component (via layout)
- Has proper loading state with `Loader2` animation
- Follows color scheme: `bg-cream-50` background, `primary-600/700` gradients
- Uses consistent typography scale with `text-warm-900`, `text-warm-600`
- Includes `LegalDisclaimer` component
- Uses `Card` and `CardContent` from UI components
- Proper icon colors with category-based color system

**Issues:**
- ❌ No framer-motion animations (uses CSS transitions only)
- ❌ Missing `ScrollReveal` or `StaggerContainer` animations present in other pages

**Recommendations:**
1. Add `ScrollReveal` wrapper around timeline items for scroll-triggered animations
2. Use `StaggerContainer` for the timeline events list

---

### 2. Milestones (`app/milestones/page.tsx`)

**Status:** ✅ Consistent

**Strengths:**
- Uses `SharedHeader` component (via layout)
- Has proper loading state with `Loader2` animation
- Follows color scheme: `bg-cream-50` background, `primary-600/700` gradients
- Uses consistent typography scale
- Includes `LegalDisclaimer` component
- Uses `Progress` component from UI library

**Issues:**
- ❌ No framer-motion animations
- ❌ Missing animation components from `components/animations/`

**Recommendations:**
1. Add `StaggerContainer`/`StaggerItem` for task cards
2. Use `motion.div` for hover effects on milestone cards

---

### 3. Hospital Costs (`app/hospital-costs/page.tsx`)

**Status:** ⚠️ Inconsistent - Requires Attention

**Strengths:**
- Follows basic color scheme with `bg-cream-50`
- Uses `Card`, `Button`, `Input` from UI components
- Has category-based icon coloring

**Critical Issues:**
- ❌ **NO `SharedHeader` usage** - This page is not wrapped properly
- ❌ **NO loading state** - Missing authentication/profile loading check
- ❌ **NO animations** - No framer-motion or animation components
- ❌ **NO `LegalDisclaimer` import or usage** (has hardcoded disclaimer)

**Recommendations:**
1. **HIGH PRIORITY:** Add authentication check with loading state
2. Use `SharedHeader` via the root layout or import explicitly
3. Add `ScrollReveal` for hospital cards
4. Use `StaggerContainer` for hospital list
5. Replace hardcoded disclaimer with `LegalDisclaimer` component
6. Add proper error boundaries

---

### 4. Postpartum (`app/postpartum/page.tsx`)

**Status:** ✅ Consistent

**Strengths:**
- Uses `SharedHeader` component (via layout)
- Has comprehensive loading state with `Loader2`
- Follows color scheme: `bg-cream-50`, `primary-600/700` gradients
- Uses `Tabs`, `TabsContent`, `TabsList` from UI library
- Includes `LegalDisclaimer` component
- Has category-based color system for tasks
- Uses `Dialog` component for modals

**Issues:**
- ❌ No framer-motion animations for tab transitions
- ❌ Missing `ScrollReveal` for milestones section

**Recommendations:**
1. Add `AnimatePresence` for tab content transitions
2. Use `StaggerContainer` for tasks and milestones

---

### 5. Insurance (`app/insurance/page.tsx`)

**Status:** ❌ MISSING - Page does not exist

**Findings:**
- The `app/insurance/` directory does not exist
- `SharedHeader.tsx` lists `/providers` as the insurance/provider route
- No separate insurance feature page found

**Recommendation:**
- Either create the page or update documentation to reflect that insurance features are consolidated under `/providers`

---

## Pattern Analysis

### Consistent Patterns (Good)

1. **Header Pattern:**
   ```tsx
   <div className="bg-gradient-to-r from-primary-600 to-primary-700 text-white py-8">
     <div className="container mx-auto px-4">
       <h1 className="text-3xl font-bold mb-2">Page Title</h1>
       <p className="text-primary-100">Description</p>
     </div>
   </div>
   ```

2. **Background Pattern:**
   - All pages use `bg-cream-50` for the main wrapper

3. **Container Pattern:**
   - All pages use `container mx-auto px-4` for content

4. **Loading Pattern:**
   ```tsx
   if (loading) {
     return (
       <div className="min-h-screen flex items-center justify-center">
         <Loader2 className="h-8 w-8 animate-spin text-primary-600" />
       </div>
     );
   }
   ```

5. **Color Category System:**
   ```tsx
   const getCategoryColor = (category: string) => {
     switch (category) {
       case 'insurance': return 'text-blue-500 bg-blue-50 border-blue-200';
       case 'savings': return 'text-green-500 bg-green-50 border-green-200';
       // ... etc
     }
   };
   ```

### Inconsistent Patterns (Needs Standardization)

1. **Animation Usage:**
   - Dashboard uses `StaggerContainer`, `ScrollReveal`, `framer-motion`
   - Feature pages use CSS transitions only
   - **Recommendation:** Standardize on animation components

2. **Header Component Usage:**
   - Pages rely on root layout's `SharedHeader`
   - Hospital Costs page seems to bypass this
   - **Recommendation:** Ensure all pages go through layout

3. **Disclaimer Pattern:**
   - Financial Timeline uses `type="financial"`
   - Milestones uses `type="medical"`
   - Hospital Costs has hardcoded amber banner
   - **Recommendation:** Always use `LegalDisclaimer` component

---

## Animation Components Available

Located in `components/animations/`:

1. **`AnimatedBackground`** - Gradient, mesh, particles, waves backgrounds
2. **`ScrollReveal`** - Scroll-triggered fade/slide animations
3. **`StaggerContainer`**/`StaggerItem` - List/item stagger animations

**Usage Examples:**
```tsx
import { StaggerContainer, StaggerItem } from '@/components/animations/StaggerContainer';
import { ScrollReveal } from '@/components/animations/ScrollReveal';

// For lists
<StaggerContainer className="grid gap-4" staggerDelay={0.1}>
  {items.map((item) => (
    <StaggerItem key={item.id}>
      <Card>...</Card>
    </StaggerItem>
  ))}
</StaggerContainer>

// For sections
<ScrollReveal direction="up">
  <SectionContent />
</ScrollReveal>
```

---

## Typography Scale

From Tailwind config and usage:

| Element | Size | Color | Weight |
|---------|------|-------|--------|
| Page Title | `text-3xl` | - | `font-bold` |
| Section Header | `text-xl` | `text-warm-900` | `font-bold` |
| Card Title | `text-lg` | `text-warm-900` | `font-semibold` |
| Body Text | `text-sm` | `text-warm-600` | - |
| Caption/Meta | `text-xs` | `text-warm-500` | - |

---

## Color Scheme

From `tailwind.config.js`:

### Primary (Sage Green)
- `primary-50` to `primary-900`
- Main actions, headers, primary buttons
- Header gradient: `from-primary-600 to-primary-700`

### Accent (Terracotta/Coral)
- `accent-50` to `accent-900`
- Highlights, badges, secondary elements

### Warm Neutrals
- `warm-50` to `warm-900`
- Text, borders, subtle backgrounds
- `text-warm-900` for primary text
- `text-warm-600` for secondary text

### Cream Backgrounds
- `cream-50`, `cream-100`, `cream-200`
- Page backgrounds, card backgrounds

---

## Action Items

### High Priority
1. [ ] Fix Hospital Costs page - add loading state and auth check
2. [ ] Ensure Hospital Costs uses SharedHeader (verify routing through layout)
3. [ ] Add LegalDisclaimer component to Hospital Costs

### Medium Priority
4. [ ] Add StaggerContainer animations to Financial Timeline event list
5. [ ] Add StaggerContainer animations to Milestones task list
6. [ ] Add ScrollReveal to Postpartum milestone cards

### Low Priority
7. [ ] Consider adding subtle framer-motion hover effects to all cards
8. [ ] Standardize on animation patterns across all feature pages
9. [ ] Clarify if Insurance page should exist or consolidate under Providers

---

## Conclusion

Most feature pages follow consistent patterns. The **Hospital Costs page requires immediate attention** as it lacks proper loading states and may bypass the layout structure. The **Insurance page is missing entirely** and needs clarification on whether it should exist or if features are consolidated elsewhere.

Animation usage is inconsistent across pages - consider standardizing on the available animation components in `components/animations/` for a more polished, consistent user experience.
