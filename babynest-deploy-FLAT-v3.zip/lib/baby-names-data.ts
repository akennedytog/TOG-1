// Baby names database

export type Gender = 'boy' | 'girl' | 'neutral';
export type Trend = 'up' | 'down' | 'stable';

export interface BabyName {
  name: string;
  gender: Gender;
  rank: number; // 1 = most popular
  meaning: string;
  origin: string;
  trend: Trend;
}

// ---------- BOYS (Top 100) ----------
export const BOY_NAMES: BabyName[] = [
  { name: 'Liam',       gender: 'boy', rank: 1,  meaning: 'Strong-willed warrior', origin: 'Irish',   trend: 'stable' },
  { name: 'Noah',       gender: 'boy', rank: 2,  meaning: 'Rest, comfort',          origin: 'Hebrew',  trend: 'stable' },
  { name: 'Oliver',     gender: 'boy', rank: 3,  meaning: 'Olive tree',             origin: 'Latin',   trend: 'up' },
  { name: 'James',      gender: 'boy', rank: 4,  meaning: 'Supplanter',             origin: 'Hebrew',  trend: 'stable' },
  { name: 'Elijah',     gender: 'boy', rank: 5,  meaning: 'My God is Yahweh',       origin: 'Hebrew',  trend: 'up' },
  { name: 'Mateo',      gender: 'boy', rank: 6,  meaning: 'Gift of God',            origin: 'Spanish', trend: 'up' },
  { name: 'Theodore',   gender: 'boy', rank: 7,  meaning: 'Gift of God',            origin: 'Greek',   trend: 'up' },
  { name: 'Lucas',      gender: 'boy', rank: 8,  meaning: 'Light, illumination',    origin: 'Latin',   trend: 'stable' },
  { name: 'Henry',      gender: 'boy', rank: 9,  meaning: 'Ruler of the home',      origin: 'German',  trend: 'up' },
  { name: 'William',    gender: 'boy', rank: 10, meaning: 'Resolute protector',     origin: 'German',  trend: 'down' },
  { name: 'Benjamin',   gender: 'boy', rank: 11, meaning: 'Son of the right hand',  origin: 'Hebrew',  trend: 'stable' },
  { name: 'Levi',       gender: 'boy', rank: 12, meaning: 'Joined, attached',       origin: 'Hebrew',  trend: 'up' },
  { name: 'Sebastian',  gender: 'boy', rank: 13, meaning: 'Venerable',              origin: 'Greek',   trend: 'stable' },
  { name: 'Jack',       gender: 'boy', rank: 14, meaning: 'God is gracious',        origin: 'English', trend: 'stable' },
  { name: 'Ezra',       gender: 'boy', rank: 15, meaning: 'Help',                   origin: 'Hebrew',  trend: 'up' },
  { name: 'Michael',    gender: 'boy', rank: 16, meaning: 'Who is like God?',       origin: 'Hebrew',  trend: 'down' },
  { name: 'Daniel',     gender: 'boy', rank: 17, meaning: 'God is my judge',        origin: 'Hebrew',  trend: 'stable' },
  { name: 'Leo',        gender: 'boy', rank: 18, meaning: 'Lion',                   origin: 'Latin',   trend: 'up' },
  { name: 'Owen',       gender: 'boy', rank: 19, meaning: 'Young warrior',          origin: 'Welsh',   trend: 'stable' },
  { name: 'Samuel',     gender: 'boy', rank: 20, meaning: 'Heard by God',           origin: 'Hebrew',  trend: 'stable' },
  { name: 'Hudson',     gender: 'boy', rank: 21, meaning: 'Son of Hudd',            origin: 'English', trend: 'up' },
  { name: 'Alexander',  gender: 'boy', rank: 22, meaning: 'Defender of the people', origin: 'Greek',   trend: 'stable' },
  { name: 'Asher',      gender: 'boy', rank: 23, meaning: 'Happy, blessed',         origin: 'Hebrew',  trend: 'up' },
  { name: 'Luca',       gender: 'boy', rank: 24, meaning: 'Light',                  origin: 'Italian', trend: 'up' },
  { name: 'Ethan',      gender: 'boy', rank: 25, meaning: 'Strong, enduring',       origin: 'Hebrew',  trend: 'down' },
  { name: 'John',       gender: 'boy', rank: 26, meaning: 'God is gracious',        origin: 'Hebrew',  trend: 'down' },
  { name: 'David',      gender: 'boy', rank: 27, meaning: 'Beloved',                origin: 'Hebrew',  trend: 'down' },
  { name: 'Jackson',    gender: 'boy', rank: 28, meaning: 'Son of Jack',            origin: 'English', trend: 'down' },
  { name: 'Joseph',     gender: 'boy', rank: 29, meaning: 'He will add',            origin: 'Hebrew',  trend: 'stable' },
  { name: 'Mason',      gender: 'boy', rank: 30, meaning: 'Stoneworker',            origin: 'English', trend: 'down' },
  { name: 'Luke',       gender: 'boy', rank: 31, meaning: 'Light-giving',           origin: 'Latin',   trend: 'stable' },
  { name: 'Matthew',    gender: 'boy', rank: 32, meaning: 'Gift of God',            origin: 'Hebrew',  trend: 'down' },
  { name: 'Aiden',      gender: 'boy', rank: 33, meaning: 'Little fire',            origin: 'Irish',   trend: 'down' },
  { name: 'Lincoln',    gender: 'boy', rank: 34, meaning: 'Town by the lake',       origin: 'English', trend: 'up' },
  { name: 'Wyatt',      gender: 'boy', rank: 35, meaning: 'Brave in war',           origin: 'English', trend: 'stable' },
  { name: 'Anthony',    gender: 'boy', rank: 36, meaning: 'Priceless one',          origin: 'Latin',   trend: 'down' },
  { name: 'Isaac',      gender: 'boy', rank: 37, meaning: 'Laughter',               origin: 'Hebrew',  trend: 'stable' },
  { name: 'Grayson',    gender: 'boy', rank: 38, meaning: 'Son of the steward',     origin: 'English', trend: 'up' },
  { name: 'Jayden',     gender: 'boy', rank: 39, meaning: 'Thankful',               origin: 'American', trend: 'down' },
  { name: 'Julian',     gender: 'boy', rank: 40, meaning: 'Youthful',               origin: 'Latin',   trend: 'up' },
  { name: 'Gabriel',    gender: 'boy', rank: 41, meaning: 'God is my strength',     origin: 'Hebrew',  trend: 'stable' },
  { name: 'Anthony',    gender: 'boy', rank: 42, meaning: 'Priceless',              origin: 'Roman',   trend: 'down' },
  { name: 'Dylan',      gender: 'boy', rank: 43, meaning: 'Son of the sea',         origin: 'Welsh',   trend: 'down' },
  { name: 'Carter',     gender: 'boy', rank: 44, meaning: 'Cart driver',            origin: 'English', trend: 'stable' },
  { name: 'Christopher',gender: 'boy', rank: 45, meaning: 'Bearer of Christ',       origin: 'Greek',   trend: 'down' },
  { name: 'Andrew',     gender: 'boy', rank: 46, meaning: 'Manly, brave',           origin: 'Greek',   trend: 'down' },
  { name: 'Joshua',     gender: 'boy', rank: 47, meaning: 'God is salvation',       origin: 'Hebrew',  trend: 'down' },
  { name: 'Nathan',     gender: 'boy', rank: 48, meaning: 'Gift from God',          origin: 'Hebrew',  trend: 'stable' },
  { name: 'Caleb',      gender: 'boy', rank: 49, meaning: 'Wholehearted',           origin: 'Hebrew',  trend: 'stable' },
  { name: 'Ryan',       gender: 'boy', rank: 50, meaning: 'Little king',            origin: 'Irish',   trend: 'down' },
  { name: 'Adrian',     gender: 'boy', rank: 51, meaning: 'From Hadria',            origin: 'Latin',   trend: 'stable' },
  { name: 'Miles',      gender: 'boy', rank: 52, meaning: 'Soldier, merciful',      origin: 'Latin',   trend: 'up' },
  { name: 'Eli',        gender: 'boy', rank: 53, meaning: 'Ascension',              origin: 'Hebrew',  trend: 'up' },
  { name: 'Nolan',      gender: 'boy', rank: 54, meaning: 'Champion',               origin: 'Irish',   trend: 'up' },
  { name: 'Christian',  gender: 'boy', rank: 55, meaning: 'Follower of Christ',     origin: 'Greek',   trend: 'down' },
  { name: 'Aaron',      gender: 'boy', rank: 56, meaning: 'High mountain',          origin: 'Hebrew',  trend: 'stable' },
  { name: 'Cameron',    gender: 'boy', rank: 57, meaning: 'Crooked nose',           origin: 'Scottish', trend: 'stable' },
  { name: 'Ezekiel',    gender: 'boy', rank: 58, meaning: 'God strengthens',        origin: 'Hebrew',  trend: 'up' },
  { name: 'Colton',     gender: 'boy', rank: 59, meaning: 'Coal town',              origin: 'English', trend: 'stable' },
  { name: 'Luca',       gender: 'boy', rank: 60, meaning: 'Bringer of light',       origin: 'Italian', trend: 'up' },
  { name: 'Landon',     gender: 'boy', rank: 61, meaning: 'Long hill',              origin: 'English', trend: 'stable' },
  { name: 'Hunter',     gender: 'boy', rank: 62, meaning: 'One who hunts',          origin: 'English', trend: 'stable' },
  { name: 'Jonathan',   gender: 'boy', rank: 63, meaning: 'Gift of God',            origin: 'Hebrew',  trend: 'down' },
  { name: 'Santiago',   gender: 'boy', rank: 64, meaning: 'Saint James',            origin: 'Spanish', trend: 'up' },
  { name: 'Axel',       gender: 'boy', rank: 65, meaning: 'Father of peace',        origin: 'Scandinavian', trend: 'up' },
  { name: 'Easton',     gender: 'boy', rank: 66, meaning: 'East-facing place',      origin: 'English', trend: 'stable' },
  { name: 'Cooper',     gender: 'boy', rank: 67, meaning: 'Barrel-maker',           origin: 'English', trend: 'stable' },
  { name: 'Jeremiah',   gender: 'boy', rank: 68, meaning: 'Appointed by God',       origin: 'Hebrew',  trend: 'stable' },
  { name: 'Angel',      gender: 'boy', rank: 69, meaning: 'Messenger of God',       origin: 'Greek',   trend: 'down' },
  { name: 'Roman',      gender: 'boy', rank: 70, meaning: 'Citizen of Rome',        origin: 'Latin',   trend: 'up' },
  { name: 'Connor',     gender: 'boy', rank: 71, meaning: 'Lover of hounds',        origin: 'Irish',   trend: 'down' },
  { name: 'Jameson',    gender: 'boy', rank: 72, meaning: 'Son of James',           origin: 'Scottish', trend: 'up' },
  { name: 'Robert',     gender: 'boy', rank: 73, meaning: 'Bright fame',            origin: 'German',  trend: 'down' },
  { name: 'Greyson',    gender: 'boy', rank: 74, meaning: 'Son of the gray-haired one', origin: 'English', trend: 'up' },
  { name: 'Jordan',     gender: 'boy', rank: 75, meaning: 'To flow down',           origin: 'Hebrew',  trend: 'stable' },
  { name: 'Ian',        gender: 'boy', rank: 76, meaning: 'God is gracious',        origin: 'Scottish', trend: 'stable' },
  { name: 'Carson',     gender: 'boy', rank: 77, meaning: 'Son of Carr',            origin: 'Scottish', trend: 'stable' },
  { name: 'Jaxon',      gender: 'boy', rank: 78, meaning: 'Son of Jack',            origin: 'English', trend: 'down' },
  { name: 'Leonardo',   gender: 'boy', rank: 79, meaning: 'Bold lion',              origin: 'Italian', trend: 'up' },
  { name: 'Nicholas',   gender: 'boy', rank: 80, meaning: 'Victory of the people',  origin: 'Greek',   trend: 'down' },
  { name: 'Dominic',    gender: 'boy', rank: 81, meaning: 'Belonging to the Lord',  origin: 'Latin',   trend: 'stable' },
  { name: 'Austin',     gender: 'boy', rank: 82, meaning: 'Great, magnificent',     origin: 'English', trend: 'down' },
  { name: 'Everett',    gender: 'boy', rank: 83, meaning: 'Brave as a wild boar',   origin: 'English', trend: 'up' },
  { name: 'Brooks',     gender: 'boy', rank: 84, meaning: 'Small stream',           origin: 'English', trend: 'up' },
  { name: 'Xavier',     gender: 'boy', rank: 85, meaning: 'New house, bright',      origin: 'Basque',  trend: 'stable' },
  { name: 'Kai',        gender: 'boy', rank: 86, meaning: 'Sea',                    origin: 'Hawaiian', trend: 'up' },
  { name: 'Jose',       gender: 'boy', rank: 87, meaning: 'He will add',            origin: 'Spanish', trend: 'stable' },
  { name: 'Parker',     gender: 'boy', rank: 88, meaning: 'Park keeper',            origin: 'English', trend: 'stable' },
  { name: 'Adam',       gender: 'boy', rank: 89, meaning: 'Earth, man',             origin: 'Hebrew',  trend: 'stable' },
  { name: 'Jose',       gender: 'boy', rank: 90, meaning: 'God will increase',      origin: 'Spanish', trend: 'stable' },
  { name: 'Jace',       gender: 'boy', rank: 91, meaning: 'Healer',                 origin: 'American', trend: 'stable' },
  { name: 'Wesley',     gender: 'boy', rank: 92, meaning: 'Western meadow',         origin: 'English', trend: 'stable' },
  { name: 'Kayden',     gender: 'boy', rank: 93, meaning: 'Battle, companion',      origin: 'American', trend: 'down' },
  { name: 'Silas',      gender: 'boy', rank: 94, meaning: 'Of the forest',          origin: 'Latin',   trend: 'up' },
  { name: 'Bennett',    gender: 'boy', rank: 95, meaning: 'Blessed',                origin: 'English', trend: 'up' },
  { name: 'Declan',     gender: 'boy', rank: 96, meaning: 'Man of prayer',          origin: 'Irish',   trend: 'up' },
  { name: 'Waylon',     gender: 'boy', rank: 97, meaning: 'Land by the road',       origin: 'English', trend: 'stable' },
  { name: 'Weston',     gender: 'boy', rank: 98, meaning: 'Western town',           origin: 'English', trend: 'up' },
  { name: 'Beau',       gender: 'boy', rank: 99, meaning: 'Handsome',               origin: 'French',  trend: 'up' },
  { name: 'Damian',     gender: 'boy', rank: 100,meaning: 'To tame',                origin: 'Greek',   trend: 'stable' },
];

// ---------- GIRLS (Top 100) ----------
export const GIRL_NAMES: BabyName[] = [
  { name: 'Olivia',     gender: 'girl', rank: 1,  meaning: 'Olive tree',            origin: 'Latin',   trend: 'stable' },
  { name: 'Emma',       gender: 'girl', rank: 2,  meaning: 'Universal, whole',      origin: 'German',  trend: 'stable' },
  { name: 'Charlotte',  gender: 'girl', rank: 3,  meaning: 'Free woman',            origin: 'French',  trend: 'up' },
  { name: 'Amelia',     gender: 'girl', rank: 4,  meaning: 'Industrious',           origin: 'German',  trend: 'up' },
  { name: 'Sophia',     gender: 'girl', rank: 5,  meaning: 'Wisdom',                origin: 'Greek',   trend: 'stable' },
  { name: 'Isabella',   gender: 'girl', rank: 6,  meaning: 'Devoted to God',        origin: 'Italian', trend: 'stable' },
  { name: 'Ava',        gender: 'girl', rank: 7,  meaning: 'Birdlike, lively',      origin: 'Latin',   trend: 'stable' },
  { name: 'Mia',        gender: 'girl', rank: 8,  meaning: 'Mine, beloved',         origin: 'Italian', trend: 'stable' },
  { name: 'Evelyn',     gender: 'girl', rank: 9,  meaning: 'Wished for child',      origin: 'English', trend: 'up' },
  { name: 'Luna',       gender: 'girl', rank: 10, meaning: 'Moon',                  origin: 'Latin',   trend: 'up' },
  { name: 'Harper',     gender: 'girl', rank: 11, meaning: 'Harp player',           origin: 'English', trend: 'stable' },
  { name: 'Sofia',      gender: 'girl', rank: 12, meaning: 'Wisdom',                origin: 'Greek',   trend: 'stable' },
  { name: 'Camila',     gender: 'girl', rank: 13, meaning: 'Young ceremonial attendant', origin: 'Latin', trend: 'up' },
  { name: 'Eliana',     gender: 'girl', rank: 14, meaning: 'My God has answered',   origin: 'Hebrew',  trend: 'up' },
  { name: 'Gianna',     gender: 'girl', rank: 15, meaning: 'God is gracious',       origin: 'Italian', trend: 'up' },
  { name: 'Abigail',    gender: 'girl', rank: 16, meaning: 'Father\'s joy',         origin: 'Hebrew',  trend: 'down' },
  { name: 'Aria',       gender: 'girl', rank: 17, meaning: 'Air, melody',           origin: 'Italian', trend: 'up' },
  { name: 'Avery',      gender: 'girl', rank: 18, meaning: 'Ruler of the elves',    origin: 'English', trend: 'stable' },
  { name: 'Mila',       gender: 'girl', rank: 19, meaning: 'Gracious, dear',        origin: 'Slavic',  trend: 'up' },
  { name: 'Ella',       gender: 'girl', rank: 20, meaning: 'Beautiful fairy',       origin: 'German',  trend: 'stable' },
  { name: 'Scarlett',   gender: 'girl', rank: 21, meaning: 'Red',                   origin: 'English', trend: 'up' },
  { name: 'Ellie',      gender: 'girl', rank: 22, meaning: 'Shining light',         origin: 'English', trend: 'up' },
  { name: 'Nora',       gender: 'girl', rank: 23, meaning: 'Honor, light',          origin: 'Irish',   trend: 'up' },
  { name: 'Hazel',      gender: 'girl', rank: 24, meaning: 'The hazel tree',        origin: 'English', trend: 'up' },
  { name: 'Layla',      gender: 'girl', rank: 25, meaning: 'Night',                 origin: 'Arabic',  trend: 'stable' },
  { name: 'Violet',     gender: 'girl', rank: 26, meaning: 'Purple flower',         origin: 'Latin',   trend: 'up' },
  { name: 'Aurora',     gender: 'girl', rank: 27, meaning: 'Dawn',                  origin: 'Latin',   trend: 'up' },
  { name: 'Penelope',   gender: 'girl', rank: 28, meaning: 'Weaver',                origin: 'Greek',   trend: 'up' },
  { name: 'Chloe',      gender: 'girl', rank: 29, meaning: 'Blooming',              origin: 'Greek',   trend: 'down' },
  { name: 'Riley',      gender: 'girl', rank: 30, meaning: 'Courageous',            origin: 'Irish',   trend: 'down' },
  { name: 'Zoey',       gender: 'girl', rank: 31, meaning: 'Life',                  origin: 'Greek',   trend: 'down' },
  { name: 'Nova',       gender: 'girl', rank: 32, meaning: 'New star',              origin: 'Latin',   trend: 'up' },
  { name: 'Victoria',   gender: 'girl', rank: 33, meaning: 'Victory',               origin: 'Latin',   trend: 'stable' },
  { name: 'Hannah',     gender: 'girl', rank: 34, meaning: 'Grace',                 origin: 'Hebrew',  trend: 'down' },
  { name: 'Lily',       gender: 'girl', rank: 35, meaning: 'Pure, lily flower',     origin: 'English', trend: 'stable' },
  { name: 'Elizabeth',  gender: 'girl', rank: 36, meaning: 'God is my oath',        origin: 'Hebrew',  trend: 'stable' },
  { name: 'Eleanor',    gender: 'girl', rank: 37, meaning: 'Shining light',         origin: 'French',  trend: 'up' },
  { name: 'Grace',      gender: 'girl', rank: 38, meaning: 'God\'s favor',          origin: 'Latin',   trend: 'stable' },
  { name: 'Stella',     gender: 'girl', rank: 39, meaning: 'Star',                  origin: 'Latin',   trend: 'up' },
  { name: 'Maya',       gender: 'girl', rank: 40, meaning: 'Illusion, dream',       origin: 'Sanskrit', trend: 'stable' },
  { name: 'Lucy',       gender: 'girl', rank: 41, meaning: 'Light',                 origin: 'Latin',   trend: 'up' },
  { name: 'Bella',      gender: 'girl', rank: 42, meaning: 'Beautiful',             origin: 'Italian', trend: 'stable' },
  { name: 'Paisley',    gender: 'girl', rank: 43, meaning: 'Church',                origin: 'Scottish', trend: 'down' },
  { name: 'Madelyn',    gender: 'girl', rank: 44, meaning: 'Tower',                 origin: 'English', trend: 'down' },
  { name: 'Naomi',      gender: 'girl', rank: 45, meaning: 'Pleasantness',          origin: 'Hebrew',  trend: 'stable' },
  { name: 'Aaliyah',    gender: 'girl', rank: 46, meaning: 'Exalted',               origin: 'Arabic',  trend: 'stable' },
  { name: 'Elena',      gender: 'girl', rank: 47, meaning: 'Bright, shining light', origin: 'Greek',   trend: 'stable' },
  { name: 'Sarah',      gender: 'girl', rank: 48, meaning: 'Princess',              origin: 'Hebrew',  trend: 'down' },
  { name: 'Ariana',     gender: 'girl', rank: 49, meaning: 'Most holy',             origin: 'Italian', trend: 'stable' },
  { name: 'Allison',    gender: 'girl', rank: 50, meaning: 'Noble',                 origin: 'German',  trend: 'down' },
  { name: 'Gabriella',  gender: 'girl', rank: 51, meaning: 'God is my strength',    origin: 'Italian', trend: 'stable' },
  { name: 'Alice',      gender: 'girl', rank: 52, meaning: 'Noble',                 origin: 'German',  trend: 'up' },
  { name: 'Ivy',        gender: 'girl', rank: 53, meaning: 'Faithfulness',          origin: 'English', trend: 'up' },
  { name: 'Ruby',       gender: 'girl', rank: 54, meaning: 'Red gemstone',          origin: 'Latin',   trend: 'up' },
  { name: 'Anna',       gender: 'girl', rank: 55, meaning: 'Grace',                 origin: 'Hebrew',  trend: 'stable' },
  { name: 'Aubrey',     gender: 'girl', rank: 56, meaning: 'Noble ruler',           origin: 'French',  trend: 'down' },
  { name: 'Emily',      gender: 'girl', rank: 57, meaning: 'Industrious',           origin: 'Latin',   trend: 'down' },
  { name: 'Willow',     gender: 'girl', rank: 58, meaning: 'Willow tree',           origin: 'English', trend: 'up' },
  { name: 'Athena',     gender: 'girl', rank: 59, meaning: 'Goddess of wisdom',     origin: 'Greek',   trend: 'up' },
  { name: 'Leah',       gender: 'girl', rank: 60, meaning: 'Weary',                 origin: 'Hebrew',  trend: 'stable' },
  { name: 'Kennedy',    gender: 'girl', rank: 61, meaning: 'Helmeted chief',        origin: 'Irish',   trend: 'down' },
  { name: 'Madeline',   gender: 'girl', rank: 62, meaning: 'High tower',            origin: 'French',  trend: 'stable' },
  { name: 'Natalie',    gender: 'girl', rank: 63, meaning: 'Born at Christmas',     origin: 'Latin',   trend: 'down' },
  { name: 'Audrey',     gender: 'girl', rank: 64, meaning: 'Noble strength',        origin: 'English', trend: 'up' },
  { name: 'Leilani',    gender: 'girl', rank: 65, meaning: 'Heavenly flower',       origin: 'Hawaiian', trend: 'up' },
  { name: 'Savannah',   gender: 'girl', rank: 66, meaning: 'Flat tropical grassland', origin: 'Spanish', trend: 'stable' },
  { name: 'Brooklyn',   gender: 'girl', rank: 67, meaning: 'Pleasant stream',       origin: 'English', trend: 'down' },
  { name: 'Bella',      gender: 'girl', rank: 68, meaning: 'Beautiful',             origin: 'Italian', trend: 'down' },
  { name: 'Claire',     gender: 'girl', rank: 69, meaning: 'Bright, clear',         origin: 'French',  trend: 'stable' },
  { name: 'Skylar',     gender: 'girl', rank: 70, meaning: 'Scholar',               origin: 'Dutch',   trend: 'down' },
  { name: 'Lucy',       gender: 'girl', rank: 71, meaning: 'Light',                 origin: 'Latin',   trend: 'up' },
  { name: 'Paisley',    gender: 'girl', rank: 72, meaning: 'Church',                origin: 'Scottish', trend: 'down' },
  { name: 'Everly',     gender: 'girl', rank: 73, meaning: 'Wild boar in a meadow', origin: 'English', trend: 'up' },
  { name: 'Anna',       gender: 'girl', rank: 74, meaning: 'Grace',                 origin: 'Hebrew',  trend: 'stable' },
  { name: 'Caroline',   gender: 'girl', rank: 75, meaning: 'Free woman',            origin: 'French',  trend: 'stable' },
  { name: 'Nova',       gender: 'girl', rank: 76, meaning: 'New, star',             origin: 'Latin',   trend: 'up' },
  { name: 'Genesis',    gender: 'girl', rank: 77, meaning: 'Origin, beginning',     origin: 'Greek',   trend: 'stable' },
  { name: 'Emilia',     gender: 'girl', rank: 78, meaning: 'Rival',                 origin: 'Latin',   trend: 'up' },
  { name: 'Kinsley',    gender: 'girl', rank: 79, meaning: 'King\'s meadow',        origin: 'English', trend: 'stable' },
  { name: 'Hailey',     gender: 'girl', rank: 80, meaning: 'Hay meadow',            origin: 'English', trend: 'down' },
  { name: 'Madison',    gender: 'girl', rank: 81, meaning: 'Son of Maud',           origin: 'English', trend: 'down' },
  { name: 'Sadie',      gender: 'girl', rank: 82, meaning: 'Princess',              origin: 'Hebrew',  trend: 'stable' },
  { name: 'Josephine',  gender: 'girl', rank: 83, meaning: 'God will add',          origin: 'French',  trend: 'up' },
  { name: 'Adeline',    gender: 'girl', rank: 84, meaning: 'Noble',                 origin: 'French',  trend: 'up' },
  { name: 'Cora',       gender: 'girl', rank: 85, meaning: 'Maiden',                origin: 'Greek',   trend: 'up' },
  { name: 'Ayla',       gender: 'girl', rank: 86, meaning: 'Halo of moonlight',     origin: 'Turkish', trend: 'up' },
  { name: 'Vivian',     gender: 'girl', rank: 87, meaning: 'Alive',                 origin: 'Latin',   trend: 'up' },
  { name: 'Iris',       gender: 'girl', rank: 88, meaning: 'Rainbow',               origin: 'Greek',   trend: 'up' },
  { name: 'Hadley',     gender: 'girl', rank: 89, meaning: 'Heather field',         origin: 'English', trend: 'stable' },
  { name: 'Maria',      gender: 'girl', rank: 90, meaning: 'Beloved',               origin: 'Latin',   trend: 'down' },
  { name: 'Liliana',    gender: 'girl', rank: 91, meaning: 'Lily',                  origin: 'Latin',   trend: 'stable' },
  { name: 'Quinn',      gender: 'girl', rank: 92, meaning: 'Counsel',               origin: 'Irish',   trend: 'up' },
  { name: 'Jade',       gender: 'girl', rank: 93, meaning: 'Green gemstone',        origin: 'Spanish', trend: 'stable' },
  { name: 'Piper',      gender: 'girl', rank: 94, meaning: 'Flute player',          origin: 'English', trend: 'stable' },
  { name: 'Lyla',       gender: 'girl', rank: 95, meaning: 'Night',                 origin: 'Arabic',  trend: 'stable' },
  { name: 'Mary',       gender: 'girl', rank: 96, meaning: 'Beloved',               origin: 'Hebrew',  trend: 'down' },
  { name: 'Eloise',     gender: 'girl', rank: 97, meaning: 'Healthy, wide',         origin: 'French',  trend: 'up' },
  { name: 'Rylee',      gender: 'girl', rank: 98, meaning: 'Courageous',            origin: 'Irish',   trend: 'down' },
  { name: 'Daisy',      gender: 'girl', rank: 99, meaning: 'Day\'s eye',            origin: 'English', trend: 'up' },
  { name: 'Reagan',     gender: 'girl', rank: 100,meaning: 'Little ruler',          origin: 'Irish',   trend: 'stable' },
];

// ---------- GENDER-NEUTRAL (Top 100) ----------
export const NEUTRAL_NAMES: BabyName[] = [
  { name: 'Rowan',     gender: 'neutral', rank: 1,  meaning: 'Little red one',       origin: 'Irish',    trend: 'up' },
  { name: 'River',     gender: 'neutral', rank: 2,  meaning: 'Flowing body of water', origin: 'English', trend: 'up' },
  { name: 'Avery',     gender: 'neutral', rank: 3,  meaning: 'Ruler of elves',       origin: 'English',  trend: 'stable' },
  { name: 'Sage',      gender: 'neutral', rank: 4,  meaning: 'Wise one',             origin: 'Latin',    trend: 'up' },
  { name: 'Quinn',     gender: 'neutral', rank: 5,  meaning: 'Counsel',              origin: 'Irish',    trend: 'up' },
  { name: 'Riley',     gender: 'neutral', rank: 6,  meaning: 'Courageous',           origin: 'Irish',    trend: 'stable' },
  { name: 'Parker',    gender: 'neutral', rank: 7,  meaning: 'Park keeper',          origin: 'English',  trend: 'stable' },
  { name: 'Phoenix',   gender: 'neutral', rank: 8,  meaning: 'Mythical firebird',    origin: 'Greek',    trend: 'up' },
  { name: 'Skylar',    gender: 'neutral', rank: 9,  meaning: 'Scholar',              origin: 'Dutch',    trend: 'stable' },
  { name: 'Reese',     gender: 'neutral', rank: 10, meaning: 'Enthusiasm',           origin: 'Welsh',    trend: 'stable' },
  { name: 'Charlie',   gender: 'neutral', rank: 11, meaning: 'Free person',          origin: 'English',  trend: 'up' },
  { name: 'Emerson',   gender: 'neutral', rank: 12, meaning: 'Brave, powerful',      origin: 'English',  trend: 'up' },
  { name: 'Hayden',    gender: 'neutral', rank: 13, meaning: 'Heather-grown hill',   origin: 'English',  trend: 'down' },
  { name: 'Jordan',    gender: 'neutral', rank: 14, meaning: 'To flow down',         origin: 'Hebrew',   trend: 'stable' },
  { name: 'Casey',     gender: 'neutral', rank: 15, meaning: 'Brave',                origin: 'Irish',    trend: 'stable' },
  { name: 'Morgan',    gender: 'neutral', rank: 16, meaning: 'Sea-born',             origin: 'Welsh',    trend: 'down' },
  { name: 'Taylor',    gender: 'neutral', rank: 17, meaning: 'Cloth cutter',         origin: 'English',  trend: 'down' },
  { name: 'Cameron',   gender: 'neutral', rank: 18, meaning: 'Crooked nose',         origin: 'Scottish', trend: 'stable' },
  { name: 'Alex',      gender: 'neutral', rank: 19, meaning: 'Defender of people',   origin: 'Greek',    trend: 'stable' },
  { name: 'Reagan',    gender: 'neutral', rank: 20, meaning: 'Little ruler',         origin: 'Irish',    trend: 'stable' },
  { name: 'Logan',     gender: 'neutral', rank: 21, meaning: 'Little hollow',        origin: 'Scottish', trend: 'down' },
  { name: 'Finley',    gender: 'neutral', rank: 22, meaning: 'Fair warrior',         origin: 'Scottish', trend: 'up' },
  { name: 'Dakota',    gender: 'neutral', rank: 23, meaning: 'Friend, ally',         origin: 'Native American', trend: 'stable' },
  { name: 'Wren',      gender: 'neutral', rank: 24, meaning: 'Small bird',           origin: 'English',  trend: 'up' },
  { name: 'Ellis',     gender: 'neutral', rank: 25, meaning: 'Benevolent',           origin: 'Welsh',    trend: 'up' },
  { name: 'Sawyer',    gender: 'neutral', rank: 26, meaning: 'Woodcutter',           origin: 'English',  trend: 'up' },
  { name: 'Blake',     gender: 'neutral', rank: 27, meaning: 'Pale, dark',           origin: 'English',  trend: 'stable' },
  { name: 'Remi',      gender: 'neutral', rank: 28, meaning: 'Oarsman',              origin: 'French',   trend: 'up' },
  { name: 'Hunter',    gender: 'neutral', rank: 29, meaning: 'One who hunts',        origin: 'English',  trend: 'stable' },
  { name: 'Peyton',    gender: 'neutral', rank: 30, meaning: 'Fighter\'s estate',    origin: 'English',  trend: 'down' },
  { name: 'Drew',      gender: 'neutral', rank: 31, meaning: 'Manly, brave',         origin: 'Greek',    trend: 'stable' },
  { name: 'Sutton',    gender: 'neutral', rank: 32, meaning: 'Southern town',        origin: 'English',  trend: 'up' },
  { name: 'Briar',     gender: 'neutral', rank: 33, meaning: 'Thorny plant',         origin: 'English',  trend: 'up' },
  { name: 'Marlowe',   gender: 'neutral', rank: 34, meaning: 'Driftwood',            origin: 'English',  trend: 'up' },
  { name: 'Lennon',    gender: 'neutral', rank: 35, meaning: 'Lover',                origin: 'Irish',    trend: 'up' },
  { name: 'Ari',       gender: 'neutral', rank: 36, meaning: 'Lion',                 origin: 'Hebrew',   trend: 'up' },
  { name: 'Oakley',    gender: 'neutral', rank: 37, meaning: 'Oak meadow',           origin: 'English',  trend: 'up' },
  { name: 'Eden',      gender: 'neutral', rank: 38, meaning: 'Paradise',             origin: 'Hebrew',   trend: 'stable' },
  { name: 'Indigo',    gender: 'neutral', rank: 39, meaning: 'Deep blue dye',        origin: 'Greek',    trend: 'up' },
  { name: 'Hollis',    gender: 'neutral', rank: 40, meaning: 'Holly trees',          origin: 'English',  trend: 'up' },
  { name: 'Devon',     gender: 'neutral', rank: 41, meaning: 'Defender',             origin: 'English',  trend: 'down' },
  { name: 'Frankie',   gender: 'neutral', rank: 42, meaning: 'Free',                 origin: 'English',  trend: 'up' },
  { name: 'Tatum',     gender: 'neutral', rank: 43, meaning: 'Cheerful one',         origin: 'English',  trend: 'stable' },
  { name: 'Justice',   gender: 'neutral', rank: 44, meaning: 'Fairness',             origin: 'English',  trend: 'stable' },
  { name: 'Lake',      gender: 'neutral', rank: 45, meaning: 'Body of water',        origin: 'English',  trend: 'up' },
  { name: 'Bowie',     gender: 'neutral', rank: 46, meaning: 'Blond, yellow-haired', origin: 'Scottish', trend: 'up' },
  { name: 'Ocean',     gender: 'neutral', rank: 47, meaning: 'The sea',              origin: 'Greek',    trend: 'up' },
  { name: 'Ellis',     gender: 'neutral', rank: 48, meaning: 'Kind',                 origin: 'Welsh',    trend: 'up' },
  { name: 'Asa',       gender: 'neutral', rank: 49, meaning: 'Physician, healer',    origin: 'Hebrew',   trend: 'stable' },
  { name: 'Sky',       gender: 'neutral', rank: 50, meaning: 'The sky',              origin: 'English',  trend: 'stable' },
  { name: 'Rory',      gender: 'neutral', rank: 51, meaning: 'Red king',             origin: 'Irish',    trend: 'up' },
  { name: 'Sasha',     gender: 'neutral', rank: 52, meaning: 'Defender',             origin: 'Russian',  trend: 'stable' },
  { name: 'Robin',     gender: 'neutral', rank: 53, meaning: 'Bright fame',          origin: 'English',  trend: 'stable' },
  { name: 'Bailey',    gender: 'neutral', rank: 54, meaning: 'Bailiff',              origin: 'English',  trend: 'down' },
  { name: 'Kai',       gender: 'neutral', rank: 55, meaning: 'Sea',                  origin: 'Hawaiian', trend: 'up' },
  { name: 'Reign',     gender: 'neutral', rank: 56, meaning: 'Rule, sovereign',      origin: 'English',  trend: 'up' },
  { name: 'Sterling',  gender: 'neutral', rank: 57, meaning: 'Of high quality',      origin: 'English',  trend: 'up' },
  { name: 'Lennox',    gender: 'neutral', rank: 58, meaning: 'Elm grove',            origin: 'Scottish', trend: 'up' },
  { name: 'Salem',     gender: 'neutral', rank: 59, meaning: 'Peace',                origin: 'Hebrew',   trend: 'stable' },
  { name: 'August',    gender: 'neutral', rank: 60, meaning: 'Majestic',             origin: 'Latin',    trend: 'up' },
  { name: 'Storm',     gender: 'neutral', rank: 61, meaning: 'Tempest',              origin: 'English',  trend: 'up' },
  { name: 'Echo',      gender: 'neutral', rank: 62, meaning: 'Reflected sound',      origin: 'Greek',    trend: 'up' },
  { name: 'Wilder',    gender: 'neutral', rank: 63, meaning: 'Untamed',              origin: 'English',  trend: 'up' },
  { name: 'Ash',       gender: 'neutral', rank: 64, meaning: 'Ash tree',             origin: 'English',  trend: 'stable' },
  { name: 'Banks',     gender: 'neutral', rank: 65, meaning: 'Edge of the river',    origin: 'English',  trend: 'up' },
  { name: 'Sailor',    gender: 'neutral', rank: 66, meaning: 'Boatman',              origin: 'English',  trend: 'stable' },
  { name: 'Lyric',     gender: 'neutral', rank: 67, meaning: 'Song-like',            origin: 'Greek',    trend: 'stable' },
  { name: 'Onyx',      gender: 'neutral', rank: 68, meaning: 'Black gemstone',       origin: 'Greek',    trend: 'up' },
  { name: 'Halo',      gender: 'neutral', rank: 69, meaning: 'Ring of light',        origin: 'Greek',    trend: 'up' },
  { name: 'Cypress',   gender: 'neutral', rank: 70, meaning: 'Cypress tree',         origin: 'Greek',    trend: 'up' },
  { name: 'Jules',     gender: 'neutral', rank: 71, meaning: 'Youthful',             origin: 'French',   trend: 'up' },
  { name: 'Wells',     gender: 'neutral', rank: 72, meaning: 'Spring of water',      origin: 'English',  trend: 'up' },
  { name: 'Kit',       gender: 'neutral', rank: 73, meaning: 'Bearer of Christ',     origin: 'Greek',    trend: 'up' },
  { name: 'Nico',      gender: 'neutral', rank: 74, meaning: 'Victory of the people', origin: 'Greek',   trend: 'stable' },
  { name: 'Sloan',     gender: 'neutral', rank: 75, meaning: 'Raider',               origin: 'Irish',    trend: 'stable' },
  { name: 'Ace',       gender: 'neutral', rank: 76, meaning: 'One, unity',           origin: 'English',  trend: 'up' },
  { name: 'Brook',     gender: 'neutral', rank: 77, meaning: 'Small stream', origin: 'English', trend: 'stable' },
  { name: 'Toby',      gender: 'neutral', rank: 78, meaning: 'God is good',          origin: 'Hebrew',   trend: 'stable' },
  { name: 'Pax',       gender: 'neutral', rank: 79, meaning: 'Peace',                origin: 'Latin',    trend: 'up' },
  { name: 'Wells',     gender: 'neutral', rank: 80, meaning: 'Springs',              origin: 'English',  trend: 'up' },
  { name: 'Reese',     gender: 'neutral', rank: 81, meaning: 'Ardor',                origin: 'Welsh',    trend: 'stable' },
  { name: 'Shiloh',    gender: 'neutral', rank: 82, meaning: 'Tranquil',             origin: 'Hebrew',   trend: 'stable' },
  { name: 'Maverick',  gender: 'neutral', rank: 83, meaning: 'Independent',          origin: 'English',  trend: 'up' },
  { name: 'Dallas',    gender: 'neutral', rank: 84, meaning: 'Meadow dwelling',      origin: 'Scottish', trend: 'stable' },
  { name: 'Brett',     gender: 'neutral', rank: 85, meaning: 'From Britain',         origin: 'Celtic',   trend: 'down' },
  { name: 'Spencer',   gender: 'neutral', rank: 86, meaning: 'Steward',              origin: 'English',  trend: 'stable' },
  { name: 'Sky',       gender: 'neutral', rank: 87, meaning: 'Sky, heavens',         origin: 'English',  trend: 'stable' },
  { name: 'Linden',    gender: 'neutral', rank: 88, meaning: 'Lime tree',            origin: 'English',  trend: 'up' },
  { name: 'Arden',     gender: 'neutral', rank: 89, meaning: 'Eagle valley',         origin: 'Latin',    trend: 'up' },
  { name: 'Toby',      gender: 'neutral', rank: 90, meaning: 'God is good',          origin: 'Hebrew',   trend: 'stable' },
  { name: 'Reed',      gender: 'neutral', rank: 91, meaning: 'Red-haired',           origin: 'English',  trend: 'stable' },
  { name: 'Wren',      gender: 'neutral', rank: 92, meaning: 'Small songbird',       origin: 'English',  trend: 'up' },
  { name: 'Story',     gender: 'neutral', rank: 93, meaning: 'A tale',               origin: 'English',  trend: 'up' },
  { name: 'Lou',       gender: 'neutral', rank: 94, meaning: 'Renowned warrior',     origin: 'French',   trend: 'stable' },
  { name: 'Sage',      gender: 'neutral', rank: 95, meaning: 'Wise herb',            origin: 'Latin',    trend: 'up' },
  { name: 'Cypress',   gender: 'neutral', rank: 96, meaning: 'Evergreen tree',       origin: 'Greek',    trend: 'up' },
  { name: 'Kit',       gender: 'neutral', rank: 97, meaning: 'Christ-bearer',        origin: 'Greek',    trend: 'up' },
  { name: 'True',      gender: 'neutral', rank: 98, meaning: 'Genuine',              origin: 'English',  trend: 'up' },
  { name: 'Banks',     gender: 'neutral', rank: 99, meaning: 'River bank',           origin: 'English',  trend: 'up' },
  { name: 'Lior',      gender: 'neutral', rank: 100,meaning: 'I have light',         origin: 'Hebrew',   trend: 'up' },
];

// ---------- Combined export & helpers ----------
export const ALL_NAMES: BabyName[] = [
  ...BOY_NAMES,
  ...GIRL_NAMES,
  ...NEUTRAL_NAMES,
];

export const NAME_ORIGINS: string[] = Array.from(
  new Set(ALL_NAMES.map((n) => n.origin))
).sort();

export function namesByGender(gender: Gender): BabyName[] {
  if (gender === 'boy') return BOY_NAMES;
  if (gender === 'girl') return GIRL_NAMES;
  return NEUTRAL_NAMES;
}

export function getTrendLabel(trend: Trend): string {
  if (trend === 'up') return 'Trending up';
  if (trend === 'down') return 'Trending down';
  return 'Stable';
}

export interface NameFilters {
  gender: Gender | 'all';
  startsWith: string; // single letter or ''
  origin: string;     // origin name or 'all'
  search: string;     // free-text search
}

export function filterNames(filters: NameFilters): BabyName[] {
  let names: BabyName[] = ALL_NAMES;

  if (filters.gender !== 'all') {
    names = names.filter((n) => n.gender === filters.gender);
  }
  if (filters.startsWith) {
    const letter = filters.startsWith.toLowerCase();
    names = names.filter((n) => n.name.toLowerCase().startsWith(letter));
  }
  if (filters.origin && filters.origin !== 'all') {
    names = names.filter((n) => n.origin === filters.origin);
  }
  if (filters.search) {
    const q = filters.search.toLowerCase();
    names = names.filter(
      (n) =>
        n.name.toLowerCase().includes(q) ||
        n.meaning.toLowerCase().includes(q) ||
        n.origin.toLowerCase().includes(q)
    );
  }
  return names;
}
