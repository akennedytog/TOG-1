// Community Q&A data and types

export type QACategory =
  | 'sleep'
  | 'feeding'
  | 'finances'
  | 'working-parents'
  | 'medical';

export interface QAAnswer {
  id: string;
  author: string;
  authorRole?: string; // e.g. "Pediatrician", "Mom of 3"
  isExpert?: boolean;
  content: string;
  upvotes: number;
  createdAt: string; // ISO
}

export interface QAQuestion {
  id: string;
  title: string;
  body: string;
  category: QACategory;
  author: string;
  upvotes: number;
  createdAt: string; // ISO
  answers: QAAnswer[];
}

export const QA_CATEGORIES: { id: QACategory; name: string; emoji: string }[] = [
  { id: 'sleep', name: 'Sleep', emoji: '😴' },
  { id: 'feeding', name: 'Feeding', emoji: '🍼' },
  { id: 'finances', name: 'Finances', emoji: '💰' },
  { id: 'working-parents', name: 'Working Parents', emoji: '💼' },
  { id: 'medical', name: 'Medical', emoji: '🩺' },
];

// Helper: days ago -> ISO string
const daysAgo = (n: number) =>
  new Date(Date.now() - n * 24 * 60 * 60 * 1000).toISOString();

export const SAMPLE_QUESTIONS: QAQuestion[] = [
  {
    id: 'q1',
    title: 'How do I get my 4-month-old to sleep through the night?',
    body: 'My baby wakes up every 2-3 hours. I\'ve tried everything I can think of. Any tips that actually worked for you?',
    category: 'sleep',
    author: 'TiredMomma22',
    upvotes: 47,
    createdAt: daysAgo(2),
    answers: [
      {
        id: 'a1-1',
        author: 'Dr. Sarah Chen',
        authorRole: 'Board-Certified Pediatrician',
        isExpert: true,
        content:
          'At 4 months, most babies are physically capable of sleeping longer stretches but are also going through the well-known "4-month sleep regression." Focus on a consistent bedtime routine (bath, feed, dim lights), put baby down drowsy but awake, and give them a chance to self-soothe for 5-10 minutes before responding. This usually resolves within 2-3 weeks.',
        upvotes: 38,
        createdAt: daysAgo(2),
      },
      {
        id: 'a1-2',
        author: 'MamaOfThree',
        authorRole: 'Mom of 3',
        content:
          'White noise machine changed our lives. Also, blackout curtains. And a dream feed around 10pm helped stretch the first chunk of sleep.',
        upvotes: 24,
        createdAt: daysAgo(1),
      },
    ],
  },
  {
    id: 'q2',
    title: 'Breast pump covered by insurance — how do I actually get one?',
    body: 'I\'m 28 weeks and just learned my insurance covers a pump. Where do I start? Do I need a prescription?',
    category: 'medical',
    author: 'FirstTimeMom2026',
    upvotes: 31,
    createdAt: daysAgo(5),
    answers: [
      {
        id: 'a2-1',
        author: 'Lisa M., IBCLC',
        authorRole: 'Lactation Consultant',
        isExpert: true,
        content:
          'Call your insurance member services line and ask for their list of approved DME (durable medical equipment) suppliers. Companies like Aeroflow, Edgepark, and 1 Natural Way will handle the paperwork — you just give them your insurance info and your OB\'s contact. They\'ll get the prescription and ship the pump. Most plans cover it 100% starting at 28 weeks.',
        upvotes: 29,
        createdAt: daysAgo(5),
      },
    ],
  },
  {
    id: 'q3',
    title: 'Maternity leave: short-term disability vs. FMLA — what\'s the difference?',
    body: 'My HR rep mentioned both and I\'m confused. Are they the same thing? Do I need to apply for both?',
    category: 'working-parents',
    author: 'CorporateMom',
    upvotes: 56,
    createdAt: daysAgo(8),
    answers: [
      {
        id: 'a3-1',
        author: 'Jessica Park, JD',
        authorRole: 'Employment Attorney',
        isExpert: true,
        content:
          'They\'re completely different and you typically use BOTH. FMLA is unpaid job protection — 12 weeks where your employer must hold your job and benefits. Short-term disability (STD) is the PAID portion — usually 60-70% of your salary for 6-8 weeks (6 vaginal, 8 C-section). FMLA runs concurrently with STD. Apply for STD BEFORE birth; FMLA gets filed when leave starts.',
        upvotes: 51,
        createdAt: daysAgo(8),
      },
      {
        id: 'a3-2',
        author: 'WorkingMomBoss',
        content:
          'Also check if your state has Paid Family Leave (PFL) — California, NY, NJ, MA, WA, and a few others offer additional paid weeks on top of STD.',
        upvotes: 18,
        createdAt: daysAgo(7),
      },
    ],
  },
  {
    id: 'q4',
    title: 'How much should I budget for the first year of baby expenses?',
    body: 'Trying to plan our finances. Realistically, what did you spend in year one (diapers, formula, daycare, etc.)?',
    category: 'finances',
    author: 'PlanningPapa',
    upvotes: 89,
    createdAt: daysAgo(12),
    answers: [
      {
        id: 'a4-1',
        author: 'Mark T., CFP',
        authorRole: 'Certified Financial Planner',
        isExpert: true,
        content:
          'National average is $15,000-$17,000 in year one, but it varies massively by location. Big buckets: childcare ($10-25K if using daycare), diapers/wipes ($800-1,200), formula if not breastfeeding ($1,500-2,500), healthcare premiums increase ($1,200-3,000), gear & clothing ($1,500). Build a buffer of 20% — surprises happen.',
        upvotes: 62,
        createdAt: daysAgo(12),
      },
      {
        id: 'a4-2',
        author: 'BudgetMom',
        content:
          'We spent ~$12K in year one in Ohio with one parent staying home (so no daycare). The biggest unexpected cost was healthcare — adding baby to insurance bumped our premium by $400/month.',
        upvotes: 34,
        createdAt: daysAgo(10),
      },
    ],
  },
  {
    id: 'q5',
    title: 'Cluster feeding — is this normal??',
    body: 'My 2-week-old wants to eat constantly in the evenings. Like, every 30 minutes for 3 hours. Am I not making enough milk?',
    category: 'feeding',
    author: 'NewMomPanic',
    upvotes: 42,
    createdAt: daysAgo(3),
    answers: [
      {
        id: 'a5-1',
        author: 'Maria G., RN, IBCLC',
        authorRole: 'Lactation Consultant',
        isExpert: true,
        content:
          'YES, completely normal. Cluster feeding in the evenings is your baby\'s natural way of "tanking up" before a longer sleep stretch, and it also signals your body to increase milk supply. As long as baby has 6+ wet diapers per day and is gaining weight, supply is fine. This phase usually peaks around 2-3 weeks and 6 weeks. Hang in there!',
        upvotes: 40,
        createdAt: daysAgo(3),
      },
    ],
  },
  {
    id: 'q6',
    title: 'When should I start a 529 account?',
    body: 'Baby is due in March. Should I open a 529 before or after birth? Pros and cons?',
    category: 'finances',
    author: 'FutureGradParent',
    upvotes: 23,
    createdAt: daysAgo(15),
    answers: [
      {
        id: 'a6-1',
        author: 'David Lee, CFP',
        authorRole: 'Financial Advisor',
        isExpert: true,
        content:
          'Open it before birth, in your own name, then transfer beneficiary to baby once you have their SSN (about 4-6 weeks after birth). This way you get a head start on tax-advantaged growth. Even $50/month from birth grows to ~$22K by age 18 at 7% returns.',
        upvotes: 19,
        createdAt: daysAgo(15),
      },
    ],
  },
  {
    id: 'q7',
    title: 'Returning to work after 12 weeks — pumping schedule advice?',
    body: 'I go back to work next month and want to keep breastfeeding. What\'s a realistic pumping schedule?',
    category: 'working-parents',
    upvotes: 28,
    author: 'BackToWorkMom',
    createdAt: daysAgo(6),
    answers: [
      {
        id: 'a7-1',
        author: 'Anna K., IBCLC',
        authorRole: 'Lactation Consultant',
        isExpert: true,
        content:
          'For an 8-hour workday, aim for 3 pump sessions of 15-20 minutes each (mid-morning, lunch, mid-afternoon). Total ~24 oz is typical. Federal law (PUMP Act) requires your employer to provide reasonable break time and a private (non-bathroom) space. Build a freezer stash of 50-100 oz before returning for peace of mind.',
        upvotes: 25,
        createdAt: daysAgo(6),
      },
    ],
  },
  {
    id: 'q8',
    title: 'Is it safe to co-sleep?',
    body: 'I keep hearing mixed things. Some say never, some say it\'s fine if done safely. What\'s the actual recommendation?',
    category: 'sleep',
    author: 'ConfusedDad',
    upvotes: 67,
    createdAt: daysAgo(9),
    answers: [
      {
        id: 'a8-1',
        author: 'Dr. Rachel Kim',
        authorRole: 'Pediatrician',
        isExpert: true,
        content:
          'The AAP recommends room-sharing (same room, separate sleep surface) for at least the first 6 months — this reduces SIDS risk by up to 50%. Bed-sharing is NOT recommended by the AAP due to suffocation risk, but if you choose to, follow the "Safe Sleep 7": firm mattress, no soft bedding, no pillows near baby, sober/non-smoking parents, baby on back, breastfed, and full-term healthy baby.',
        upvotes: 58,
        createdAt: daysAgo(9),
      },
    ],
  },
  {
    id: 'q9',
    title: 'Daycare vs. nanny vs. au pair — how did you decide?',
    body: 'Comparing options for when I go back to work. The cost difference is huge. What worked for your family?',
    category: 'working-parents',
    author: 'WeighingOptions',
    upvotes: 35,
    createdAt: daysAgo(11),
    answers: [
      {
        id: 'a9-1',
        author: 'TwinMom',
        content:
          'Daycare for us — socialization was huge and it was the cheapest. ~$2,400/mo for one in our HCOL area. Nanny quotes were $25/hr (~$5,000/mo). Au pair is interesting if you have a spare bedroom — ~$2,200/mo all-in plus the cultural exchange.',
        upvotes: 22,
        createdAt: daysAgo(11),
      },
    ],
  },
  {
    id: 'q10',
    title: 'Baby refuses bottle — going back to work in 2 weeks 😭',
    body: 'EBF baby will NOT take a bottle no matter what we try. Different nipples, different people offering, different times. Help!',
    category: 'feeding',
    author: 'DesperateMom',
    upvotes: 51,
    createdAt: daysAgo(4),
    answers: [
      {
        id: 'a10-1',
        author: 'Karen S., IBCLC',
        authorRole: 'Lactation Consultant',
        isExpert: true,
        content:
          'Try this: someone OTHER than mom offers the bottle, mom is out of the house (not just out of the room — babies smell us), warm the nipple under hot water first, and try when baby is calm but not starving. Some babies do better with a Lansinoh mOmma bottle or Comotomo. If still refusing, try a cup or syringe — many babies skip bottles entirely and go straight to sippy cups at 6 months.',
        upvotes: 47,
        createdAt: daysAgo(4),
      },
    ],
  },
  {
    id: 'q11',
    title: 'Wake windows by age — cheat sheet?',
    body: 'Trying to figure out how long my baby should be awake between naps. Anyone have a reliable guide?',
    category: 'sleep',
    author: 'NapSchedule',
    upvotes: 19,
    createdAt: daysAgo(7),
    answers: [
      {
        id: 'a11-1',
        author: 'Sleep Consultant Mia',
        authorRole: 'Certified Pediatric Sleep Consultant',
        isExpert: true,
        content:
          'General wake windows: Newborn (0-1mo): 45-60 min. 2 mo: 60-90 min. 3 mo: 75-105 min. 4-5 mo: 1.5-2 hrs. 6-8 mo: 2-3 hrs. 9-12 mo: 3-4 hrs. 12-18 mo: 4-5 hrs. Watch sleepy cues (yawning, rubbing eyes, getting fussy) more than the clock!',
        upvotes: 26,
        createdAt: daysAgo(7),
      },
    ],
  },
  {
    id: 'q12',
    title: 'HSA vs FSA for baby expenses?',
    body: 'Open enrollment is coming. Which is better when you\'re about to have a baby?',
    category: 'finances',
    author: 'BenefitsConfused',
    upvotes: 14,
    createdAt: daysAgo(14),
    answers: [],
  },
  {
    id: 'q13',
    title: 'When to call the pediatrician vs. wait it out — fever in newborn?',
    body: 'My 6-week-old has a temp of 100.1°F. Is that a "call now" situation?',
    category: 'medical',
    author: 'WorriedFirstTime',
    upvotes: 78,
    createdAt: daysAgo(1),
    answers: [
      {
        id: 'a13-1',
        author: 'Dr. James Park',
        authorRole: 'Pediatrician',
        isExpert: true,
        content:
          'YES — for babies under 3 months, ANY rectal temp of 100.4°F (38°C) or higher is an automatic ER visit, not even a "call the office" situation. At 100.1°F, call your pediatrician\'s after-hours line now. Newborns can\'t mount a strong immune response, so even mild fevers can indicate serious infections that need IV antibiotics within hours. Better safe than sorry.',
        upvotes: 89,
        createdAt: daysAgo(1),
      },
    ],
  },
  {
    id: 'q14',
    title: 'Best way to introduce solids at 6 months?',
    body: 'Baby-led weaning, purees, or both? What did you do and how did it go?',
    category: 'feeding',
    author: 'SolidsTime',
    upvotes: 22,
    createdAt: daysAgo(13),
    answers: [
      {
        id: 'a14-1',
        author: 'Dr. Lisa Wong',
        authorRole: 'Pediatric Dietitian',
        isExpert: true,
        content:
          'Both work — research shows no significant difference in long-term outcomes. A "combination" approach is most common: purees for some meals, soft finger foods for others. Start with iron-rich foods (iron-fortified cereal, pureed meats, lentils) since baby\'s iron stores from birth deplete around 6 months. Introduce common allergens (peanut, egg, dairy) early per current AAP guidance.',
        upvotes: 18,
        createdAt: daysAgo(13),
      },
    ],
  },
  {
    id: 'q15',
    title: 'Tax credits and benefits I should know about as a new parent?',
    body: 'What are the financial perks of having a kid (tax-wise) that I should be claiming?',
    category: 'finances',
    author: 'NewDadTaxes',
    upvotes: 44,
    createdAt: daysAgo(20),
    answers: [
      {
        id: 'a15-1',
        author: 'Rebecca H., CPA',
        authorRole: 'Tax Professional',
        isExpert: true,
        content:
          'Big ones: (1) Child Tax Credit — up to $2,000/child under 17. (2) Dependent Care FSA — pre-tax $5,000/yr for daycare. (3) Child & Dependent Care Credit — up to $1,050 per child for childcare costs. (4) Earned Income Tax Credit (income-dependent). (5) Update your W-4 to adjust withholding. Also: 529 contributions are state tax-deductible in 30+ states.',
        upvotes: 41,
        createdAt: daysAgo(20),
      },
    ],
  },
];
