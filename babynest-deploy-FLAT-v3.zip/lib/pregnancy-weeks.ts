/**
 * Week-by-Week Pregnancy Data
 *
 * Complete content for all 40 weeks of pregnancy, including baby development,
 * mom's symptoms, medical milestones, financial deadlines, and action items.
 *
 * Medical information is general guidance only — always consult a healthcare provider.
 */

export type Trimester = 1 | 2 | 3;

export interface FinancialDeadline {
  title: string;
  description: string;
  estimatedCost?: string;
  link?: string;
}

export interface MedicalMilestone {
  title: string;
  description: string;
}

export interface WeekData {
  week: number;
  trimester: Trimester;
  // Baby development
  babySize: string; // e.g. "Lime"
  babyEmoji: string; // e.g. "🍋"
  babyLengthCm?: number;
  babyWeightG?: number;
  babyDevelopment: string; // short paragraph
  // Mom
  momSymptoms: string[];
  momChanges: string; // short paragraph
  // Medical
  medicalMilestones: MedicalMilestone[];
  // Financial
  financialDeadlines: FinancialDeadline[];
  // Actionable
  checklist: string[];
  // Optional headline
  headline?: string;
}

const trimesterOf = (w: number): Trimester => (w <= 12 ? 1 : w <= 27 ? 2 : 3);

export const TRIMESTER_LABELS: Record<Trimester, string> = {
  1: 'First Trimester',
  2: 'Second Trimester',
  3: 'Third Trimester',
};

export const TRIMESTER_RANGES: Record<Trimester, [number, number]> = {
  1: [1, 12],
  2: [13, 27],
  3: [28, 40],
};

/**
 * Per-week content. Every week 1-40 is represented.
 * Where we have rich, well-known content (e.g. milestone weeks)
 * we provide detailed information; other weeks use a sensible default
 * derived from the trimester.
 */
const WEEK_OVERRIDES: Partial<Record<number, Partial<WeekData>>> = {
  1: {
    babySize: 'Microscopic',
    babyEmoji: '✨',
    babyDevelopment:
      "Technically you're not pregnant yet — week 1 is counted from the first day of your last menstrual period. Your body is preparing for ovulation.",
    momChanges:
      'Your period is happening. The uterus is shedding its lining in preparation for a fresh cycle.',
    momSymptoms: ['Menstrual bleeding', 'Cramps', 'PMS-like mood'],
    medicalMilestones: [
      { title: 'Track your cycle', description: 'Note day 1 of your last period — doctors use this to date the pregnancy.' },
    ],
    financialDeadlines: [
      { title: 'Review health insurance', description: 'Check maternity coverage, deductibles, and in-network OBGYNs before conception.' },
    ],
    checklist: ['Start prenatal vitamins with folic acid', 'Track your cycle', 'Quit alcohol & smoking'],
    headline: "You're not pregnant yet — but the clock starts here.",
  },
  2: {
    babySize: 'Microscopic',
    babyEmoji: '✨',
    babyDevelopment: 'Ovulation occurs around the end of this week. The egg is released and ready to be fertilized.',
    momChanges: 'Your body releases an egg. Cervical mucus changes to be more receptive to sperm.',
    momSymptoms: ['Slight cramping', 'Increased libido', 'Egg-white cervical mucus'],
    medicalMilestones: [{ title: 'Ovulation', description: 'Peak fertility window.' }],
    financialDeadlines: [
      { title: 'Set up an FSA/HSA', description: 'If your employer offers one, enroll during open season — pregnancy care is a qualified expense.' },
    ],
    checklist: ['Continue prenatals', 'Track ovulation', 'Reduce caffeine to under 200mg/day'],
  },
  3: {
    babySize: 'Poppy seed',
    babyEmoji: '·',
    babyDevelopment: 'Fertilization happens! The single cell divides rapidly into a blastocyst as it travels down the fallopian tube.',
    momChanges: 'Implantation is occurring. You may not feel anything yet.',
    momSymptoms: ['Light spotting (implantation)', 'Mild cramping', 'Breast tenderness'],
    medicalMilestones: [{ title: 'Implantation', description: 'The blastocyst attaches to the uterine wall, around days 6-12 after fertilization.' }],
    financialDeadlines: [
      { title: 'Confirm insurance maternity benefits', description: 'Call your insurer and ask about deductibles, copays, and out-of-pocket maximums.' },
    ],
    checklist: ['Avoid alcohol & high-risk foods', 'Continue prenatals', 'Schedule preconception checkup if not done'],
  },
  4: {
    babySize: 'Poppy seed',
    babyEmoji: '·',
    babyLengthCm: 0.1,
    babyDevelopment: 'Your baby is now an embryo. The neural tube, heart, and digestive tract are starting to form. The placenta begins developing.',
    momChanges: 'A missed period is your first major clue. Pregnancy hormones (hCG) are rising fast.',
    momSymptoms: ['Missed period', 'Sore breasts', 'Fatigue', 'Mood swings', 'Positive home test'],
    medicalMilestones: [
      { title: 'Positive home pregnancy test', description: 'hCG is detectable in urine. Confirm with a second test in a few days.' },
      { title: 'Call your OBGYN', description: 'Schedule your first prenatal appointment (usually at week 8).' },
    ],
    financialDeadlines: [
      { title: 'Verify insurance covers your OBGYN', description: 'Make sure your preferred provider is in-network before booking the first visit.' },
      { title: 'Open a pregnancy savings fund', description: 'Start setting aside money for out-of-pocket medical costs ($3,000-$7,000 average).' },
    ],
    checklist: [
      'Take a home pregnancy test',
      'Start (or continue) prenatal vitamins with 400-800mcg folic acid',
      'Schedule your first prenatal visit',
      'Quit alcohol, smoking, and recreational drugs',
      'Tell your partner / closest support',
    ],
    headline: 'First positive test! Confirm and call your OBGYN.',
  },
  5: {
    babySize: 'Sesame seed',
    babyEmoji: '🌱',
    babyLengthCm: 0.2,
    babyDevelopment: 'The heart starts to beat this week. Major organ systems are beginning to form.',
    momChanges: 'Pregnancy hormones surge. Morning sickness can start now.',
    momSymptoms: ['Nausea', 'Frequent urination', 'Sore breasts', 'Mild cramping'],
    medicalMilestones: [{ title: "Baby's heart starts beating", description: 'Sometimes visible on early ultrasound by 6-7 weeks.' }],
    financialDeadlines: [
      { title: 'Estimate your out-of-pocket maximum', description: 'Most of your medical costs will fall under this annual cap.' },
    ],
    checklist: ['Eat small frequent meals to manage nausea', 'Stay hydrated', 'Keep taking prenatals'],
  },
  6: {
    babySize: 'Lentil',
    babyEmoji: '🟤',
    babyLengthCm: 0.5,
    babyDevelopment: "Tiny limb buds appear. The brain is developing rapidly and the heart beats around 110 bpm.",
    momChanges: 'Morning sickness may peak. Smells become overwhelming.',
    momSymptoms: ['Morning sickness', 'Food aversions', 'Exhaustion', 'Bloating'],
    medicalMilestones: [{ title: 'Early ultrasound possible', description: 'Some providers do a dating ultrasound at 6-8 weeks.' }],
    financialDeadlines: [
      { title: 'Read your insurance Summary of Benefits', description: 'Look specifically for maternity, delivery, NICU, and lactation coverage.' },
    ],
    checklist: ['Hydrate aggressively', 'Sleep when you can', 'Pick an OBGYN if you haven\'t'],
  },
  7: {
    babySize: 'Blueberry',
    babyEmoji: '🫐',
    babyLengthCm: 1,
    babyDevelopment: 'Hands and feet are starting to form. The brain has doubled in size since last week.',
    momChanges: 'Symptoms intensify. You\'re producing 50% more blood than before.',
    momSymptoms: ['Nausea', 'Fatigue', 'Excess saliva', 'Acne'],
    medicalMilestones: [{ title: 'Prep for first prenatal visit', description: 'Write down questions and your full medical history.' }],
    financialDeadlines: [
      { title: 'Compare hospitals & birthing centers', description: 'Costs vary 5-10x between facilities for the same delivery.' },
    ],
    checklist: ['Write down questions for your OB', 'Avoid raw fish, deli meat, soft cheese'],
  },
  8: {
    babySize: 'Raspberry',
    babyEmoji: '🍇',
    babyLengthCm: 1.6,
    babyWeightG: 1,
    babyDevelopment: 'All essential organs are now in place and starting to function. Webbed fingers and toes are visible.',
    momChanges: 'Your uterus has doubled in size. Symptoms are usually strongest now.',
    momSymptoms: ['Heightened smell', 'Constipation', 'Nausea', 'Headaches', 'Mood swings'],
    medicalMilestones: [
      { title: 'FIRST PRENATAL VISIT', description: 'Full physical, blood work, urine test, dating ultrasound, and Pap smear if due.' },
      { title: 'Confirmed due date', description: 'Your due date is finalized based on ultrasound measurements.' },
    ],
    financialDeadlines: [
      { title: 'Initial cost planning', description: 'You should now know your deductible, copays, and what your insurance covers. Build a budget.' },
      { title: 'Ask about prenatal global billing', description: 'Many OBs bundle prenatal care into one fee due at delivery.' },
    ],
    checklist: [
      'Attend first prenatal visit',
      'Submit insurance card and ID',
      'Ask about NIPT (non-invasive prenatal testing)',
      'Begin a pregnancy budget',
      'Confirm in-network labs for blood work',
    ],
    headline: 'First prenatal visit — kickstart your cost planning.',
  },
  9: {
    babySize: 'Cherry',
    babyEmoji: '🍒',
    babyLengthCm: 2.3,
    babyWeightG: 2,
    babyDevelopment: 'Officially a fetus now. Tiny earlobes, eyelids, and a beating heart visible on ultrasound.',
    momChanges: 'You may need bigger bras already. The uterus is the size of a grapefruit.',
    momSymptoms: ['Breast growth', 'Mood swings', 'Vivid dreams', 'Fatigue'],
    medicalMilestones: [{ title: 'Possible NIPT', description: 'A simple blood test can screen for chromosomal conditions starting at week 10.' }],
    financialDeadlines: [
      { title: 'Confirm NIPT coverage', description: 'NIPT runs $300-$800 if not covered. Ask if your provider has a flat-fee program.' },
    ],
    checklist: ['Decide on genetic screening', 'Start a pregnancy journal'],
  },
  10: {
    babySize: 'Strawberry',
    babyEmoji: '🍓',
    babyLengthCm: 3.1,
    babyWeightG: 4,
    babyDevelopment: 'Vital organs are formed and starting to function. Tooth buds and nails are developing.',
    momChanges: 'Visible bump may start to show, especially if it\'s not your first pregnancy.',
    momSymptoms: ['Visible veins', 'Bloating', 'Bigger appetite'],
    medicalMilestones: [{ title: 'NIPT window opens', description: 'Available from week 10. Can also reveal baby\'s sex.' }],
    financialDeadlines: [
      { title: 'Open a 529 or savings account', description: 'Compound growth from before birth is huge — even $50/mo can become tens of thousands.' },
    ],
    checklist: ['Order NIPT if desired', 'Tell close family if you want to'],
  },
  11: {
    babySize: 'Fig',
    babyEmoji: '🟢',
    babyLengthCm: 4.1,
    babyWeightG: 7,
    babyDevelopment: 'Baby can hiccup. Fingers and toes are no longer webbed.',
    momChanges: 'Nausea may start fading. Energy returns slowly.',
    momSymptoms: ['Fading nausea', 'Increased energy', 'Heartburn'],
    medicalMilestones: [{ title: 'Nuchal translucency window opens', description: 'Ultrasound to assess Down syndrome risk (weeks 11-14).' }],
    financialDeadlines: [
      { title: 'Review FSA/HSA contributions', description: 'Maximize tax-advantaged accounts before year end.' },
    ],
    checklist: ['Stay active — walks help energy', 'Plan announcement strategy'],
  },
  12: {
    babySize: 'Lime',
    babyEmoji: '🟢',
    babyLengthCm: 5.4,
    babyWeightG: 14,
    babyDevelopment: 'Reflexes are developing. Baby can suck their thumb and yawn. All organs are formed.',
    momChanges: 'End of first trimester! Miscarriage risk drops sharply.',
    momSymptoms: ['Decreasing nausea', 'Increased appetite', 'Skin changes (linea nigra)'],
    medicalMilestones: [
      { title: 'First trimester combined screening', description: 'Blood test + nuchal translucency ultrasound for Down syndrome and trisomy 18.' },
      { title: 'End of first trimester', description: 'You\'ve made it through the riskiest period.' },
    ],
    financialDeadlines: [
      { title: 'INSURANCE VERIFICATION', description: 'Get written confirmation of maternity coverage, including hospital, anesthesia, and pediatric coverage.' },
      { title: 'Notify HR (if you want)', description: 'Many companies require advance notice for FMLA and short-term disability.' },
      { title: 'Research short-term disability', description: 'If not employer-provided, it\'s usually too late to buy once pregnant — but verify policy details.' },
    ],
    checklist: [
      'Verify insurance in writing',
      'Make announcement (if ready)',
      'Get combined screening results',
      'Schedule the 20-week anatomy scan',
      'Look into short-term disability benefits',
    ],
    headline: 'End of T1! Verify insurance and plan for the road ahead.',
  },
  13: {
    babySize: 'Lemon',
    babyEmoji: '🍋',
    babyLengthCm: 7.4,
    babyWeightG: 23,
    babyDevelopment: 'Welcome to the second trimester! Baby\'s vocal cords and fingerprints are forming.',
    momChanges: 'The honeymoon trimester begins — usually the most comfortable.',
    momSymptoms: ['More energy', 'Visible bump', 'Higher libido'],
    medicalMilestones: [{ title: 'Anatomy scan scheduling', description: 'Book your 20-week ultrasound now — they fill up fast.' }],
    financialDeadlines: [
      { title: 'Estimate maternity leave income', description: 'Map out paid vs unpaid weeks and the income gap.' },
    ],
    checklist: ['Schedule anatomy scan', 'Start a baby registry list (research only)', 'Begin gentle exercise'],
  },
  14: {
    babySize: 'Peach',
    babyEmoji: '🍑',
    babyLengthCm: 8.7,
    babyWeightG: 43,
    babyDevelopment: 'Baby is making facial expressions. Lanugo (fine hair) covers the body.',
    momChanges: 'Many women report a glow this week.',
    momSymptoms: ['Glowing skin', 'Round ligament pain', 'Stuffy nose'],
    medicalMilestones: [{ title: 'Second prenatal visit', description: 'Routine checkup. Weight, blood pressure, heartbeat.' }],
    financialDeadlines: [
      { title: 'Build a childcare cost estimate', description: 'Daycare averages $1,000-$2,500/mo in the US. Get on waitlists 6+ months early.' },
    ],
    checklist: ['Tour daycares / get on waitlists', 'Plan announcement to extended family'],
  },
  15: {
    babySize: 'Apple',
    babyEmoji: '🍎',
    babyLengthCm: 10.1,
    babyWeightG: 70,
    babyDevelopment: 'Baby can sense light and is forming taste buds.',
    momChanges: 'You may start feeling flutters of movement (quickening).',
    momSymptoms: ['Quickening', 'Heartburn', 'Bleeding gums'],
    medicalMilestones: [{ title: 'Quad screen window opens', description: 'Blood test to screen for neural tube defects and chromosomal issues (weeks 15-22).' }],
    financialDeadlines: [
      { title: 'Compare daycares', description: 'Centers vs in-home vs nanny share — costs vary 2-3x.' },
    ],
    checklist: ['Compare childcare options', 'Start tracking baby movements (mental note)'],
  },
  16: {
    babySize: 'Avocado',
    babyEmoji: '🥑',
    babyLengthCm: 11.6,
    babyWeightG: 100,
    babyDevelopment: 'Baby\'s circulatory system is fully functional. Eyes can move.',
    momChanges: 'Bump is unmistakable now. You may feel "pregnancy brain".',
    momSymptoms: ['Backaches', 'Forgetfulness', 'Stronger hair and nails'],
    medicalMilestones: [{ title: 'Possible amniocentesis', description: 'Optional diagnostic test for genetic conditions (weeks 15-20).' }],
    financialDeadlines: [
      { title: 'Estimate hospital delivery costs', description: 'Vaginal: $13K avg. C-section: $22K avg. Get an itemized estimate from your hospital.' },
    ],
    checklist: ['Buy maternity clothes (or accept hand-me-downs)', 'Start sleeping on left side'],
  },
  17: {
    babySize: 'Pear',
    babyEmoji: '🍐',
    babyLengthCm: 13,
    babyWeightG: 140,
    babyDevelopment: 'Baby\'s skeleton is hardening from cartilage to bone.',
    momChanges: 'Center of gravity is shifting — be careful with balance.',
    momSymptoms: ['Heartburn', 'Increased sweating', 'Swollen feet'],
    medicalMilestones: [{ title: 'Continued movement awareness', description: 'Movements will become more regular and noticeable.' }],
    financialDeadlines: [
      { title: 'Research pediatricians', description: 'In-network pediatricians save thousands. Most need to be chosen before delivery.' },
    ],
    checklist: ['Interview pediatricians', 'Plan a babymoon (if budget allows)'],
  },
  18: {
    babySize: 'Bell pepper',
    babyEmoji: '🫑',
    babyLengthCm: 14.2,
    babyWeightG: 190,
    babyDevelopment: 'Baby can hear your voice and react to it.',
    momChanges: 'Round ligament pain is common as the uterus expands.',
    momSymptoms: ['Round ligament pain', 'Dizziness', 'Visible bump'],
    medicalMilestones: [{ title: 'Pre-anatomy scan visit', description: 'Routine prenatal — heartbeat, blood pressure, fundal height.' }],
    financialDeadlines: [
      { title: 'Pre-register at the hospital', description: 'Some hospitals offer discounts for pre-registration. Reduces paperwork at delivery.' },
    ],
    checklist: ['Pre-register at delivery hospital', 'Start talking and reading to baby'],
  },
  19: {
    babySize: 'Mango',
    babyEmoji: '🥭',
    babyLengthCm: 15.3,
    babyWeightG: 240,
    babyDevelopment: 'Vernix (waxy coating) protects baby\'s skin in the amniotic fluid.',
    momChanges: 'Hips may widen. Pelvic pressure is increasing.',
    momSymptoms: ['Pelvic pressure', 'Leg cramps', 'Lower back pain'],
    medicalMilestones: [{ title: 'Anatomy scan prep', description: 'Drink water before the scan for better visibility.' }],
    financialDeadlines: [
      { title: 'Refine your registry', description: 'Many retailers offer completion discounts (Amazon 15%, Target 15%, Babylist 15%).' },
    ],
    checklist: ['Prepare anatomy scan questions', 'Start a baby registry'],
  },
  20: {
    babySize: 'Banana',
    babyEmoji: '🍌',
    babyLengthCm: 16.4,
    babyWeightG: 300,
    babyDevelopment: 'Halfway point! Baby can swallow and pass meconium. Sex is clearly visible on ultrasound.',
    momChanges: 'You may notice stronger kicks. The bump is undeniable.',
    momSymptoms: ['Strong kicks', 'Stretch marks', 'Faster hair growth'],
    medicalMilestones: [
      { title: 'ANATOMY SCAN (Level 2 ultrasound)', description: 'Detailed 30-60 minute ultrasound to check baby\'s organs, growth, and identify sex if desired.' },
      { title: 'Halfway point', description: 'You\'re 50% there!' },
    ],
    financialDeadlines: [
      { title: 'Anatomy scan costs', description: 'Usually covered by insurance, but verify. Additional 3D/4D scans run $100-$300 out of pocket.' },
      { title: 'GENDER REVEAL BUDGET', description: 'Average gender reveal party: $400-$1,500. Decide what makes sense for you.' },
      { title: 'Lock in your registry', description: 'Aim for ~80 items across price points. Friends and family will start asking.' },
    ],
    checklist: [
      'Attend anatomy scan',
      'Decide on gender reveal (or skip it)',
      'Finalize baby registry',
      'Plan baby shower with host',
      'Start nursery planning',
    ],
    headline: 'Anatomy scan — and time to plan the gender reveal!',
  },
  21: {
    babySize: 'Carrot',
    babyEmoji: '🥕',
    babyLengthCm: 26.7,
    babyWeightG: 360,
    babyDevelopment: 'Baby\'s digestive system practices by swallowing amniotic fluid.',
    momChanges: 'Belly button may pop out soon. Stretch marks may appear.',
    momSymptoms: ['Stretch marks', 'Braxton Hicks possible', 'Spider veins'],
    medicalMilestones: [{ title: 'Movement tracking', description: 'You should feel regular movement now.' }],
    financialDeadlines: [
      { title: 'Plan the baby shower budget', description: 'Average shower cost: $300-$1,000. Discuss with the host.' },
    ],
    checklist: ['Confirm baby shower date', 'Start nursery planning'],
  },
  22: {
    babySize: 'Spaghetti squash',
    babyEmoji: '🍝',
    babyLengthCm: 27.8,
    babyWeightG: 430,
    babyDevelopment: 'Baby has eyebrows and eyelashes. Senses are sharpening.',
    momChanges: 'Some women feel sexy and energetic. Others feel awkward — both are normal.',
    momSymptoms: ['Increased libido', 'Bigger appetite', 'Hot flashes'],
    medicalMilestones: [{ title: 'Routine prenatal', description: 'Quick check-in visit.' }],
    financialDeadlines: [
      { title: 'Research life insurance', description: 'Term life policies are cheapest while young and healthy. Cover both parents.' },
    ],
    checklist: ['Quote term life insurance', 'Add baby to estate plan (if applicable)'],
  },
  23: {
    babySize: 'Mango',
    babyEmoji: '🥭',
    babyLengthCm: 28.9,
    babyWeightG: 500,
    babyDevelopment: 'Baby has fingerprints and can hear distinct sounds.',
    momChanges: 'Linea nigra may darken. Edema (swelling) can start.',
    momSymptoms: ['Swelling', 'Backache', 'Snoring'],
    medicalMilestones: [{ title: 'Viability approaching', description: 'Babies born from week 24 have a chance of survival with NICU care.' }],
    financialDeadlines: [
      { title: 'Understand NICU costs', description: 'NICU stays average $3,000-$10,000 per day. Verify your max out-of-pocket.' },
    ],
    checklist: ['Tour the hospital / birthing center', 'Sign up for childbirth classes'],
  },
  24: {
    babySize: 'Ear of corn',
    babyEmoji: '🌽',
    babyLengthCm: 30,
    babyWeightG: 600,
    babyDevelopment: 'Viability milestone — lungs are developing surfactant. Skin is becoming less translucent.',
    momChanges: 'You may feel breathless climbing stairs.',
    momSymptoms: ['Shortness of breath', 'Itchy skin', 'Stronger movements'],
    medicalMilestones: [
      { title: 'Viability milestone', description: 'Babies born now have ~60% survival rate with intensive care.' },
      { title: 'Glucose challenge prep', description: 'Coming up at weeks 24-28.' },
    ],
    financialDeadlines: [
      { title: 'Re-check year-end HSA/FSA', description: 'You may want to plan to roll over or use funds before December.' },
    ],
    checklist: ['Take a childbirth class', 'Pack hospital tour into schedule'],
  },
  25: {
    babySize: 'Cauliflower',
    babyEmoji: '🥦',
    babyLengthCm: 34.6,
    babyWeightG: 660,
    babyDevelopment: 'Baby\'s brain is developing rapidly. Hair color is being determined.',
    momChanges: 'Heartburn and constipation peak. Sleep gets harder.',
    momSymptoms: ['Heartburn', 'Restless legs', 'Constipation'],
    medicalMilestones: [{ title: 'Possible Rh shot (if Rh-negative)', description: 'RhoGAM shot is given around week 28 to prevent complications.' }],
    financialDeadlines: [
      { title: 'Confirm pediatrician', description: 'You\'ll need to provide their name at the hospital.' },
    ],
    checklist: ['Lock in pediatrician', 'Start sleeping with a pregnancy pillow'],
  },
  26: {
    babySize: 'Scallion',
    babyEmoji: '🌿',
    babyLengthCm: 35.6,
    babyWeightG: 760,
    babyDevelopment: 'Baby\'s eyes start opening. Lungs are practicing breathing motions.',
    momChanges: 'Belly is now obviously pregnant from a distance.',
    momSymptoms: ['Backache', 'Hand pain (carpal tunnel)', 'Round ligament pain'],
    medicalMilestones: [{ title: 'Childbirth class series', description: 'Most classes run 6-8 weeks. Start now if you haven\'t.' }],
    financialDeadlines: [
      { title: 'Plan maternity/paternity leave dates', description: 'Submit official leave paperwork to HR 30+ days before start date.' },
    ],
    checklist: ['Submit FMLA paperwork', 'Plan return-to-work logistics'],
  },
  27: {
    babySize: 'Head of lettuce',
    babyEmoji: '🥬',
    babyLengthCm: 36.6,
    babyWeightG: 875,
    babyDevelopment: 'Baby has sleep/wake cycles. Brain activity is increasing significantly.',
    momChanges: 'End of the second trimester. Energy may dip again.',
    momSymptoms: ['Braxton Hicks contractions', 'Leg cramps', 'Decreased energy'],
    medicalMilestones: [{ title: 'End of T2', description: 'You\'re 67% through pregnancy!' }],
    financialDeadlines: [
      { title: 'Third trimester budget check', description: 'Reconcile spending vs your initial budget. Reserve $3,000-$5,000 for last-minute purchases.' },
    ],
    checklist: ['Reconcile pregnancy budget', 'Set up the nursery'],
  },
  28: {
    babySize: 'Eggplant',
    babyEmoji: '🍆',
    babyLengthCm: 37.6,
    babyWeightG: 1005,
    babyDevelopment: 'Baby can blink and dream (REM sleep). Eyelashes are fully formed.',
    momChanges: 'Welcome to T3! Visits become every 2 weeks.',
    momSymptoms: ['Fatigue returns', 'Hemorrhoids', 'Frequent urination'],
    medicalMilestones: [
      { title: 'GLUCOSE TOLERANCE TEST', description: 'Screen for gestational diabetes. 1-hour test; possibly followed by a 3-hour test if abnormal.' },
      { title: 'Rh shot if needed', description: 'RhoGAM injection for Rh-negative moms.' },
      { title: 'TDAP vaccine', description: 'Recommended between 27-36 weeks to protect baby from whooping cough.' },
    ],
    financialDeadlines: [
      { title: 'THIRD TRIMESTER BUDGET CHECK', description: 'Final review of your savings cushion. Aim for 3-6 months of expenses on hand.' },
      { title: 'Estimate take-home pay during leave', description: 'Account for short-term disability (usually 60-67% of salary), PTO, FMLA unpaid weeks.' },
      { title: 'Update tax withholding', description: 'A new dependent changes your W-4. Adjust now for an accurate refund.' },
    ],
    checklist: [
      'Complete glucose test',
      'Get TDAP shot',
      'Reconcile budget — close any gaps',
      'Submit short-term disability paperwork',
      'Update W-4 with HR',
    ],
    headline: 'Glucose test & third-trimester budget check.',
  },
  29: {
    babySize: 'Butternut squash',
    babyEmoji: '🎃',
    babyLengthCm: 38.6,
    babyWeightG: 1150,
    babyDevelopment: 'Baby is putting on fat and starting head-down positioning.',
    momChanges: 'Bigger and more uncomfortable. Sleep is rough.',
    momSymptoms: ['Heartburn', 'Insomnia', 'Stronger kicks'],
    medicalMilestones: [{ title: 'Kick counts', description: 'Count 10 movements per session, ideally same time each day.' }],
    financialDeadlines: [
      { title: 'Build emergency cash cushion', description: 'Target 3 months expenses minimum in liquid savings before baby arrives.' },
    ],
    checklist: ['Track kick counts daily', 'Practice relaxation techniques'],
  },
  30: {
    babySize: 'Cabbage',
    babyEmoji: '🥬',
    babyLengthCm: 39.9,
    babyWeightG: 1320,
    babyDevelopment: 'Baby\'s eyesight is improving. Bone marrow is making blood cells.',
    momChanges: 'Mood swings can return. Nesting instinct may kick in.',
    momSymptoms: ['Mood swings', 'Nesting', 'Heartburn'],
    medicalMilestones: [{ title: 'Bi-weekly visits begin', description: 'You\'ll see your OB every 2 weeks now.' }],
    financialDeadlines: [
      { title: 'Set up a will', description: 'Designate guardianship and beneficiaries. Online wills start at $150.' },
    ],
    checklist: ['Create or update will', 'Designate guardians'],
  },
  31: {
    babySize: 'Coconut',
    babyEmoji: '🥥',
    babyLengthCm: 41.1,
    babyWeightG: 1500,
    babyDevelopment: 'All five senses are working. Baby is gaining about half a pound a week.',
    momChanges: 'Breast may leak colostrum. Sleep is increasingly difficult.',
    momSymptoms: ['Leaking breasts', 'Shortness of breath', 'Vivid dreams'],
    medicalMilestones: [{ title: 'Plan birth preferences', description: 'Start drafting a birth plan if you haven\'t.' }],
    financialDeadlines: [
      { title: 'Confirm baby on insurance', description: 'Most insurers allow 30-60 days post-birth to add baby. Note the deadline now.' },
    ],
    checklist: ['Draft birth plan', 'Take infant CPR class'],
  },
  32: {
    babySize: 'Jicama',
    babyEmoji: '🟤',
    babyLengthCm: 42.4,
    babyWeightG: 1700,
    babyDevelopment: 'Baby practices breathing motions. Toenails are visible.',
    momChanges: 'Pelvic pressure increases. Walking gets harder.',
    momSymptoms: ['Pelvic pain', 'Heartburn', 'Bigger feet (yes really)'],
    medicalMilestones: [{ title: 'Group B strep prep', description: 'Test happens around 35-37 weeks. Just know it\'s coming.' }],
    financialDeadlines: [
      { title: 'Stock up via registry completion', description: 'Use 15% registry discounts for any final items. Don\'t buy diapers in bulk yet.' },
    ],
    checklist: ['Use registry completion discounts', 'Install car seat (or schedule check)'],
  },
  33: {
    babySize: 'Pineapple',
    babyEmoji: '🍍',
    babyLengthCm: 43.7,
    babyWeightG: 1920,
    babyDevelopment: 'Baby\'s skull bones are soft to allow for birth canal passage.',
    momChanges: 'Trouble breathing as the uterus pushes diaphragm.',
    momSymptoms: ['Pelvic pressure', 'Insomnia', 'Forgetfulness'],
    medicalMilestones: [{ title: 'Pre-register pediatrician', description: 'Provide pediatrician info to your hospital.' }],
    financialDeadlines: [
      { title: 'Pre-pay deductibles', description: 'Some hospitals offer discounts for pre-payment of estimated patient responsibility.' },
    ],
    checklist: ['Pre-register baby at hospital', 'Pre-pay deductible if offered'],
  },
  34: {
    babySize: 'Cantaloupe',
    babyEmoji: '🍈',
    babyLengthCm: 45,
    babyWeightG: 2150,
    babyDevelopment: 'Central nervous system is maturing. Lungs are nearly developed.',
    momChanges: 'Tired and ready to be done. Common at this point!',
    momSymptoms: ['Exhaustion', 'Swelling', 'Pelvic pain'],
    medicalMilestones: [{ title: 'Finalize birth plan', description: 'Share with OB and birth partner.' }],
    financialDeadlines: [
      { title: 'Finalize maternity leave', description: 'Confirm start date and any unused PTO that can supplement income.' },
    ],
    checklist: ['Finalize maternity leave dates', 'Print birth plan copies'],
  },
  35: {
    babySize: 'Honeydew melon',
    babyEmoji: '🍈',
    babyLengthCm: 46.2,
    babyWeightG: 2380,
    babyDevelopment: 'Kidneys are fully developed. Liver can process some waste.',
    momChanges: 'Visits become weekly. Cervix may start softening.',
    momSymptoms: ['Increased pelvic pressure', 'Frequent urination', 'Braxton Hicks'],
    medicalMilestones: [
      { title: 'Group B Strep test', description: 'Quick swab — results determine whether antibiotics are given during labor.' },
      { title: 'Weekly visits begin', description: 'Every visit will check baby\'s position and your cervix.' },
    ],
    financialDeadlines: [
      { title: 'Set up paternity leave / partner\'s plan', description: 'Confirm partner\'s leave dates and any paid options.' },
    ],
    checklist: ['Get GBS test', 'Coordinate partner\'s leave'],
  },
  36: {
    babySize: 'Romaine lettuce',
    babyEmoji: '🥬',
    babyLengthCm: 47.4,
    babyWeightG: 2620,
    babyDevelopment: 'Baby is considered "late preterm" — most are head-down by now.',
    momChanges: '"Lightening" — baby drops lower into pelvis, easier to breathe.',
    momSymptoms: ['Easier breathing', 'More pelvic pressure', 'Loose stools'],
    medicalMilestones: [
      { title: 'Weekly checkups continue', description: 'Cervical checks may begin.' },
      { title: 'Position check', description: 'If baby is breech, doctor may discuss options.' },
    ],
    financialDeadlines: [
      { title: 'Hospital pre-registration deadline', description: 'Submit pre-registration paperwork if not done.' },
      { title: 'Confirm hospital cost estimate', description: 'Request a final itemized cost estimate from billing.' },
    ],
    checklist: [
      'PACK HOSPITAL BAG',
      'Finalize birth plan',
      'Install car seat & get it inspected (free at fire stations)',
      'Wash baby clothes & set up nursery',
      'Prep freezer meals',
    ],
    headline: 'Pack the hospital bag. Finalize the birth plan.',
  },
  37: {
    babySize: 'Swiss chard',
    babyEmoji: '🥬',
    babyLengthCm: 48.6,
    babyWeightG: 2860,
    babyDevelopment: 'Baby is considered "early term". Practicing breathing, sucking, and grasping.',
    momChanges: 'You may lose your mucus plug. Contractions may become more frequent.',
    momSymptoms: ['Loss of mucus plug possible', 'Frequent Braxton Hicks', 'Trouble sleeping'],
    medicalMilestones: [{ title: 'Recognize labor signs', description: 'Regular contractions, water breaking, or bloody show = call your OB.' }],
    financialDeadlines: [
      { title: 'Confirm baby coverage process', description: 'Know exactly how to add baby to insurance. Have the form/portal ready.' },
    ],
    checklist: ['Know labor signs cold', 'Have phone numbers in one place'],
  },
  38: {
    babySize: 'Leek',
    babyEmoji: '🟢',
    babyLengthCm: 49.8,
    babyWeightG: 3080,
    babyDevelopment: 'Baby has a firm grasp and is shedding lanugo. Most organs fully mature.',
    momChanges: 'Extreme tiredness. You\'re ready for this.',
    momSymptoms: ['Exhaustion', 'Increased discharge', 'Stronger contractions'],
    medicalMilestones: [{ title: 'Weekly check + cervical exam', description: 'Doctor may check dilation and effacement.' }],
    financialDeadlines: [
      { title: 'Verify lactation consultant coverage', description: 'ACA requires plans to cover lactation services. Confirm in-network options.' },
    ],
    checklist: ['Find an in-network lactation consultant', 'Final freezer-meal prep'],
  },
  39: {
    babySize: 'Mini watermelon',
    babyEmoji: '🍉',
    babyLengthCm: 50.7,
    babyWeightG: 3290,
    babyDevelopment: 'Officially "full term". Brain is still developing rapidly.',
    momChanges: 'Could be any day now. Trust your body.',
    momSymptoms: ['Contractions', 'Pelvic pressure', 'Nesting bursts'],
    medicalMilestones: [{ title: 'Weekly visit', description: 'Doctor may discuss induction if you go past 41 weeks.' }],
    financialDeadlines: [
      { title: 'Lock in childcare start date', description: 'Confirm with daycare or nanny so there\'s no last-minute scramble.' },
    ],
    checklist: ['Confirm childcare start date', 'Rest as much as possible'],
  },
  40: {
    babySize: 'Watermelon',
    babyEmoji: '🍉',
    babyLengthCm: 51.2,
    babyWeightG: 3460,
    babyDevelopment: 'Baby is fully cooked! Average weight 7.5 lb, length 20 in.',
    momChanges: 'Due date! Only ~5% of babies arrive exactly today.',
    momSymptoms: ['Strong contractions', 'Water breaking', 'Anxiousness'],
    medicalMilestones: [
      { title: 'DUE DATE', description: 'If you go past, your OB will monitor weekly until induction (usually 41-42 weeks).' },
      { title: 'Labor & delivery', description: 'Know the signs: regular contractions 5 min apart for 1 hour, water breaking, or bloody show.' },
    ],
    financialDeadlines: [
      { title: 'FINAL COST REVIEW', description: 'You\'ve spent or will spend $20K-$50K total. Track every dollar for the year-end tax review.' },
      { title: 'Add baby to insurance (30-60 day window)', description: 'Do this immediately after birth — you\'ll need baby\'s SSN later but can start now.' },
      { title: 'Apply for baby\'s SSN at hospital', description: 'Easiest way — fill out form at birth.' },
      { title: 'Plan FMLA/leave start', description: 'Confirm leave is active. Set up partner\'s leave to overlap or sequence.' },
    ],
    checklist: [
      'Final cost review',
      'Apply for baby\'s SSN at hospital',
      'Add baby to insurance within deadline',
      'Activate maternity/paternity leave',
      'Take a deep breath — you\'re ready',
    ],
    headline: 'Due date! Final cost review.',
  },
};

const DEFAULT_SIZES: { week: number; size: string; emoji: string }[] = [
  { week: 5, size: 'Sesame seed', emoji: '🌱' },
  { week: 10, size: 'Strawberry', emoji: '🍓' },
  { week: 15, size: 'Apple', emoji: '🍎' },
  { week: 20, size: 'Banana', emoji: '🍌' },
  { week: 25, size: 'Cauliflower', emoji: '🥦' },
  { week: 30, size: 'Cabbage', emoji: '🥬' },
  { week: 35, size: 'Honeydew melon', emoji: '🍈' },
  { week: 40, size: 'Watermelon', emoji: '🍉' },
];

function defaultWeek(week: number): WeekData {
  const trimester = trimesterOf(week);
  const nearest = DEFAULT_SIZES.reduce((prev, curr) =>
    Math.abs(curr.week - week) < Math.abs(prev.week - week) ? curr : prev
  );
  return {
    week,
    trimester,
    babySize: nearest.size,
    babyEmoji: nearest.emoji,
    babyDevelopment: `Week ${week}: Your baby continues developing in the ${TRIMESTER_LABELS[trimester].toLowerCase()}. Major organs continue to mature.`,
    momChanges: `Week ${week} brings continued changes to your body as your pregnancy progresses.`,
    momSymptoms: ['Fatigue', 'Mild back pain', 'Mood swings'],
    medicalMilestones: [{ title: 'Routine prenatal care', description: 'Continue regular prenatal visits as scheduled.' }],
    financialDeadlines: [{ title: 'Stay on track', description: 'Review your pregnancy budget and savings progress.' }],
    checklist: ['Continue prenatal vitamins', 'Track your symptoms', 'Stay hydrated'],
  };
}

/** Get full data for a specific week (1-40). */
export function getWeekData(week: number): WeekData {
  if (week < 1 || week > 40 || !Number.isInteger(week)) {
    throw new Error(`Invalid pregnancy week: ${week}. Must be an integer between 1 and 40.`);
  }
  const base = defaultWeek(week);
  const override = WEEK_OVERRIDES[week];
  if (!override) return base;
  return {
    ...base,
    ...override,
    week,
    trimester: trimesterOf(week),
  };
}

/** Get an array of all 40 weeks of data. */
export function getAllWeeks(): WeekData[] {
  return Array.from({ length: 40 }, (_, i) => getWeekData(i + 1));
}

/** Calculate current pregnancy week from a due date string (YYYY-MM-DD). */
export function calculateCurrentWeek(dueDate: string | null | undefined): number | null {
  if (!dueDate) return null;
  const due = new Date(dueDate);
  if (Number.isNaN(due.getTime())) return null;
  const now = new Date();
  const diffMs = due.getTime() - now.getTime();
  const weeksUntilDue = diffMs / (1000 * 60 * 60 * 24 * 7);
  const week = Math.round(40 - weeksUntilDue);
  if (week < 1) return null;
  if (week > 40) return 40;
  return week;
}

/** Filter weeks by trimester. */
export function getWeeksByTrimester(trimester: Trimester): WeekData[] {
  const [start, end] = TRIMESTER_RANGES[trimester];
  return Array.from({ length: end - start + 1 }, (_, i) => getWeekData(start + i));
}
