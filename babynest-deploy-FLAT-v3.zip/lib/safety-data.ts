/**
 * Pregnancy "Is It Safe?" database
 *
 * IMPORTANT: This data is for informational purposes only and is not medical
 * advice. Every pregnancy is different — users should always consult their
 * own healthcare provider for personalized recommendations.
 */

export type SafetyVerdict = 'yes' | 'no' | 'maybe';

export type SafetyCategory = 'food' | 'medications' | 'activities' | 'beauty';

export interface SafetyItem {
  /** URL-safe identifier */
  slug: string;
  /** Display name (the thing being asked about) */
  name: string;
  /** Common-language question, e.g. "Can I eat sushi while pregnant?" */
  question: string;
  /** Searchable aliases / alternate names */
  aliases: string[];
  category: SafetyCategory;
  verdict: SafetyVerdict;
  /** One-line summary that pairs with the verdict */
  shortAnswer: string;
  /** Longer explanation, 2-4 sentences */
  explanation: string;
  /** Practical safer-alternative tip (optional) */
  tip?: string;
  /** Human-readable source attribution */
  source: string;
  /** URL for the source (optional) */
  sourceUrl?: string;
}

export const CATEGORY_META: Record<
  SafetyCategory,
  { label: string; emoji: string; description: string }
> = {
  food: {
    label: 'Food & Drink',
    emoji: '🍽️',
    description: 'Foods, drinks, and ingredients to know about.',
  },
  medications: {
    label: 'Medications',
    emoji: '💊',
    description: 'Over-the-counter and common medications.',
  },
  activities: {
    label: 'Activities',
    emoji: '🤸',
    description: 'Exercise, travel, and everyday activities.',
  },
  beauty: {
    label: 'Beauty & Products',
    emoji: '💅',
    description: 'Cosmetics, treatments, and household products.',
  },
};

export const VERDICT_META: Record<
  SafetyVerdict,
  { label: string; emoji: string; color: string; bg: string; border: string }
> = {
  yes: {
    label: 'Generally Safe',
    emoji: '✅',
    color: 'text-primary-700',
    bg: 'bg-primary-50',
    border: 'border-primary-200',
  },
  maybe: {
    label: 'Use Caution',
    emoji: '⚠️',
    color: 'text-amber-700',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
  },
  no: {
    label: 'Avoid',
    emoji: '🚫',
    color: 'text-accent-700',
    bg: 'bg-accent-50',
    border: 'border-accent-200',
  },
};

export const SAFETY_ITEMS: SafetyItem[] = [
  // ---------- FOOD & DRINK ----------
  {
    slug: 'sushi',
    name: 'Sushi',
    question: 'Can I eat sushi while pregnant?',
    aliases: ['sashimi', 'raw fish', 'nigiri'],
    category: 'food',
    verdict: 'no',
    shortAnswer: 'Skip raw fish sushi — cooked or veggie rolls are fine.',
    explanation:
      'Raw fish can carry parasites and bacteria like Listeria and Salmonella, which are riskier during pregnancy. Cooked sushi (shrimp tempura, eel, California rolls) and fully vegetarian rolls are considered safe. Also watch mercury levels: avoid tuna, swordfish, king mackerel, and tilefish even when cooked.',
    tip: 'Choose cooked rolls or veggie rolls from a trusted restaurant.',
    source: 'ACOG & FDA',
    sourceUrl:
      'https://www.acog.org/womens-health/faqs/nutrition-during-pregnancy',
  },
  {
    slug: 'caffeine',
    name: 'Caffeine',
    question: 'Can I drink coffee or caffeine while pregnant?',
    aliases: ['coffee', 'espresso', 'tea', 'energy drinks'],
    category: 'food',
    verdict: 'maybe',
    shortAnswer: 'Up to 200 mg per day (about one 12 oz coffee) is OK.',
    explanation:
      'ACOG considers moderate caffeine intake — under 200 mg per day — to be safe during pregnancy. Higher amounts have been linked in some studies to miscarriage and low birth weight. Remember caffeine is also in tea, soda, chocolate, and many energy drinks.',
    tip: 'A 12 oz brewed coffee is ~200 mg. Half-caf or decaf for refills.',
    source: 'ACOG',
    sourceUrl:
      'https://www.acog.org/womens-health/experts-and-stories/the-latest/how-much-coffee-can-i-drink-while-im-pregnant',
  },
  {
    slug: 'alcohol',
    name: 'Alcohol',
    question: 'Is any amount of alcohol safe during pregnancy?',
    aliases: ['wine', 'beer', 'liquor', 'cocktails'],
    category: 'food',
    verdict: 'no',
    shortAnswer: 'No amount of alcohol is considered safe in pregnancy.',
    explanation:
      'The CDC, ACOG, and AAP all recommend no alcohol during pregnancy. Prenatal alcohol exposure can cause fetal alcohol spectrum disorders (FASDs), which are 100% preventable. There is no known safe amount, type, or trimester for drinking.',
    tip: 'Mocktails, sparkling water with bitters-free citrus, or NA beer.',
    source: 'CDC',
    sourceUrl: 'https://www.cdc.gov/ncbddd/fasd/alcohol-use.html',
  },
  {
    slug: 'deli-meat',
    name: 'Deli Meat',
    question: 'Can I eat deli meat or cold cuts while pregnant?',
    aliases: ['cold cuts', 'lunch meat', 'turkey sandwich', 'ham'],
    category: 'food',
    verdict: 'maybe',
    shortAnswer: 'Heat it until steaming hot (165°F) before eating.',
    explanation:
      'Deli meats and hot dogs can carry Listeria, which is especially dangerous in pregnancy. Heating them until steaming hot (165°F / 74°C) kills the bacteria. The same applies to pâtés and refrigerated smoked seafood.',
    source: 'FDA & CDC',
    sourceUrl:
      'https://www.fda.gov/food/people-risk-foodborne-illness/food-safety-pregnant-women-their-unborn-babies-and-children-under-five',
  },
  {
    slug: 'soft-cheese',
    name: 'Soft Cheese',
    question: 'Can I eat soft cheese during pregnancy?',
    aliases: ['brie', 'feta', 'camembert', 'blue cheese', 'queso fresco'],
    category: 'food',
    verdict: 'maybe',
    shortAnswer: 'Only if labeled "pasteurized."',
    explanation:
      'Unpasteurized soft cheeses (brie, camembert, feta, blue cheese, queso fresco) can carry Listeria. Pasteurized versions — which most cheese sold in U.S. grocery stores is — are safe. Always check the label, especially with imported or farmers-market cheese.',
    source: 'FDA',
  },
  {
    slug: 'runny-eggs',
    name: 'Runny / Raw Eggs',
    question: 'Can I eat runny or raw eggs while pregnant?',
    aliases: ['soft eggs', 'eggs benedict', 'cookie dough', 'caesar dressing'],
    category: 'food',
    verdict: 'no',
    shortAnswer: 'Cook eggs until both yolk and white are firm.',
    explanation:
      'Raw or undercooked eggs can carry Salmonella. That includes soft-boiled, sunny-side up, homemade Caesar dressing, hollandaise, raw cookie dough, and homemade mayo. Use pasteurized eggs if you want a runny yolk.',
    tip: 'Pasteurized shell eggs (labeled "pasteurized") are safe runny.',
    source: 'FDA',
  },
  {
    slug: 'tuna',
    name: 'Tuna',
    question: 'Can I eat tuna while pregnant?',
    aliases: ['canned tuna', 'ahi', 'yellowfin'],
    category: 'food',
    verdict: 'maybe',
    shortAnswer: 'Light tuna up to 2-3 servings/week; limit albacore.',
    explanation:
      'Light canned tuna is lower in mercury and is on the FDA "Best Choices" list (up to 2-3 servings per week). Albacore/white tuna and yellowfin are higher in mercury — limit to 1 serving per week. Avoid bigeye tuna entirely.',
    source: 'FDA',
    sourceUrl: 'https://www.fda.gov/food/consumers/advice-about-eating-fish',
  },
  {
    slug: 'honey',
    name: 'Honey',
    question: 'Can I eat honey during pregnancy?',
    aliases: ['raw honey'],
    category: 'food',
    verdict: 'yes',
    shortAnswer: 'Safe for you — but never give honey to a baby under 12 months.',
    explanation:
      'The botulism spores in honey that can be dangerous for infants are not a problem for healthy adults — your digestive system handles them easily. Honey is safe in pregnancy. Just remember not to give any honey (including in foods) to your baby until they turn one.',
    source: 'CDC',
  },
  {
    slug: 'raw-sprouts',
    name: 'Raw Sprouts',
    question: 'Can I eat raw sprouts while pregnant?',
    aliases: ['alfalfa sprouts', 'bean sprouts', 'clover sprouts'],
    category: 'food',
    verdict: 'no',
    shortAnswer: 'Avoid raw sprouts; cook them thoroughly if you want them.',
    explanation:
      'Raw and lightly cooked sprouts (alfalfa, clover, mung bean, radish) have been linked to E. coli and Salmonella outbreaks because of how they\'re grown. The FDA recommends pregnant people avoid them unless cooked until steaming hot.',
    source: 'FDA',
  },
  {
    slug: 'unpasteurized-juice',
    name: 'Unpasteurized Juice',
    question: 'Can I drink unpasteurized juice or cider?',
    aliases: ['fresh juice', 'raw juice', 'apple cider', 'fresh squeezed'],
    category: 'food',
    verdict: 'no',
    shortAnswer: 'Stick to pasteurized juice during pregnancy.',
    explanation:
      'Fresh-squeezed or unpasteurized juice and cider (often sold at farm stands and juice bars) can contain E. coli, Salmonella, or Listeria. Pasteurized juice is widely available and safe. If you press juice at home, drink it immediately and keep produce clean.',
    source: 'FDA',
  },

  // ---------- MEDICATIONS ----------
  {
    slug: 'tylenol',
    name: 'Tylenol (Acetaminophen)',
    question: 'Can I take Tylenol while pregnant?',
    aliases: ['acetaminophen', 'paracetamol'],
    category: 'medications',
    verdict: 'yes',
    shortAnswer: 'Generally the preferred pain reliever during pregnancy.',
    explanation:
      'Acetaminophen (Tylenol) is the most commonly recommended pain reliever in pregnancy and is considered safe at standard doses. ACOG continues to recommend it for pain and fever. Use the lowest effective dose for the shortest time, and check with your provider before regular use.',
    source: 'ACOG',
    sourceUrl:
      'https://www.acog.org/news/news-releases/2021/09/response-to-consensus-statement-on-paracetamol-use-during-pregnancy',
  },
  {
    slug: 'ibuprofen',
    name: 'Ibuprofen / Advil',
    question: 'Can I take ibuprofen while pregnant?',
    aliases: ['advil', 'motrin', 'nsaid', 'aleve', 'naproxen'],
    category: 'medications',
    verdict: 'no',
    shortAnswer:
      'Avoid NSAIDs after 20 weeks; ask your doctor in the first half too.',
    explanation:
      'The FDA recommends avoiding NSAIDs (ibuprofen, naproxen, aspirin) at 20 weeks or later because they can cause kidney problems in the fetus and low amniotic fluid. Many providers also prefer you avoid them earlier in pregnancy. Acetaminophen is usually recommended instead.',
    source: 'FDA',
    sourceUrl:
      'https://www.fda.gov/drugs/drug-safety-and-availability/fda-recommends-avoiding-use-nsaids-pregnancy-20-weeks-or-later',
  },
  {
    slug: 'benadryl',
    name: 'Benadryl (Diphenhydramine)',
    question: 'Can I take Benadryl while pregnant?',
    aliases: ['diphenhydramine', 'antihistamine'],
    category: 'medications',
    verdict: 'yes',
    shortAnswer: 'Considered safe — but it can make you drowsy.',
    explanation:
      'Diphenhydramine (Benadryl) has a long track record of use in pregnancy and is generally considered safe for short-term allergy or sleep issues. Newer non-drowsy options like loratadine (Claritin) and cetirizine (Zyrtec) are also typically considered safe. Always confirm with your provider.',
    source: 'ACOG',
  },
  {
    slug: 'sudafed',
    name: 'Sudafed (Pseudoephedrine)',
    question: 'Can I take Sudafed while pregnant?',
    aliases: ['pseudoephedrine', 'decongestant'],
    category: 'medications',
    verdict: 'maybe',
    shortAnswer: 'Avoid in the first trimester; ask your doctor later.',
    explanation:
      'Pseudoephedrine has been associated with a small increase in certain birth defects when used in the first trimester. Many providers recommend avoiding it in the first 12-13 weeks. Saline sprays, humidifiers, and nasal strips are safer first-line options.',
    source: 'ACOG',
  },
  {
    slug: 'pepto-bismol',
    name: 'Pepto-Bismol',
    question: 'Can I take Pepto-Bismol while pregnant?',
    aliases: ['bismuth subsalicylate'],
    category: 'medications',
    verdict: 'no',
    shortAnswer: 'Avoid — it contains salicylates (aspirin-like).',
    explanation:
      'Pepto-Bismol contains bismuth subsalicylate, which is in the same family as aspirin. It is not recommended in pregnancy, especially after 20 weeks. Tums, Maalox, and Mylanta are typically safe antacid options; ask your provider about Zantac (famotidine) for heartburn.',
    source: 'Mayo Clinic',
  },
  {
    slug: 'prenatal-vitamins',
    name: 'Prenatal Vitamins',
    question: 'Should I take a prenatal vitamin?',
    aliases: ['folic acid', 'folate', 'prenatals'],
    category: 'medications',
    verdict: 'yes',
    shortAnswer: 'Yes — ideally start before conception.',
    explanation:
      'Prenatal vitamins help cover nutrients that are critical for development, especially folic acid (400-800 mcg) which reduces the risk of neural tube defects. Iron, iodine, DHA, and choline matter too. Start as early as possible — ideally 1-3 months before trying to conceive.',
    source: 'ACOG & CDC',
  },

  // ---------- ACTIVITIES ----------
  {
    slug: 'hot-tubs',
    name: 'Hot Tubs',
    question: 'Can I use a hot tub while pregnant?',
    aliases: ['jacuzzi', 'spa', 'hot bath', 'sauna'],
    category: 'activities',
    verdict: 'no',
    shortAnswer:
      'Skip hot tubs — your core body temperature can climb too high.',
    explanation:
      'Hot tubs and saunas can raise core body temperature above 102.2°F (39°C), which has been linked to neural tube defects and miscarriage, especially in the first trimester. A warm (not hot) bath under 100°F that doesn\'t raise your core temperature is fine. Avoid soaking longer than 10 minutes in anything warmer.',
    source: 'ACOG',
  },
  {
    slug: 'exercise',
    name: 'Exercise',
    question: 'Can I exercise while pregnant?',
    aliases: ['workout', 'running', 'cardio', 'gym', 'lifting weights'],
    category: 'activities',
    verdict: 'yes',
    shortAnswer:
      'Yes — 150 min/week of moderate activity is recommended.',
    explanation:
      'ACOG recommends 150 minutes of moderate-intensity aerobic activity per week for most pregnant people with uncomplicated pregnancies. Walking, swimming, prenatal yoga, stationary cycling, and modified strength training are great. Avoid contact sports, activities with fall risk (downhill skiing, horseback), and lying flat on your back after the first trimester.',
    source: 'ACOG',
    sourceUrl:
      'https://www.acog.org/womens-health/faqs/exercise-during-pregnancy',
  },
  {
    slug: 'flying',
    name: 'Flying / Air Travel',
    question: 'Is it safe to fly while pregnant?',
    aliases: ['airplane', 'air travel', 'plane'],
    category: 'activities',
    verdict: 'yes',
    shortAnswer: 'Safe until ~36 weeks for uncomplicated pregnancies.',
    explanation:
      'For most healthy pregnancies, flying is safe up to 36 weeks for domestic travel (many airlines cut off earlier for international). Wear your seatbelt low under the bump, stay hydrated, and walk the aisle every hour to lower clot risk. Compression socks help. Check airline policies and bring a doctor\'s note after 28 weeks.',
    source: 'ACOG',
  },
  {
    slug: 'cat-litter',
    name: 'Cat Litter',
    question: 'Can I change the cat litter while pregnant?',
    aliases: ['toxoplasmosis', 'cat box', 'kitty litter'],
    category: 'activities',
    verdict: 'no',
    shortAnswer: 'Have someone else clean it to avoid toxoplasmosis.',
    explanation:
      'Cat feces can contain Toxoplasma gondii, a parasite that can cause serious problems for the fetus. If you must change litter yourself, wear gloves and a mask and wash hands thoroughly after. Cleaning daily reduces risk (the parasite takes 1-5 days to become infectious). Indoor-only cats fed cooked or commercial food are very low risk.',
    source: 'CDC',
  },
  {
    slug: 'sleeping-on-back',
    name: 'Sleeping on Back',
    question: 'Is it safe to sleep on my back while pregnant?',
    aliases: ['back sleeping', 'supine', 'sleep position'],
    category: 'activities',
    verdict: 'maybe',
    shortAnswer: 'Side sleeping is recommended after ~20 weeks.',
    explanation:
      'After about 20 weeks, the growing uterus can compress the vena cava when you lie flat on your back, reducing blood flow. Sleeping on your side (either side, though left is often recommended) is safer. If you wake up on your back, don\'t panic — just roll back over. A pregnancy pillow helps a lot.',
    source: 'ACOG',
  },
  {
    slug: 'sex',
    name: 'Sex',
    question: 'Is sex safe during pregnancy?',
    aliases: ['intercourse', 'intimacy'],
    category: 'activities',
    verdict: 'yes',
    shortAnswer: 'Safe in most pregnancies — your provider will tell you otherwise.',
    explanation:
      'For uncomplicated pregnancies, sex is safe throughout. Your provider may advise against it if you have placenta previa, a history of preterm labor, unexplained bleeding, or a short cervix. Cramping after orgasm is normal; persistent contractions or bleeding warrant a call.',
    source: 'ACOG',
  },

  // ---------- BEAUTY & PRODUCTS ----------
  {
    slug: 'hair-dye',
    name: 'Hair Dye',
    question: 'Can I dye my hair while pregnant?',
    aliases: ['highlights', 'hair color', 'bleach'],
    category: 'beauty',
    verdict: 'maybe',
    shortAnswer: 'Generally low risk — many wait until after first trimester.',
    explanation:
      'Only small amounts of hair-dye chemicals are absorbed through the scalp, and there\'s no strong evidence linking modern dyes to birth defects. Many providers still suggest waiting until after the first trimester out of caution. Highlights/balayage (which sit on hair, not scalp), ammonia-free dyes, and well-ventilated rooms are lower-exposure options.',
    source: 'ACOG',
  },
  {
    slug: 'retinol',
    name: 'Retinol / Retinoids',
    question: 'Can I use retinol while pregnant?',
    aliases: ['tretinoin', 'retin-a', 'accutane', 'isotretinoin', 'adapalene'],
    category: 'beauty',
    verdict: 'no',
    shortAnswer: 'Avoid all retinoids — including topical.',
    explanation:
      'Oral retinoids (isotretinoin/Accutane) are known teratogens and cause severe birth defects. Topical retinoids (tretinoin, retinol, adapalene) absorb less, but they\'re still avoided in pregnancy out of an abundance of caution. Switch to azelaic acid, glycolic acid, vitamin C, or bakuchiol for similar benefits.',
    source: 'FDA',
  },
  {
    slug: 'salicylic-acid',
    name: 'Salicylic Acid',
    question: 'Can I use salicylic acid skincare while pregnant?',
    aliases: ['bha', 'acne treatment'],
    category: 'beauty',
    verdict: 'maybe',
    shortAnswer: 'Low-concentration topical OK; avoid peels and oral forms.',
    explanation:
      'Low-strength topical salicylic acid (≤2%) in cleansers and spot treatments is generally considered safe. High-strength chemical peels and oral salicylates (aspirin-family) should be avoided. Glycolic acid, azelaic acid, and benzoyl peroxide (in moderation) are alternatives.',
    source: 'AAD',
  },
  {
    slug: 'manicure-pedicure',
    name: 'Manicures & Pedicures',
    question: 'Are mani/pedis safe during pregnancy?',
    aliases: ['nail polish', 'gel nails', 'acrylics'],
    category: 'beauty',
    verdict: 'yes',
    shortAnswer: 'Yes — pick a well-ventilated salon.',
    explanation:
      'Occasional nail services are considered safe in pregnancy. The main concern is the fumes from acrylics and harsh polishes — choose a well-ventilated salon and avoid prolonged exposure. "3-free" or "10-free" polishes skip the most-questioned chemicals (formaldehyde, toluene, DBP).',
    source: 'ACOG',
  },
  {
    slug: 'essential-oils',
    name: 'Essential Oils',
    question: 'Are essential oils safe during pregnancy?',
    aliases: ['aromatherapy', 'diffuser'],
    category: 'beauty',
    verdict: 'maybe',
    shortAnswer: 'Some are fine diluted; several should be avoided.',
    explanation:
      'Many essential oils are fine to diffuse or use diluted topically (lavender, citrus, ginger). Others should be avoided in pregnancy, including rosemary, clary sage, basil, jasmine, juniper, and pennyroyal — some can stimulate contractions. Never ingest essential oils, and dilute before topical use.',
    source: 'Tisserand Institute',
  },
  {
    slug: 'sunscreen',
    name: 'Sunscreen',
    question: 'Is sunscreen safe while pregnant?',
    aliases: ['spf', 'sunblock'],
    category: 'beauty',
    verdict: 'yes',
    shortAnswer: 'Yes — mineral (zinc/titanium) sunscreens are preferred.',
    explanation:
      'Daily SPF is actually extra important in pregnancy because hormonal changes can cause melasma ("the mask of pregnancy"). Mineral sunscreens with zinc oxide or titanium dioxide sit on the skin and are the safest pick. Some chemical filters (like oxybenzone) are debated — many people switch to mineral just to be safe.',
    source: 'AAD',
  },
  {
    slug: 'botox',
    name: 'Botox & Fillers',
    question: 'Can I get Botox or fillers while pregnant?',
    aliases: ['cosmetic injections', 'filler', 'dysport'],
    category: 'beauty',
    verdict: 'no',
    shortAnswer: 'Postpone elective injections until after delivery.',
    explanation:
      'There\'s very limited safety data on Botox, fillers, and similar injectables in pregnancy, so they\'re not recommended. Most providers also pause these during breastfeeding. The effects are temporary anyway — easy enough to wait a few months.',
    source: 'AAD',
  },
  {
    slug: 'cleaning-products',
    name: 'Cleaning Products',
    question: 'Are household cleaning products safe to use?',
    aliases: ['bleach', 'ammonia', 'disinfectants'],
    category: 'beauty',
    verdict: 'maybe',
    shortAnswer: 'OK with ventilation; never mix bleach + ammonia.',
    explanation:
      'Most household cleaners are safe in normal use if you ventilate the room and wear gloves. Avoid mixing bleach with ammonia or vinegar (creates toxic fumes). Pass on oven cleaning, harsh solvents, and pesticide application if you can. Fragrance-free and "green" cleaners are nice alternatives.',
    source: 'EPA',
  },
];

// ---------- Helpers ----------

export function getCategoryItems(category: SafetyCategory): SafetyItem[] {
  return SAFETY_ITEMS.filter((i) => i.category === category);
}

export function searchSafetyItems(query: string): SafetyItem[] {
  const q = query.trim().toLowerCase();
  if (!q) return SAFETY_ITEMS;

  return SAFETY_ITEMS.filter((item) => {
    const hay = [
      item.name,
      item.question,
      item.shortAnswer,
      item.explanation,
      ...item.aliases,
    ]
      .join(' ')
      .toLowerCase();
    return hay.includes(q);
  });
}

export const TOTAL_SAFETY_ITEMS = SAFETY_ITEMS.length;
