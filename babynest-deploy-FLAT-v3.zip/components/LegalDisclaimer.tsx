'use client';

import { AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LegalDisclaimerProps {
  /** Page-specific disclaimer text */
  message?: string;
  /** Additional disclaimer type */
  type?: 'medical' | 'financial' | 'general' | 'demo';
  /** Custom className for styling */
  className?: string;
}

const DISCLAIMER_TEXT = {
  medical: 'This app is for educational purposes only and is not a substitute for professional medical advice. Always consult your healthcare provider for medical decisions.',
  financial: 'Financial information is for educational purposes only. Consult qualified financial advisors for personalized advice.',
  general: 'This app is for educational purposes only. Not HIPAA compliant.',
  demo: 'Data shown is for demonstration purposes. Verify all information independently.',
};

export function LegalDisclaimer({ 
  message, 
  type = 'general',
  className 
}: LegalDisclaimerProps) {
  const displayMessage = message || DISCLAIMER_TEXT[type];
  
  return (
    <div className={cn(
      "bg-amber-50 border-t border-amber-200 py-3 px-4",
      className
    )}>
      <div className="container mx-auto flex items-start gap-2 max-w-6xl">
        <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-800 leading-relaxed">
          {displayMessage}
        </p>
      </div>
    </div>
  );
}

/** Footer version for layout.tsx */
export function LegalFooter() {
  return (
    <footer className="bg-warm-50 border-t border-warm-200 py-4 mt-auto">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col md:flex-row gap-4 text-xs text-warm-600">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <p>
              <strong>Medical Disclaimer:</strong> This app is for educational purposes only and is not a substitute for professional medical advice. Always consult your healthcare provider.
            </p>
          </div>
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
            <p>
              <strong>Financial Disclaimer:</strong> Financial estimates are for planning purposes only. Consult qualified advisors.
            </p>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-warm-200 text-center text-xs text-warm-500">
          © {new Date().getFullYear()} BabyNest. Data is stored securely but not HIPAA compliant.
        </div>
      </div>
    </footer>
  );
}
