'use client';

import { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';

interface AnimatedBackgroundProps {
  className?: string;
  variant?: 'gradient' | 'mesh' | 'particles' | 'waves';
  colors?: string[];
  speed?: 'slow' | 'normal' | 'fast';
  intensity?: 'subtle' | 'medium' | 'strong';
}

export function AnimatedBackground({
  className,
  variant = 'gradient',
  colors = ['#FB8C8C', '#FEF0E6', '#A0D9E9'],
  speed = 'normal',
  intensity = 'subtle',
}: AnimatedBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  const speedMultiplier = {
    slow: 0.5,
    normal: 1,
    fast: 2,
  }[speed];

  const opacityMultiplier = {
    subtle: 0.3,
    medium: 0.5,
    strong: 0.8,
  }[intensity];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || variant !== 'particles') return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const particles: Array<{
      x: number;
      y: number;
      radius: number;
      vx: number;
      vy: number;
      color: string;
      alpha: number;
    }> = [];

    const particleCount = Math.floor((canvas.width * canvas.height) / 15000);
    
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: Math.random() * 3 + 1,
        vx: (Math.random() - 0.5) * 0.5 * speedMultiplier,
        vy: (Math.random() - 0.5) * 0.5 * speedMultiplier,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * opacityMultiplier,
      });
    }

    let frameCount = 0;
    const animate = () => {
      frameCount++;
      // Render every 2nd frame for performance
      if (frameCount % 2 === 0) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach((particle) => {
          particle.x += particle.vx;
          particle.y += particle.vy;

          if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
          if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;

          ctx.beginPath();
          ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
          ctx.fillStyle = particle.color;
          ctx.globalAlpha = particle.alpha;
          ctx.fill();

          // Draw connections
          particles.forEach((other) => {
            const dx = particle.x - other.x;
            const dy = particle.y - other.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 100) {
              ctx.beginPath();
              ctx.moveTo(particle.x, particle.y);
              ctx.lineTo(other.x, other.y);
              ctx.strokeStyle = particle.color;
              ctx.globalAlpha = (1 - distance / 100) * 0.1 * opacityMultiplier;
              ctx.stroke();
            }
          });
        });
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resize);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [variant, colors, speedMultiplier, opacityMultiplier]);

  const baseClasses = 'absolute inset-0 pointer-events-none overflow-hidden';

  if (variant === 'particles') {
    return (
      <canvas
        ref={canvasRef}
        className={cn(baseClasses, className)}
        style={{ opacity: opacityMultiplier }}
      />
    );
  }

  if (variant === 'gradient') {
    return (
      <div
        className={cn(baseClasses, className)}
        style={{
          background: `
            radial-gradient(ellipse at 20% 30%, ${colors[0]}${Math.floor(opacityMultiplier * 40).toString(16).padStart(2, '0')} 0%, transparent 50%),
            radial-gradient(ellipse at 80% 70%, ${colors[1]}${Math.floor(opacityMultiplier * 40).toString(16).padStart(2, '0')} 0%, transparent 50%),
            radial-gradient(ellipse at 50% 50%, ${colors[2]}${Math.floor(opacityMultiplier * 30).toString(16).padStart(2, '0')} 0%, transparent 60%)
          `,
          animation: `gradientShift ${20 / speedMultiplier}s ease-in-out infinite alternate`,
        }}
      />
    );
  }

  if (variant === 'mesh') {
    return (
      <div
        className={cn(baseClasses, className)}
        style={{
          background: `
            radial-gradient(at 40% 20%, ${colors[0]}${Math.floor(opacityMultiplier * 50).toString(16).padStart(2, '0')} 0px, transparent 50%),
            radial-gradient(at 80% 0%, ${colors[1]}${Math.floor(opacityMultiplier * 50).toString(16).padStart(2, '0')} 0px, transparent 50%),
            radial-gradient(at 0% 50%, ${colors[2]}${Math.floor(opacityMultiplier * 40).toString(16).padStart(2, '0')} 0px, transparent 50%),
            radial-gradient(at 80% 50%, ${colors[0]}${Math.floor(opacityMultiplier * 30).toString(16).padStart(2, '0')} 0px, transparent 50%),
            radial-gradient(at 40% 100%, ${colors[1]}${Math.floor(opacityMultiplier * 40).toString(16).padStart(2, '0')} 0px, transparent 50%)
          `,
          filter: 'blur(60px)',
          animation: `meshShift ${15 / speedMultiplier}s ease-in-out infinite alternate`,
        }}
      />
    );
  }

  if (variant === 'waves') {
    return (
      <div className={cn(baseClasses, className)}>
        <svg
          className="absolute bottom-0 left-0 w-full"
          viewBox="0 0 1440 320"
          preserveAspectRatio="none"
          style={{ height: '40%' }}
        >
          <defs>
            <linearGradient id="wave1" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={colors[0]} stopOpacity={opacityMultiplier * 0.5} />
              <stop offset="100%" stopColor={colors[1]} stopOpacity={opacityMultiplier * 0.3} />
            </linearGradient>
            <linearGradient id="wave2" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={colors[1]} stopOpacity={opacityMultiplier * 0.4} />
              <stop offset="100%" stopColor={colors[2]} stopOpacity={opacityMultiplier * 0.2} />
            </linearGradient>
          </defs>
          <path
            fill="url(#wave1)"
            d="M0,160L48,176C96,192,192,224,288,213.3C384,203,480,149,576,138.7C672,128,768,160,864,181.3C960,203,1056,213,1152,197.3C1248,181,1344,139,1392,117.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
            style={{
              animation: `wave ${8 / speedMultiplier}s ease-in-out infinite alternate`,
            }}
          />
          <path
            fill="url(#wave2)"
            d="M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,224C672,245,768,267,864,250.7C960,235,1056,181,1152,160C1248,139,1344,149,1392,154.7L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
            style={{
              animation: `wave ${10 / speedMultiplier}s ease-in-out infinite alternate-reverse`,
            }}
          />
        </svg>
      </div>
    );
  }

  return null;
}

// CSS keyframes for animations
export const animatedBackgroundStyles = `
@keyframes gradientShift {
  0% {
    transform: translate(0, 0) scale(1);
  }
  100% {
    transform: translate(2%, 2%) scale(1.05);
  }
}

@keyframes meshShift {
  0% {
    transform: translate(0, 0) rotate(0deg);
  }
  100% {
    transform: translate(-2%, -2%) rotate(2deg);
  }
}

@keyframes wave {
  0% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(-5%);
  }
}
`;

// Component to inject the styles
export function AnimatedBackgroundStyles() {
  return <style>{animatedBackgroundStyles}</style>;
}
