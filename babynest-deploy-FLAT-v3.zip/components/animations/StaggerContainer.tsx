'use client';

import { motion } from 'framer-motion';
import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface StaggerContainerProps {
  children: ReactNode;
  className?: string;
  staggerDelay?: number;
  delayChildren?: number;
  once?: boolean;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: (custom: { staggerDelay: number; delayChildren: number }) => ({
    opacity: 1,
    transition: {
      staggerChildren: custom.staggerDelay,
      delayChildren: custom.delayChildren,
    },
  }),
};

export function StaggerContainer({
  children,
  className,
  staggerDelay = 0.1,
  delayChildren = 0,
  once = true,
}: StaggerContainerProps) {
  return (
    <motion.div
      className={cn(className)}
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once, margin: '-50px' }}
      custom={{ staggerDelay, delayChildren }}
    >
      {children}
    </motion.div>
  );
}

interface StaggerItemProps {
  children: ReactNode;
  className?: string;
  direction?: 'up' | 'down' | 'left' | 'right' | 'fade' | 'scale';
  distance?: number;
  duration?: number;
  delay?: number;
}

const itemVariants = {
  hidden: (custom: { direction: string; distance: number }) => {
    const base = { opacity: 0 };
    switch (custom.direction) {
      case 'up':
        return { ...base, y: custom.distance };
      case 'down':
        return { ...base, y: -custom.distance };
      case 'left':
        return { ...base, x: custom.distance };
      case 'right':
        return { ...base, x: -custom.distance };
      case 'scale':
        return { ...base, scale: 0.9 };
      default:
        return base;
    }
  },
  visible: (custom: { duration: number; delay?: number }) => ({
    opacity: 1,
    y: 0,
    x: 0,
    scale: 1,
    transition: {
      duration: custom.duration,
      delay: custom.delay,
      ease: [0.16, 1, 0.3, 1] as const,
    },
  }),
};

export function StaggerItem({
  children,
  className,
  direction = 'up',
  distance = 30,
  duration = 0.5,
  delay = 0,
}: StaggerItemProps) {
  return (
    <motion.div
      className={cn(className)}
      variants={itemVariants}
      custom={{ direction, distance, duration, delay }}
    >
      {children}
    </motion.div>
  );
}

// Pre-configured stagger items for common use cases
export function FadeInItem({ children, className, duration = 0.5 }: Omit<StaggerItemProps, 'direction' | 'distance'>) {
  return (
    <StaggerItem direction="fade" duration={duration} className={className}>
      {children}
    </StaggerItem>
  );
}

export function SlideUpItem({ children, className, distance = 30, duration = 0.5 }: Omit<StaggerItemProps, 'direction'>) {
  return (
    <StaggerItem direction="up" distance={distance} duration={duration} className={className}>
      {children}
    </StaggerItem>
  );
}

export function SlideLeftItem({ children, className, distance = 30, duration = 0.5 }: Omit<StaggerItemProps, 'direction'>) {
  return (
    <StaggerItem direction="left" distance={distance} duration={duration} className={className}>
      {children}
    </StaggerItem>
  );
}

export function ScaleInItem({ children, className, duration = 0.5 }: Omit<StaggerItemProps, 'direction' | 'distance'>) {
  return (
    <StaggerItem direction="scale" duration={duration} className={className}>
      {children}
    </StaggerItem>
  );
}

// Card grid with stagger animation
interface StaggerGridProps {
  children: ReactNode[];
  className?: string;
  itemClassName?: string;
  columns?: 1 | 2 | 3 | 4;
  staggerDelay?: number;
}

export function StaggerGrid({
  children,
  className,
  itemClassName,
  columns = 3,
  staggerDelay = 0.1,
}: StaggerGridProps) {
  const colClasses = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 md:grid-cols-2',
    3: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4',
  };

  return (
    <StaggerContainer className={cn('grid gap-4', colClasses[columns], className)} staggerDelay={staggerDelay}>
      {children.map((child, index) => (
        <StaggerItem key={index} className={itemClassName}>
          {child}
        </StaggerItem>
      ))}
    </StaggerContainer>
  );
}
