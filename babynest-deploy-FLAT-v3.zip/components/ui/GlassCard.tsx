'use client';

import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
  intensity?: 'light' | 'medium' | 'heavy';
  border?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  shadow?: boolean;
  onClick?: () => void;
}

export function GlassCard({
  children,
  className,
  hover = true,
  glow = false,
  intensity = 'medium',
  border = true,
  padding = 'md',
  shadow = true,
  onClick,
}: GlassCardProps) {
  const intensityClasses = {
    light: 'bg-white/30 backdrop-blur-sm',
    medium: 'bg-white/50 backdrop-blur-md',
    heavy: 'bg-white/70 backdrop-blur-xl',
  };

  const paddingClasses = {
    none: 'p-0',
    sm: 'p-3',
    md: 'p-4',
    lg: 'p-6',
  };

  const borderClasses = border
    ? 'border border-white/40 dark:border-white/10'
    : '';

  const shadowClasses = shadow
    ? 'shadow-soft hover:shadow-soft-lg'
    : '';

  const glowClasses = glow
    ? 'hover:shadow-[0_0_30px_rgba(251,140,140,0.3)]'
    : '';

  const CardWrapper = hover ? motion.div : 'div';
  const hoverProps = hover
    ? {
        whileHover: { scale: 1.01, y: -2 },
        transition: { duration: 0.2, ease: 'easeOut' as const },
      }
    : {};

  return (
    <CardWrapper
      className={cn(
        'rounded-xl overflow-hidden',
        intensityClasses[intensity],
        paddingClasses[padding],
        borderClasses,
        shadowClasses,
        glowClasses,
        onClick && 'cursor-pointer',
        className
      )}
      onClick={onClick}
      {...hoverProps}
    >
      {children}
    </CardWrapper>
  );
}

// Colored glass card variant
interface ColoredGlassCardProps extends GlassCardProps {
  color?: 'primary' | 'accent' | 'emerald' | 'amber' | 'rose' | 'blue' | 'purple' | 'indigo';
  gradient?: boolean;
}

export function ColoredGlassCard({
  children,
  className,
  color = 'primary',
  gradient = false,
  intensity = 'medium',
  ...props
}: ColoredGlassCardProps) {
  const colorClasses = {
    primary: {
      bg: 'bg-primary-500/10',
      border: 'border-primary-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(251,140,140,0.2)]',
    },
    accent: {
      bg: 'bg-accent-500/10',
      border: 'border-accent-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(160,217,233,0.2)]',
    },
    emerald: {
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(34,197,94,0.2)]',
    },
    amber: {
      bg: 'bg-amber-500/10',
      border: 'border-amber-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(245,158,11,0.2)]',
    },
    rose: {
      bg: 'bg-rose-500/10',
      border: 'border-rose-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(244,63,94,0.2)]',
    },
    blue: {
      bg: 'bg-blue-500/10',
      border: 'border-blue-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(59,130,246,0.2)]',
    },
    purple: {
      bg: 'bg-purple-500/10',
      border: 'border-purple-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(168,85,247,0.2)]',
    },
    indigo: {
      bg: 'bg-indigo-500/10',
      border: 'border-indigo-200/50',
      glow: 'hover:shadow-[0_0_30px_rgba(99,102,241,0.2)]',
    },
  };

  const gradientClasses = gradient
    ? {
        primary: 'bg-gradient-to-br from-primary-500/20 to-primary-600/5',
        accent: 'bg-gradient-to-br from-accent-500/20 to-accent-600/5',
        emerald: 'bg-gradient-to-br from-emerald-500/20 to-emerald-600/5',
        amber: 'bg-gradient-to-br from-amber-500/20 to-amber-600/5',
        rose: 'bg-gradient-to-br from-rose-500/20 to-rose-600/5',
        blue: 'bg-gradient-to-br from-blue-500/20 to-blue-600/5',
        purple: 'bg-gradient-to-br from-purple-500/20 to-purple-600/5',
        indigo: 'bg-gradient-to-br from-indigo-500/20 to-indigo-600/5',
      }
    : colorClasses;

  const bgClass = gradient
    ? (gradientClasses as Record<string, string>)[color]
    : colorClasses[color].bg;

  return (
    <GlassCard
      className={cn(
        bgClass,
        colorClasses[color].border,
        colorClasses[color].glow,
        className
      )}
      intensity={intensity}
      {...props}
    >
      {children}
    </GlassCard>
  );
}

// Glass card with icon header
interface GlassCardWithIconProps extends GlassCardProps {
  icon: React.ComponentType<{ className?: string }>;
  iconClassName?: string;
  title?: string;
  subtitle?: string;
  color?: 'primary' | 'accent' | 'emerald' | 'amber' | 'rose' | 'blue' | 'purple' | 'indigo';
}

export function GlassCardWithIcon({
  children,
  icon: Icon,
  iconClassName,
  title,
  subtitle,
  color = 'primary',
  className,
  ...props
}: GlassCardWithIconProps) {
  const colorClasses = {
    primary: 'bg-primary-100 text-primary-600',
    accent: 'bg-accent-100 text-accent-600',
    emerald: 'bg-emerald-100 text-emerald-600',
    amber: 'bg-amber-100 text-amber-600',
    rose: 'bg-rose-100 text-rose-600',
    blue: 'bg-blue-100 text-blue-600',
    purple: 'bg-purple-100 text-purple-600',
    indigo: 'bg-indigo-100 text-indigo-600',
  };

  return (
    <ColoredGlassCard color={color} className={className} {...props}>
      <div className="flex items-start gap-4">
        <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center shrink-0', colorClasses[color])}>
          <Icon className={cn('w-6 h-6', iconClassName)} />
        </div>
        <div className="flex-1 min-w-0">
          {title && <h3 className="font-semibold text-warm-900">{title}</h3>}
          {subtitle && <p className="text-sm text-warm-600">{subtitle}</p>}
          {children && <div className="mt-3">{children}</div>}
        </div>
      </div>
    </ColoredGlassCard>
  );
}
