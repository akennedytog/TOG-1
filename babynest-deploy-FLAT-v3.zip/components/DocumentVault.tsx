'use client';

import { useState, useCallback, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  Upload, 
  Search, 
  Folder, 
  Share2, 
  Download, 
  Trash2, 
  Star,
  MoreVertical,
  Eye,
  Clock,
  Shield,
  Image,
  File,
  X,
  Loader2,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { getSupabase } from '@/lib/supabase';
import { toast } from 'sonner';

const folders = [
  { id: 'all', name: 'All Documents', icon: FileText },
  { id: 'insurance', name: 'Insurance', icon: Shield },
  { id: 'medical', name: 'Medical Records', icon: FileText },
  { id: 'legal', name: 'Legal', icon: FileText },
  { id: 'personal', name: 'Personal', icon: Folder },
  { id: 'receipts', name: 'Receipts', icon: FileText },
];

const documentTypes = [
  { id: 'insurance_card', name: 'Insurance Card', color: 'bg-emerald-100 text-emerald-700' },
  { id: 'birth_certificate', name: 'Birth Certificate', color: 'bg-blue-100 text-blue-700' },
  { id: 'ssn_card', name: 'SSN Card', color: 'bg-amber-100 text-amber-700' },
  { id: 'medical_record', name: 'Medical Record', color: 'bg-rose-100 text-rose-700' },
  { id: 'will', name: 'Will/Trust', color: 'bg-purple-100 text-purple-700' },
  { id: 'receipt', name: 'Receipt', color: 'bg-cyan-100 text-cyan-700' },
  { id: 'other', name: 'Other', color: 'bg-warm-100 text-warm-700' },
];

interface Document {
  id: string;
  name: string;
  type: string;
  folder: string;
  size: number;
  uploadedAt: string;
  tags: string[];
  isFavorite: boolean;
  expirationDate?: string;
  shared?: boolean;
  thumbnail?: string;
  storagePath?: string;
  url?: string;
  userId?: string;
}

interface ShareLink {
  url: string;
  expiresAt: string;
}

export function DocumentVault() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  
  const [activeFolder, setActiveFolder] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [showUpload, setShowUpload] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareLink, setShareLink] = useState<ShareLink | null>(null);
  const [isCreatingShare, setIsCreatingShare] = useState(false);

  // Fetch user and documents on mount
  useEffect(() => {
    const fetchUserAndDocuments = async () => {
      const supabase = getSupabase();
      
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setIsLoading(false);
        return;
      }
      
      setUserId(user.id);
      
      // Fetch documents from database
      const { data: docs, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', user.id)
        .order('uploaded_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching documents:', error);
        toast.error('Failed to load documents');
      } else if (docs) {
        // Transform database records to Document interface
        const transformedDocs: Document[] = docs.map((doc: any) => ({
          id: doc.id,
          name: doc.name,
          type: doc.type || 'other',
          folder: doc.folder || 'personal',
          size: doc.size || 0,
          uploadedAt: doc.uploaded_at || doc.created_at,
          tags: doc.tags || [],
          isFavorite: doc.is_favorite || false,
          expirationDate: doc.expiration_date,
          shared: doc.shared || false,
          thumbnail: doc.thumbnail,
          storagePath: doc.storage_path,
          url: doc.url,
          userId: doc.user_id,
        }));
        setDocuments(transformedDocs);
      }
      
      setIsLoading(false);
    };
    
    fetchUserAndDocuments();
  }, []);

  // Upload file to Supabase Storage
  const uploadFile = async (file: File, docType: string = 'other', folder: string = 'personal') => {
    if (!userId) {
      toast.error('Please sign in to upload documents');
      return null;
    }
    
    const supabase = getSupabase();
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
    const storagePath = `${userId}/${folder}/${fileName}`;
    
    try {
      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(storagePath, file, {
          cacheControl: '3600',
          upsert: false,
        });
      
      if (uploadError) {
        throw uploadError;
      }
      
      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('documents')
        .getPublicUrl(storagePath);
      
      // Create document record in database
      const { data: doc, error: dbError } = await supabase
        .from('documents')
        .insert({
          user_id: userId,
          name: file.name,
          type: docType,
          folder: folder,
          size: file.size,
          storage_path: storagePath,
          url: publicUrl,
          tags: [],
          is_favorite: false,
          uploaded_at: new Date().toISOString(),
        })
        .select()
        .single();
      
      if (dbError) {
        // Rollback storage upload if DB insert fails
        await supabase.storage.from('documents').remove([storagePath]);
        throw dbError;
      }
      
      return {
        id: doc.id,
        name: doc.name,
        type: doc.type,
        folder: doc.folder,
        size: doc.size,
        uploadedAt: doc.uploaded_at,
        tags: doc.tags || [],
        isFavorite: doc.is_favorite || false,
        storagePath: doc.storage_path,
        url: doc.url,
        userId: doc.user_id,
      } as Document;
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload document');
      return null;
    }
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!userId) {
      toast.error('Please sign in to upload documents');
      return;
    }
    
    setIsUploading(true);
    
    for (const file of acceptedFiles) {
      // Detect document type based on filename
      let docType = 'other';
      const lowerName = file.name.toLowerCase();
      if (lowerName.includes('insurance')) docType = 'insurance_card';
      else if (lowerName.includes('birth')) docType = 'birth_certificate';
      else if (lowerName.includes('ssn') || lowerName.includes('social')) docType = 'ssn_card';
      else if (lowerName.includes('medical') || lowerName.includes('record')) docType = 'medical_record';
      else if (lowerName.includes('will') || lowerName.includes('trust')) docType = 'will';
      else if (lowerName.includes('receipt')) docType = 'receipt';
      
      const uploadedDoc = await uploadFile(file, docType, activeFolder === 'all' ? 'personal' : activeFolder);
      
      if (uploadedDoc) {
        setDocuments(prev => [uploadedDoc, ...prev]);
        toast.success(`Uploaded ${file.name}`);
      }
    }
    
    setIsUploading(false);
    setShowUpload(false);
  }, [userId, activeFolder]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  const filteredDocs = documents.filter(doc => {
    const matchesFolder = activeFolder === 'all' || doc.folder === activeFolder;
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doc.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFolder && matchesSearch;
  });

  const toggleFavorite = async (id: string) => {
    const doc = documents.find(d => d.id === id);
    if (!doc || !userId) return;
    
    const newFavoriteState = !doc.isFavorite;
    
    // Optimistic update
    setDocuments(docs => docs.map(d => 
      d.id === id ? { ...d, isFavorite: newFavoriteState } : d
    ));
    
    // Update in database
    const supabase = getSupabase();
    const { error } = await supabase
      .from('documents')
      .update({ is_favorite: newFavoriteState })
      .eq('id', id)
      .eq('user_id', userId);
    
    if (error) {
      // Revert on error
      setDocuments(docs => docs.map(d => 
        d.id === id ? { ...d, isFavorite: !newFavoriteState } : d
      ));
      toast.error('Failed to update favorite status');
    }
  };

  const deleteDoc = async (id: string) => {
    const doc = documents.find(d => d.id === id);
    if (!doc || !userId) return;
    
    // Optimistic update
    setDocuments(docs => docs.filter(d => d.id !== id));
    
    const supabase = getSupabase();
    
    // Delete from storage if path exists
    if (doc.storagePath) {
      const { error: storageError } = await supabase.storage
        .from('documents')
        .remove([doc.storagePath]);
      
      if (storageError) {
        console.error('Storage delete error:', storageError);
      }
    }
    
    // Delete from database
    const { error } = await supabase
      .from('documents')
      .delete()
      .eq('id', id)
      .eq('user_id', userId);
    
    if (error) {
      // Restore on error
      setDocuments(prev => [...prev, doc]);
      toast.error('Failed to delete document');
    } else {
      toast.success('Document deleted');
    }
  };

  const downloadDoc = async (doc: Document) => {
    if (!doc.url) {
      toast.error('Document URL not available');
      return;
    }
    
    try {
      const response = await fetch(doc.url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.name;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download document');
    }
  };

  const createShareLink = async (doc: Document) => {
    if (!userId || !doc.storagePath) return;
    
    setIsCreatingShare(true);
    
    const supabase = getSupabase();
    
    // Create a signed URL that expires in 7 days
    const { data, error } = await supabase.storage
      .from('documents')
      .createSignedUrl(doc.storagePath, 60 * 60 * 24 * 7); // 7 days
    
    if (error) {
      toast.error('Failed to create share link');
      setIsCreatingShare(false);
      return;
    }
    
    setShareLink({
      url: data.signedUrl,
      expiresAt: new Date(Date.now() + 60 * 60 * 24 * 7 * 1000).toISOString(),
    });
    
    // Update document as shared in DB
    await supabase
      .from('documents')
      .update({ shared: true })
      .eq('id', doc.id)
      .eq('user_id', userId);
    
    setIsCreatingShare(false);
  };

  const copyShareLink = () => {
    if (shareLink?.url) {
      navigator.clipboard.writeText(shareLink.url);
      toast.success('Link copied to clipboard');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getDocTypeLabel = (type: string) => {
    return documentTypes.find(t => t.id === type)?.name || 'Document';
  };

  const getDocTypeColor = (type: string) => {
    return documentTypes.find(t => t.id === type)?.color || 'bg-warm-100 text-warm-700';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
      </div>
    );
  }

  if (!userId) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-12 h-12 text-warm-400 mx-auto mb-4" />
        <p className="text-warm-600 mb-4">Please sign in to access your documents</p>
        <Button onClick={() => window.location.href = '/auth/signin'}>
          Sign In
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-warm-400" />
            <Input
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-full md:w-96"
            />
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}>
            {viewMode === 'grid' ? 'List' : 'Grid'}
          </Button>
          <Button onClick={() => setShowUpload(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Upload
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Sidebar - Folders */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Folders</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="space-y-1">
              {folders.map(folder => {
                const count = documents.filter(d => folder.id === 'all' || d.folder === folder.id).length;
                const Icon = folder.icon;
                return (
                  <button
                    key={folder.id}
                    onClick={() => setActiveFolder(folder.id)}
                    className={cn(
                      'w-full flex items-center justify-between px-4 py-3 text-left transition-colors',
                      activeFolder === folder.id 
                        ? 'bg-primary-50 text-primary-700 border-r-2 border-primary-500' 
                        : 'text-warm-600 hover:bg-warm-50'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5" />
                      <span>{folder.name}</span>
                    </div>
                    <span className="text-sm text-warm-400">{count}</span>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Documents Grid */}
        <div className="lg:col-span-3">
          {showUpload ? (
            <Card>
              <CardContent className="p-8">
                <div
                  {...getRootProps()}
                  className={cn(
                    'border-2 border-dashed rounded-xl p-12 text-center transition-colors cursor-pointer',
                    isDragActive 
                      ? 'border-primary-500 bg-primary-50' 
                      : 'border-warm-300 hover:border-primary-300'
                  )}
                >
                  <input {...getInputProps()} />
                  {isUploading ? (
                    <>
                      <Loader2 className="w-12 h-12 text-warm-400 mx-auto mb-4 animate-spin" />
                      <p className="text-lg font-medium text-warm-900 mb-2">Uploading...</p>
                    </>
                  ) : (
                    <>
                      <Upload className="w-12 h-12 text-warm-400 mx-auto mb-4" />
                      <p className="text-lg font-medium text-warm-900 mb-2">
                        {isDragActive ? 'Drop files here' : 'Drag & drop files here'}
                      </p>
                      <p className="text-sm text-warm-500 mb-4">or click to browse</p>
                    </>
                  )}
                  <Button 
                    variant="outline" 
                    onClick={() => setShowUpload(false)}
                    disabled={isUploading}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className={cn(
              'grid gap-4',
              viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'
            )}>
              {filteredDocs.map(doc => (
                <Card key={doc.id} className="group hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className={cn(
                        'w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0',
                        getDocTypeColor(doc.type)
                      )}
                      >
                        {doc.thumbnail ? (
                          <span className="text-2xl">{doc.thumbnail}</span>
                        ) : (
                          <FileText className="w-6 h-6" />
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-warm-900 truncate">{doc.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="secondary" className="text-xs">
                            {getDocTypeLabel(doc.type)}
                          </Badge>
                          <span className="text-xs text-warm-400">{formatFileSize(doc.size)}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-2 text-xs text-warm-500">
                          <Clock className="w-3 h-3" />
                          {format(new Date(doc.uploadedAt), 'MMM d, yyyy')}
                        </div>
                        
                        {doc.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {doc.tags.map(tag => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {doc.expirationDate && (
                          <div className="flex items-center gap-1 mt-2 text-xs text-amber-600">
                            <Clock className="w-3 h-3" />
                            Expires {format(new Date(doc.expirationDate), 'MMM d, yyyy')}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => toggleFavorite(doc.id)}
                          className={cn(
                            'p-2 rounded-lg transition-colors',
                            doc.isFavorite ? 'text-amber-500' : 'text-warm-400 hover:text-amber-500'
                          )}
                        >
                          <Star className={cn('w-4 h-4', doc.isFavorite && 'fill-current')} />
                        </button>
                        
                        <button
                          onClick={() => downloadDoc(doc)}
                          className="p-2 text-warm-400 hover:text-primary-500 rounded-lg transition-colors"
                          title="Download"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        
                        <button
                          onClick={() => {
                            setSelectedDoc(doc);
                            setShareLink(null);
                            setShowShareModal(true);
                            createShareLink(doc);
                          }}
                          className="p-2 text-warm-400 hover:text-primary-500 rounded-lg transition-colors"
                          title="Share"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>
                        
                        <button
                          onClick={() => deleteDoc(doc.id)}
                          className="p-2 text-warm-400 hover:text-accent-500 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {filteredDocs.length === 0 && (
                <div className="col-span-full text-center py-12">
                  <FileText className="w-12 h-12 text-warm-300 mx-auto mb-4" />
                  <p className="text-warm-500">No documents found</p>
                  <Button variant="outline" className="mt-4" onClick={() => setShowUpload(true)}>
                    Upload your first document
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Share Modal */}
      {showShareModal && selectedDoc && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Share Document
                <button onClick={() => {
                  setShowShareModal(false);
                  setShareLink(null);
                  setSelectedDoc(null);
                }}>
                  <X className="w-5 h-5" />
                </button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-warm-600">
                Sharing: <span className="font-medium">{selectedDoc.name}</span>
              </p>
              
              {isCreatingShare ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-6 h-6 animate-spin text-primary-500" />
                </div>
              ) : shareLink ? (
                <>
                  <div className="p-4 bg-warm-50 rounded-lg">
                    <p className="text-sm text-warm-600 mb-2">Secure share link:</p>
                    <code className="text-xs bg-white p-2 rounded block break-all border">
                      {shareLink.url}
                    </code>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1" onClick={copyShareLink}>
                      Copy Link
                    </Button>
                  </div>
                  
                  <div className="text-sm text-warm-500 flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    Link expires {format(new Date(shareLink.expiresAt), 'MMM d, yyyy')}
                  </div>
                </>
              ) : (
                <p className="text-sm text-warm-500 text-center py-4">
                  Failed to create share link. Please try again.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
