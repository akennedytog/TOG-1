'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  MessageCircle,
  ThumbsUp,
  Clock,
  CheckCircle2,
  Search,
  Plus,
  ShieldCheck,
  TrendingUp,
  HelpCircle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import {
  QAQuestion,
  QAAnswer,
  QACategory,
  QA_CATEGORIES,
  SAMPLE_QUESTIONS,
} from '@/lib/community-data';

type SortMode = 'newest' | 'helpful' | 'unanswered';

export function CommunityQA() {
  const [questions, setQuestions] = useState<QAQuestion[]>(SAMPLE_QUESTIONS);
  const [activeCategory, setActiveCategory] = useState<QACategory | 'all'>('all');
  const [sortMode, setSortMode] = useState<SortMode>('helpful');
  const [search, setSearch] = useState('');
  const [showAskForm, setShowAskForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Track which questions/answers the current user has upvoted (session only)
  const [upvotedQs, setUpvotedQs] = useState<Set<string>>(new Set());
  const [upvotedAs, setUpvotedAs] = useState<Set<string>>(new Set());

  // Ask-a-question form state
  const [newTitle, setNewTitle] = useState('');
  const [newBody, setNewBody] = useState('');
  const [newCategory, setNewCategory] = useState<QACategory>('sleep');

  const filtered = useMemo(() => {
    let list = questions.slice();
    if (activeCategory !== 'all') {
      list = list.filter((q) => q.category === activeCategory);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.body.toLowerCase().includes(q) ||
          item.answers.some((a) => a.content.toLowerCase().includes(q))
      );
    }
    if (sortMode === 'newest') {
      list.sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } else if (sortMode === 'helpful') {
      list.sort((a, b) => {
        const aScore =
          a.upvotes + a.answers.reduce((s, ans) => s + ans.upvotes, 0);
        const bScore =
          b.upvotes + b.answers.reduce((s, ans) => s + ans.upvotes, 0);
        return bScore - aScore;
      });
    } else if (sortMode === 'unanswered') {
      list = list.filter((q) => q.answers.length === 0);
      list.sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    }
    return list;
  }, [questions, activeCategory, sortMode, search]);

  const toggleUpvoteQuestion = (id: string) => {
    setQuestions((prev) =>
      prev.map((q) =>
        q.id === id
          ? { ...q, upvotes: q.upvotes + (upvotedQs.has(id) ? -1 : 1) }
          : q
      )
    );
    setUpvotedQs((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleUpvoteAnswer = (questionId: string, answerId: string) => {
    setQuestions((prev) =>
      prev.map((q) => {
        if (q.id !== questionId) return q;
        return {
          ...q,
          answers: q.answers.map((a) =>
            a.id === answerId
              ? { ...a, upvotes: a.upvotes + (upvotedAs.has(answerId) ? -1 : 1) }
              : a
          ),
        };
      })
    );
    setUpvotedAs((prev) => {
      const next = new Set(prev);
      if (next.has(answerId)) next.delete(answerId);
      else next.add(answerId);
      return next;
    });
  };

  const submitQuestion = () => {
    if (!newTitle.trim()) return;
    const q: QAQuestion = {
      id: `q-${Date.now()}`,
      title: newTitle.trim(),
      body: newBody.trim(),
      category: newCategory,
      author: 'You',
      upvotes: 0,
      createdAt: new Date().toISOString(),
      answers: [],
    };
    setQuestions((prev) => [q, ...prev]);
    setNewTitle('');
    setNewBody('');
    setShowAskForm(false);
    setActiveCategory(newCategory);
    setSortMode('newest');
  };

  const categoryMeta = (id: QACategory) =>
    QA_CATEGORIES.find((c) => c.id === id);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary-500 to-primary-700 text-white rounded-2xl p-6 md:p-8 shadow-soft">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
              <span className="text-3xl">👶</span> Community Q&amp;A
            </h1>
            <p className="text-primary-50 mt-2 max-w-xl">
              Real questions from real parents. Answered by other parents and
              expert-verified professionals.
            </p>
          </div>
          <Button
            onClick={() => setShowAskForm((v) => !v)}
            className="bg-white text-primary-700 hover:bg-cream-100"
          >
            <Plus className="w-4 h-4 mr-2" />
            Ask a Question
          </Button>
        </div>
      </div>

      {/* Ask form */}
      {showAskForm && (
        <Card className="border-primary-200 shadow-soft animate-slide-down">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-primary-600" />
              Ask the Community
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-warm-700 mb-1 block">
                Title
              </label>
              <Input
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="What's your question?"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-warm-700 mb-1 block">
                Details (optional)
              </label>
              <Textarea
                value={newBody}
                onChange={(e) => setNewBody(e.target.value)}
                placeholder="Add any helpful context..."
                rows={3}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-warm-700 mb-2 block">
                Category
              </label>
              <div className="flex flex-wrap gap-2">
                {QA_CATEGORIES.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setNewCategory(c.id)}
                    className={cn(
                      'px-3 py-1.5 rounded-full text-sm border transition',
                      newCategory === c.id
                        ? 'bg-primary-600 text-white border-primary-600'
                        : 'bg-white text-warm-700 border-warm-300 hover:border-primary-400'
                    )}
                  >
                    <span className="mr-1">{c.emoji}</span>
                    {c.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                variant="ghost"
                onClick={() => setShowAskForm(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={submitQuestion}
                disabled={!newTitle.trim()}
                className="bg-primary-600 hover:bg-primary-700"
              >
                Post Question
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters bar */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-warm-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search questions, answers, topics..."
            className="pl-9"
          />
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveCategory('all')}
            className={cn(
              'px-3 py-1.5 rounded-full text-sm border transition',
              activeCategory === 'all'
                ? 'bg-primary-600 text-white border-primary-600'
                : 'bg-white text-warm-700 border-warm-300 hover:border-primary-400'
            )}
          >
            All Topics
          </button>
          {QA_CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCategory(c.id)}
              className={cn(
                'px-3 py-1.5 rounded-full text-sm border transition flex items-center gap-1',
                activeCategory === c.id
                  ? 'bg-primary-600 text-white border-primary-600'
                  : 'bg-white text-warm-700 border-warm-300 hover:border-primary-400'
              )}
            >
              <span>{c.emoji}</span> {c.name}
            </button>
          ))}
        </div>

        {/* Sort */}
        <div className="flex flex-wrap items-center gap-2 text-sm">
          <span className="text-warm-600">Sort:</span>
          {(
            [
              { id: 'helpful', label: 'Most Helpful', icon: TrendingUp },
              { id: 'newest', label: 'Newest', icon: Clock },
              { id: 'unanswered', label: 'Unanswered', icon: HelpCircle },
            ] as { id: SortMode; label: string; icon: typeof Clock }[]
          ).map((s) => (
            <button
              key={s.id}
              onClick={() => setSortMode(s.id)}
              className={cn(
                'px-3 py-1 rounded-full border text-sm flex items-center gap-1 transition',
                sortMode === s.id
                  ? 'bg-accent-100 text-accent-700 border-accent-300'
                  : 'bg-white text-warm-600 border-warm-200 hover:border-accent-300'
              )}
            >
              <s.icon className="w-3.5 h-3.5" />
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Question list */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="text-center py-12 text-warm-500">
              No questions match your filters yet.
              <div className="mt-3">
                <Button
                  onClick={() => setShowAskForm(true)}
                  className="bg-primary-600 hover:bg-primary-700"
                >
                  Be the first to ask
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          filtered.map((q) => {
            const expanded = expandedId === q.id;
            const meta = categoryMeta(q.category);
            const topAnswer = [...q.answers].sort(
              (a, b) => b.upvotes - a.upvotes
            )[0];
            return (
              <Card
                key={q.id}
                className="hover:shadow-soft-lg transition-shadow border-warm-200"
              >
                <CardContent className="p-5">
                  <div className="flex gap-3">
                    {/* Vote column */}
                    <div className="flex flex-col items-center pt-1 min-w-[44px]">
                      <button
                        onClick={() => toggleUpvoteQuestion(q.id)}
                        className={cn(
                          'w-9 h-9 rounded-full flex items-center justify-center border transition',
                          upvotedQs.has(q.id)
                            ? 'bg-primary-600 text-white border-primary-600'
                            : 'bg-white text-warm-600 border-warm-300 hover:border-primary-400'
                        )}
                        aria-label="Upvote question"
                      >
                        <ThumbsUp className="w-4 h-4" />
                      </button>
                      <span className="text-sm font-semibold text-warm-700 mt-1">
                        {q.upvotes}
                      </span>
                    </div>

                    {/* Body */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        {meta && (
                          <Badge
                            variant="outline"
                            className="text-xs border-primary-300 text-primary-700 bg-primary-50"
                          >
                            <span className="mr-1">{meta.emoji}</span>
                            {meta.name}
                          </Badge>
                        )}
                        {q.answers.some((a) => a.isExpert) && (
                          <Badge className="text-xs bg-accent-100 text-accent-800 border-accent-300 hover:bg-accent-100">
                            <ShieldCheck className="w-3 h-3 mr-1" />
                            Expert Verified
                          </Badge>
                        )}
                        {q.answers.length === 0 && (
                          <Badge
                            variant="outline"
                            className="text-xs border-warm-300 text-warm-600"
                          >
                            Unanswered
                          </Badge>
                        )}
                      </div>

                      <button
                        onClick={() =>
                          setExpandedId(expanded ? null : q.id)
                        }
                        className="text-left w-full"
                      >
                        <h3 className="text-lg font-semibold text-warm-900 hover:text-primary-700 transition">
                          {q.title}
                        </h3>
                      </button>

                      {q.body && (
                        <p className="text-sm text-warm-600 mt-1 line-clamp-2">
                          {q.body}
                        </p>
                      )}

                      <div className="flex items-center gap-3 text-xs text-warm-500 mt-2 flex-wrap">
                        <span>by {q.author}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatDistanceToNow(new Date(q.createdAt), {
                            addSuffix: true,
                          })}
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <MessageCircle className="w-3 h-3" />
                          {q.answers.length}{' '}
                          {q.answers.length === 1 ? 'answer' : 'answers'}
                        </span>
                      </div>

                      {/* Preview of top answer when collapsed */}
                      {!expanded && topAnswer && (
                        <div className="mt-3 p-3 bg-cream-100 rounded-lg border border-cream-200">
                          <div className="flex items-center gap-2 mb-1 text-xs">
                            <span className="font-medium text-warm-800">
                              {topAnswer.author}
                            </span>
                            {topAnswer.isExpert && (
                              <Badge className="text-[10px] py-0 px-1.5 bg-accent-100 text-accent-800 border-accent-300 hover:bg-accent-100">
                                <ShieldCheck className="w-2.5 h-2.5 mr-0.5" />
                                Verified
                              </Badge>
                            )}
                            {topAnswer.authorRole && (
                              <span className="text-warm-500">
                                · {topAnswer.authorRole}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-warm-700 line-clamp-2">
                            {topAnswer.content}
                          </p>
                          <button
                            onClick={() => setExpandedId(q.id)}
                            className="text-xs text-primary-700 hover:text-primary-800 font-medium mt-1"
                          >
                            Read full answer →
                          </button>
                        </div>
                      )}

                      {/* Expanded: all answers */}
                      {expanded && (
                        <div className="mt-4 space-y-3">
                          {q.answers.length === 0 ? (
                            <div className="p-4 bg-cream-100 rounded-lg text-sm text-warm-600 text-center border border-cream-200">
                              No answers yet — be the first to help!
                            </div>
                          ) : (
                            [...q.answers]
                              .sort((a, b) => b.upvotes - a.upvotes)
                              .map((a) => (
                                <AnswerCard
                                  key={a.id}
                                  answer={a}
                                  upvoted={upvotedAs.has(a.id)}
                                  onUpvote={() =>
                                    toggleUpvoteAnswer(q.id, a.id)
                                  }
                                />
                              ))
                          )}
                          <button
                            onClick={() => setExpandedId(null)}
                            className="text-xs text-warm-500 hover:text-warm-700"
                          >
                            Collapse
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}

function AnswerCard({
  answer,
  upvoted,
  onUpvote,
}: {
  answer: QAAnswer;
  upvoted: boolean;
  onUpvote: () => void;
}) {
  return (
    <div
      className={cn(
        'p-4 rounded-lg border',
        answer.isExpert
          ? 'bg-accent-50 border-accent-200'
          : 'bg-cream-50 border-warm-200'
      )}
    >
      <div className="flex items-start gap-3">
        <button
          onClick={onUpvote}
          className={cn(
            'flex flex-col items-center gap-0.5 px-2 py-1 rounded-md border transition',
            upvoted
              ? 'bg-primary-600 text-white border-primary-600'
              : 'bg-white text-warm-600 border-warm-300 hover:border-primary-400'
          )}
          aria-label="Upvote answer"
        >
          <ThumbsUp className="w-3.5 h-3.5" />
          <span className="text-xs font-semibold">{answer.upvotes}</span>
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1 text-sm">
            <span className="font-semibold text-warm-900">{answer.author}</span>
            {answer.isExpert && (
              <Badge className="text-xs bg-accent-200 text-accent-800 border-accent-300 hover:bg-accent-200">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Expert Verified
              </Badge>
            )}
            {answer.authorRole && (
              <span className="text-xs text-warm-600">
                · {answer.authorRole}
              </span>
            )}
          </div>
          <p className="text-sm text-warm-800 whitespace-pre-line">
            {answer.content}
          </p>
          <div className="text-xs text-warm-500 mt-2">
            {formatDistanceToNow(new Date(answer.createdAt), {
              addSuffix: true,
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
