import Link from 'next/link';
import { Baby, Heart } from 'lucide-react';
import { ScrollReveal } from '@/components/animations/ScrollReveal';

export function LandingFooter() {
  return (
    <footer className="bg-warm-900 text-warm-300 py-16">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center">
                  <Baby className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold text-white">BabyNest</span>
              </div>
              <p className="text-warm-400 max-w-sm leading-relaxed">
                Your warm, AI-powered companion for navigating parenthood&apos;s financial journey.
                Trusted by 500+ families.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2">
                <li><Link href="/#features" className="hover:text-white transition-colors">Features</Link></li>
                <li><Link href="/#pricing" className="hover:text-white transition-colors">Pricing</Link></li>
                <li><Link href="/auth/signin" className="hover:text-white transition-colors">Security</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2">
                <li><Link href="/blog" className="hover:text-white transition-colors">About</Link></li>
                <li><Link href="/community" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link href="/auth/signup" className="hover:text-white transition-colors">Privacy</Link></li>
                <li><Link href="/pricing" className="hover:text-white transition-colors">Terms</Link></li>
              </ul>
            </div>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={100}>
          <div className="pt-8 border-t border-warm-800 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm">
              © 2026 BabyNest. Made with <Heart className="w-4 h-4 inline text-primary-400" /> for new parents.
            </div>
            <div className="flex gap-4">
              <a href="#" className="text-warm-400 hover:text-white transition-colors">Twitter</a>
              <a href="#" className="text-warm-400 hover:text-white transition-colors">Instagram</a>
              <a href="#" className="text-warm-400 hover:text-white transition-colors">LinkedIn</a>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </footer>
  );
}
