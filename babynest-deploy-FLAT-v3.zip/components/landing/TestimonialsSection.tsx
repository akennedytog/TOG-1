import { Quote, Star } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { ScrollReveal } from '@/components/animations/ScrollReveal';

const testimonials = [
  {
    quote:
      "BabyNest saved us $3,000 in tax credits we didn't even know existed. The timeline feature kept us on track during those sleep-deprived early weeks!",
    author: 'Sarah M.',
    role: 'Mom of twins, California',
    rating: 5,
  },
  {
    quote:
      'As a first-time dad, I was overwhelmed by all the financial decisions. BabyNest made everything feel manageable and even enjoyable.',
    author: 'Brian Reedy',
    role: 'First-time dad, Florida',
    rating: 5,
  },
  {
    quote:
      'The 529 plan comparison alone was worth it. We found a much better option for our state that will save us thousands over the years.',
    author: 'Emily R.',
    role: 'Mom of two, New York',
    rating: 5,
  },
];

export function TestimonialsSection() {
  return (
    <section id="testimonials" className="section-padding">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-warm-100 text-warm-700 rounded-full text-sm font-semibold mb-4">
              <Star className="w-3 h-3" />
              Testimonials
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-warm-900 mb-4">Loved by New Parents</h2>
            <p className="text-lg text-warm-600">See what families are saying about BabyNest</p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <ScrollReveal key={testimonial.author} delay={index * 100}>
              <GlassCard className="h-full" padding="lg" intensity="heavy">
                <Quote className="w-8 h-8 text-primary-300 mb-4" />
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-warm-400 text-warm-400" />
                  ))}
                </div>
                <p className="text-warm-700 mb-6 leading-relaxed">&quot;{testimonial.quote}&quot;</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-primary-500 flex items-center justify-center text-white font-semibold">
                    {testimonial.author[0]}
                  </div>
                  <div>
                    <div className="font-semibold text-warm-900">{testimonial.author}</div>
                    <div className="text-sm text-warm-500">{testimonial.role}</div>
                  </div>
                </div>
              </GlassCard>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
