import { CheckCircle2, Clock, Heart, Shield, GraduationCap, Calculator, FileText, Sparkles, Users, Wallet } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { ScrollReveal } from '@/components/animations/ScrollReveal';

const trustStats = [
  { label: 'Parents Helped', value: '500+', icon: Users },
  { label: 'Tasks Completed', value: '2,400+', icon: CheckCircle2 },
  { label: 'Money Saved', value: '$1.2M+', icon: Wallet },
  { label: 'States Covered', value: '50', icon: Heart },
];

const features = [
  {
    icon: Clock,
    title: 'Smart Timeline',
    description:
      'Never miss a deadline. We track time-sensitive tasks like insurance enrollment windows and 529 contribution deadlines.',
    accent: 'bg-primary-100 text-primary-600',
  },
  {
    icon: Shield,
    title: 'Insurance Decoder',
    description:
      'Upload your insurance card and our AI explains your coverage. Know exactly what is covered and what you need to do.',
    accent: 'bg-warm-100 text-warm-700',
  },
  {
    icon: GraduationCap,
    title: '529 Plan Guide',
    description:
      'State-specific 529 recommendations. Compare plans, understand tax benefits, and optimize your contributions.',
    accent: 'bg-primary-50 text-primary-700',
  },
  {
    icon: Calculator,
    title: 'Tax Optimization',
    description:
      'Maximize child tax credits, dependent care benefits, and state-specific deductions. Keep more of your money.',
    accent: 'bg-warm-50 text-warm-700',
  },
  {
    icon: FileText,
    title: 'Legal Checklist',
    description:
      'Wills, guardianship, and trusts simplified. State-specific requirements and document templates included.',
    accent: 'bg-primary-100 text-primary-700',
  },
  {
    icon: Heart,
    title: 'AI Assistant',
    description:
      'Ask anything about baby finances. Our AI knows the rules for your state and gives personalized guidance.',
    accent: 'bg-warm-100 text-primary-600',
  },
];

const steps = [
  {
    step: '01',
    title: 'Share Your Story',
    description:
      'Tell us your state, due date, and what matters most to your family. We personalize everything to your unique situation.',
    icon: Heart,
  },
  {
    step: '02',
    title: 'Get Your Timeline',
    description:
      'See exactly what you need to do and when. Tasks are prioritized by urgency and financial impact on your family.',
    icon: Clock,
  },
  {
    step: '03',
    title: 'Navigate with Confidence',
    description:
      'Follow step-by-step guides, use our AI assistant for questions, and track your progress as you go.',
    icon: Sparkles,
  },
];

export function FeaturesSection() {
  return (
    <>
      <section className="py-12 border-y border-warm-100 bg-white/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {trustStats.map((stat, index) => (
              <ScrollReveal key={stat.label} delay={index * 75}>
                <div className="text-center group">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-primary-100 text-primary-600 mb-3 group-hover:scale-110 transition-transform">
                    <stat.icon className="w-6 h-6" />
                  </div>
                  <div className="text-3xl font-bold text-warm-900">{stat.value}</div>
                  <div className="text-warm-500 text-sm">{stat.label}</div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      <section id="features" className="section-padding">
        <div className="container mx-auto px-4">
          <ScrollReveal>
            <div className="text-center mb-16">
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-semibold mb-4">
                <Heart className="w-3 h-3" />
                Features
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-warm-900 mb-4">
                Everything You Need for Peace of Mind
              </h2>
              <p className="text-lg text-warm-600 max-w-2xl mx-auto">
                From insurance deadlines to 529 plans, we guide you through every financial decision
                with warmth and clarity.
              </p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <ScrollReveal key={feature.title} delay={index * 75}>
                <GlassCard className="h-full" padding="lg" intensity="heavy">
                  <div className={`w-12 h-12 ${feature.accent} rounded-xl flex items-center justify-center mb-4`}>
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-warm-900 mb-2">{feature.title}</h3>
                  <p className="text-warm-600 text-sm leading-relaxed">{feature.description}</p>
                </GlassCard>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      <section id="how-it-works" className="section-padding bg-gradient-to-b from-cream-100 to-cream-50">
        <div className="container mx-auto px-4">
          <ScrollReveal>
            <div className="text-center mb-16">
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-warm-100 text-warm-700 rounded-full text-sm font-semibold mb-4">
                <Sparkles className="w-3 h-3" />
                Simple Process
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-warm-900 mb-4">How BabyNest Works</h2>
              <p className="text-lg text-warm-600">Three simple steps to financial peace of mind</p>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {steps.map((item, index) => (
              <ScrollReveal key={item.step} delay={index * 100}>
                <div className="relative text-center group h-full">
                  {index < 2 && (
                    <div className="hidden md:block absolute top-12 left-[60%] w-full h-0.5 bg-gradient-to-r from-primary-200 to-transparent" />
                  )}

                  <GlassCard className="h-full text-center" padding="lg" intensity="light">
                    <div className="inline-flex items-center justify-center w-24 h-24 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-600 text-white mb-6 shadow-glow group-hover:scale-105 transition-transform">
                      <item.icon className="w-10 h-10" />
                    </div>
                    <div className="text-5xl font-bold text-primary-200 mb-2">{item.step}</div>
                    <h3 className="text-xl font-bold text-warm-900 mb-3">{item.title}</h3>
                    <p className="text-warm-600 leading-relaxed">{item.description}</p>
                  </GlassCard>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
