import Link from 'next/link';
import { CheckCircle2, ChevronRight, Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { GlassCard } from '@/components/ui/GlassCard';
import { ScrollReveal } from '@/components/animations/ScrollReveal';

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    description: 'Basic timeline and general guidance',
    features: [
      'Generic task checklist',
      'Limited AI chat (5 questions/month)',
      'Basic 529 information',
      'Community access',
    ],
    cta: 'Get Started',
    variant: 'secondary' as const,
  },
  {
    name: 'Pro',
    price: '$9.99',
    period: '/month',
    description: 'Everything you need for new parent finances',
    features: [
      'State-specific task timeline',
      'Unlimited AI chat',
      'Insurance card scanner',
      'Document vault',
      '529 plan comparisons',
      'Tax optimization tips',
    ],
    cta: 'Start Free Trial',
    variant: 'primary' as const,
    popular: true,
  },
  {
    name: 'Family',
    price: '$14.99',
    period: '/month',
    description: 'For families with multiple children',
    features: [
      'Everything in Pro',
      'Multiple children profiles',
      'Grandparent gifting calculator',
      'Family sharing (5 members)',
      'Priority support',
    ],
    cta: 'Start Free Trial',
    variant: 'secondary' as const,
  },
];

export function PricingSection() {
  return (
    <section id="pricing" className="section-padding bg-gradient-to-b from-cream-50 to-white">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-semibold mb-4">
              <Wallet className="w-3 h-3" />
              Pricing
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-warm-900 mb-4">
              Simple, Parent-Friendly Pricing
            </h2>
            <p className="text-lg text-warm-600">Start free. Upgrade when you&apos;re ready.</p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <ScrollReveal key={plan.name} delay={index * 100}>
              <GlassCard
                className={`relative h-full ${plan.popular ? 'ring-2 ring-primary-500 md:scale-105' : ''}`}
                padding="lg"
                intensity={plan.popular ? 'heavy' : 'medium'}
                glow={plan.popular}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <span className="bg-gradient-to-r from-primary-500 to-primary-600 text-white px-4 py-1 rounded-full text-sm font-semibold shadow-soft">
                      Most Popular
                    </span>
                  </div>
                )}

                <h3 className="text-xl font-bold text-warm-900">{plan.name}</h3>
                <div className="mt-4 mb-2">
                  <span className="text-4xl font-bold text-warm-900">{plan.price}</span>
                  <span className="text-warm-500">{plan.period}</span>
                </div>
                <p className="text-warm-600 mb-6">{plan.description}</p>

                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2">
                      <CheckCircle2 className="w-5 h-5 text-primary-500 flex-shrink-0" />
                      <span className="text-warm-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link href={plan.name === 'Free' ? '/auth/signup' : '/pricing'} className="block mt-auto">
                  <Button variant={plan.variant} className="w-full" size="lg">
                    {plan.cta}
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
              </GlassCard>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
