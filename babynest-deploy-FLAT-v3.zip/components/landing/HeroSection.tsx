'use client';

import { useState } from 'react';
import Link from 'next/link';
import { AlertCircle, ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, states } from '@/components/ui/select';
import { GlassCard } from '@/components/ui/GlassCard';
import { ScrollReveal } from '@/components/animations/ScrollReveal';
import { joinWaitlist } from '@/lib/supabase';

export function HeroSection() {
  const [email, setEmail] = useState('');
  const [state, setState] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    setError('');

    try {
      await joinWaitlist({
        email,
        state: state || undefined,
        due_date: dueDate || undefined,
      });
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="pt-24 pb-20 relative overflow-hidden">
      <div className="absolute top-20 right-0 w-96 h-96 bg-gradient-to-br from-primary-200/40 to-primary-100/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-gradient-to-tr from-warm-200/40 to-primary-100/20 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          <ScrollReveal>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-100 text-primary-700 rounded-full text-sm font-semibold mb-8">
              <Sparkles className="w-4 h-4" />
              <span>Now in Beta — Join 500+ Happy Parents</span>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={75}>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-warm-900 mb-6 leading-tight">
              Navigate Parenthood&apos;s
              <br />
              <span className="text-gradient">Financial Journey</span>
            </h1>
          </ScrollReveal>

          <ScrollReveal delay={150}>
            <p className="text-lg sm:text-xl text-warm-600 mb-10 max-w-2xl mx-auto leading-relaxed">
              Your warm, AI-powered companion for new parent finances. We guide you through
              insurance, 529 plans, taxes, and legal tasks — so you can focus on cuddles and milestones.
            </p>
          </ScrollReveal>

          {!submitted ? (
            <ScrollReveal delay={225}>
              <form onSubmit={handleSubmit} className="max-w-md mx-auto">
                <GlassCard className="border-primary-100/60" padding="lg" intensity="heavy" glow>
                  <div className="space-y-4 text-left">
                    <div>
                      <label className="block text-sm font-semibold text-warm-700 mb-2">
                        Email Address
                      </label>
                      <Input
                        type="email"
                        placeholder="you@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="h-12"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-warm-700 mb-2">
                          Your State
                        </label>
                        <Select value={state} onValueChange={setState}>
                          <SelectTrigger className="h-12">
                            <SelectValue placeholder="Select state" />
                          </SelectTrigger>
                          <SelectContent>
                            {states.filter((s) => s.value).map((s) => (
                              <SelectItem key={s.value} value={s.value}>
                                {s.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-warm-700 mb-2">
                          Due Date
                        </label>
                        <Input
                          type="date"
                          value={dueDate}
                          onChange={(e) => setDueDate(e.target.value)}
                          className="h-12"
                        />
                      </div>
                    </div>

                    {error && (
                      <div className="flex items-center gap-2 text-primary-700 text-sm bg-primary-50 p-3 rounded-xl border border-primary-100">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {error}
                      </div>
                    )}

                    <Button type="submit" size="lg" className="w-full" isLoading={loading}>
                      Get Early Access Free
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>

                    <p className="text-xs text-warm-500 text-center">
                      No credit card required. Join 500+ parents on the waitlist.
                    </p>

                    <div className="text-center text-sm text-warm-500">
                      Already have an account?{' '}
                      <Link href="/auth/signin" className="text-primary-600 font-semibold hover:text-primary-700">
                        Sign in
                      </Link>
                    </div>
                  </div>
                </GlassCard>
              </form>
            </ScrollReveal>
          ) : (
            <ScrollReveal delay={225}>
              <GlassCard className="max-w-md mx-auto text-center border-primary-200" padding="lg" intensity="heavy" glow>
                <div className="w-16 h-16 bg-gradient-to-br from-primary-400 to-primary-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
                  <CheckCircle2 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-warm-900 mb-2">You&apos;re on the list!</h3>
                <p className="text-warm-600">
                  We&apos;ll email you when BabyNest is ready. Thanks for trusting us with your family&apos;s journey!
                </p>
              </GlassCard>
            </ScrollReveal>
          )}
        </div>
      </div>
    </section>
  );
}
