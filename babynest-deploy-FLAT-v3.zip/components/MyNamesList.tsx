'use client';

import { useCallback, useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Share2, Trash2, Copy, Check, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ALL_NAMES, BabyName } from '@/lib/baby-names-data';

const STORAGE_KEY = 'babynest:favorite-names';

// ---------- Hook: favorites ----------
export function useFavoriteNames() {
  const [favorites, setFavorites] = useState<string[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setFavorites(parsed.filter((x) => typeof x === 'string'));
      }
    } catch {
      // ignore
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded || typeof window === 'undefined') return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(favorites));
    } catch {
      // ignore
    }
  }, [favorites, loaded]);

  const isFavorite = useCallback(
    (name: string) => favorites.includes(name),
    [favorites]
  );

  const toggleFavorite = useCallback((name: string) => {
    setFavorites((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]
    );
  }, []);

  const removeFavorite = useCallback((name: string) => {
    setFavorites((prev) => prev.filter((n) => n !== name));
  }, []);

  const clearAll = useCallback(() => setFavorites([]), []);

  return {
    favorites,
    isFavorite,
    toggleFavorite,
    removeFavorite,
    clearAll,
    loaded,
  };
}

// ---------- Favorite button (small heart toggle) ----------
export function FavoriteButton({
  name,
  isFavorite,
  onToggle,
  size = 'md',
}: {
  name: string;
  isFavorite: boolean;
  onToggle: (name: string) => void;
  size?: 'sm' | 'md';
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onToggle(name);
      }}
      aria-label={isFavorite ? `Remove ${name} from favorites` : `Save ${name} to favorites`}
      className={cn(
        'rounded-full flex items-center justify-center transition border',
        size === 'sm' ? 'w-7 h-7' : 'w-9 h-9',
        isFavorite
          ? 'bg-accent-100 border-accent-300 text-accent-600 hover:bg-accent-200'
          : 'bg-white border-warm-300 text-warm-400 hover:text-accent-500 hover:border-accent-300'
      )}
    >
      <Heart
        className={cn(
          size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4',
          isFavorite && 'fill-current'
        )}
      />
    </button>
  );
}

// ---------- Encode/decode shareable list ----------
function encodeList(names: string[]): string {
  // Base64-encode JSON for shareable URL fragment
  if (typeof window === 'undefined') return '';
  try {
    const json = JSON.stringify(names);
    return window.btoa(unescape(encodeURIComponent(json)));
  } catch {
    return '';
  }
}

export function decodeList(encoded: string): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const json = decodeURIComponent(escape(window.atob(encoded)));
    const parsed = JSON.parse(json);
    if (Array.isArray(parsed)) {
      return parsed.filter((x) => typeof x === 'string');
    }
  } catch {
    // ignore
  }
  return [];
}

// ---------- MyNamesList modal/sidebar ----------
export function MyNamesList({
  open,
  onClose,
  favorites,
  onRemove,
  onClearAll,
}: {
  open: boolean;
  onClose: () => void;
  favorites: string[];
  onRemove: (name: string) => void;
  onClearAll: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const [shareUrl, setShareUrl] = useState('');

  useEffect(() => {
    if (!open || typeof window === 'undefined') return;
    const encoded = encodeList(favorites);
    const base = `${window.location.origin}${window.location.pathname}`;
    setShareUrl(encoded ? `${base}?names=${encoded}` : base);
    setCopied(false);
  }, [open, favorites]);

  // Resolve name details from the dataset
  const detailed: BabyName[] = favorites
    .map((n) => ALL_NAMES.find((x) => x.name === n))
    .filter((x): x is BabyName => Boolean(x));

  // Names favorited but not in dataset (defensive)
  const unknown: string[] = favorites.filter(
    (n) => !ALL_NAMES.some((x) => x.name === n)
  );

  const copyLink = async () => {
    if (typeof navigator === 'undefined') return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback: select via input
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-accent-500 fill-accent-500" />
            My Favorite Names
            <Badge variant="outline" className="ml-1 border-warm-300 text-warm-600">
              {favorites.length}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {favorites.length === 0 ? (
          <div className="py-10 text-center text-warm-500">
            <Heart className="w-12 h-12 mx-auto mb-3 text-warm-300" />
            <p>No favorites yet.</p>
            <p className="text-sm mt-1">
              Tap the heart on any name to save it here.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Share section */}
            <div className="bg-cream-100 rounded-lg p-3 border border-cream-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-warm-700 flex items-center gap-1">
                  <Share2 className="w-4 h-4" />
                  Share with partner
                </span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={onClearAll}
                  className="text-warm-500 hover:text-accent-600 h-7 px-2"
                >
                  <Trash2 className="w-3.5 h-3.5 mr-1" />
                  Clear all
                </Button>
              </div>
              <div className="flex gap-2">
                <input
                  readOnly
                  value={shareUrl}
                  onClick={(e) => e.currentTarget.select()}
                  className="flex-1 text-xs px-2 py-1.5 bg-white rounded border border-warm-200 text-warm-700 truncate"
                />
                <Button
                  size="sm"
                  onClick={copyLink}
                  className="bg-primary-600 hover:bg-primary-700 h-8"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 mr-1" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Detailed list */}
            <div className="space-y-2">
              {detailed.map((n) => (
                <div
                  key={n.name}
                  className="flex items-center justify-between p-3 bg-white rounded-lg border border-warm-200 hover:border-primary-300 transition"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-warm-900">
                        {n.name}
                      </span>
                      <Badge
                        variant="outline"
                        className={cn(
                          'text-xs capitalize',
                          n.gender === 'boy' &&
                            'border-blue-300 text-blue-700 bg-blue-50',
                          n.gender === 'girl' &&
                            'border-pink-300 text-pink-700 bg-pink-50',
                          n.gender === 'neutral' &&
                            'border-amber-300 text-amber-700 bg-amber-50'
                        )}
                      >
                        {n.gender}
                      </Badge>
                    </div>
                    <p className="text-xs text-warm-600 mt-0.5 truncate">
                      {n.meaning} · {n.origin}
                    </p>
                  </div>
                  <button
                    onClick={() => onRemove(n.name)}
                    className="text-warm-400 hover:text-accent-600 p-1"
                    aria-label={`Remove ${n.name}`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}

              {unknown.map((name) => (
                <div
                  key={name}
                  className="flex items-center justify-between p-3 bg-white rounded-lg border border-warm-200"
                >
                  <span className="font-semibold text-warm-900">{name}</span>
                  <button
                    onClick={() => onRemove(name)}
                    className="text-warm-400 hover:text-accent-600 p-1"
                    aria-label={`Remove ${name}`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ---------- Floating "View favorites" button ----------
export function FavoritesFloatingButton({
  count,
  onClick,
}: {
  count: number;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'fixed bottom-6 right-6 z-30 flex items-center gap-2 px-4 py-3 rounded-full shadow-soft-lg transition',
        count > 0
          ? 'bg-accent-500 hover:bg-accent-600 text-white'
          : 'bg-white hover:bg-cream-100 text-warm-700 border border-warm-300'
      )}
    >
      <Heart className={cn('w-5 h-5', count > 0 && 'fill-current')} />
      <span className="text-sm font-medium">
        {count > 0 ? `My Names (${count})` : 'My Names'}
      </span>
    </button>
  );
}
