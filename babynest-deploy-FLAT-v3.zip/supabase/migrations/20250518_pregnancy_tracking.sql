-- Migration: Create pregnancy tracking tables
-- Run this in your Supabase SQL Editor

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create contractions table
CREATE TABLE IF NOT EXISTS public.contractions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  start_time TIMESTAMP WITH TIME ZONE NOT NULL,
  end_time TIMESTAMP WITH TIME ZONE,
  duration INTEGER NOT NULL, -- Duration in milliseconds
  intensity TEXT NOT NULL CHECK (intensity IN ('mild', 'moderate', 'strong')),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create kick_sessions table
CREATE TABLE IF NOT EXISTS public.kick_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  start_time TIMESTAMP WITH TIME ZONE NOT NULL,
  end_time TIMESTAMP WITH TIME ZONE,
  kicks INTEGER NOT NULL DEFAULT 0,
  duration INTEGER NOT NULL, -- Duration in milliseconds
  completed BOOLEAN NOT NULL DEFAULT false,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_contractions_user_id ON public.contractions(user_id);
CREATE INDEX IF NOT EXISTS idx_contractions_start_time ON public.contractions(start_time DESC);
CREATE INDEX IF NOT EXISTS idx_kick_sessions_user_id ON public.kick_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_kick_sessions_start_time ON public.kick_sessions(start_time DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE public.contractions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kick_sessions ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for contractions
CREATE POLICY "Users can view their own contractions"
  ON public.contractions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own contractions"
  ON public.contractions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own contractions"
  ON public.contractions
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own contractions"
  ON public.contractions
  FOR DELETE
  USING (auth.uid() = user_id);

-- Create RLS policies for kick_sessions
CREATE POLICY "Users can view their own kick sessions"
  ON public.kick_sessions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own kick sessions"
  ON public.kick_sessions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own kick sessions"
  ON public.kick_sessions
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own kick sessions"
  ON public.kick_sessions
  FOR DELETE
  USING (auth.uid() = user_id);

-- Add comment for documentation
COMMENT ON TABLE public.contractions IS 'Stores contraction timing data for pregnancy tracking';
COMMENT ON TABLE public.kick_sessions IS 'Stores baby kick counting sessions for pregnancy tracking';
