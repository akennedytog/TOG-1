# Component Library Audit Report

**Date:** 2026-05-19  
**Auditor:** Subagent (Clawd)  
**Project:** babynest-full-fixed

---

## Executive Summary

The component library has **good structural foundations** with consistent use of `cn()` utility and mostly proper TypeScript patterns. However, several **inconsistencies** exist across the UI components, particularly in styling approaches, import patterns, and animation integration.

**Overall Rating:** ⚠️ Needs Attention (7/10)

---

## 1. Components/ui/ Directory Analysis

### 1.1 File Organization
✅ **Good:** All shadcn/ui components are properly organized in `components/ui/`

**Components Audited (22 files):**
- `alert.tsx` - Standard shadcn pattern
- `avatar.tsx` - Standard shadcn pattern
- `badge.tsx` - Standard shadcn pattern
- `button.tsx` - **Custom implementation** (non-standard)
- `card.tsx` - **Custom implementation** (non-standard)
- `checkbox.tsx` - Modified with mobile touch targets ✅
- `collapsible.tsx` - Standard shadcn pattern
- `dialog.tsx` - **Custom implementation** (non-standard)
- `dropdown-menu.tsx` - Standard shadcn pattern
- `GlassCard.tsx` - **Custom utility component**
- `input.tsx` - Mixed pattern (custom styling)
- `label.tsx` - Mixed pattern (custom styling)
- `progress.tsx` - **Custom implementation**
- `radio-group.tsx` - Mixed pattern
- `scroll-area.tsx` - Standard shadcn pattern
- `select.tsx` - **Custom implementation** + includes state data
- `separator.tsx` - Standard shadcn pattern
- `skeleton.tsx` - Custom styling
- `switch.tsx` - Standard shadcn pattern
- `tabs.tsx` - Standard shadcn pattern
- `textarea.tsx` - Standard shadcn pattern

### 1.2 Inconsistency Findings

#### A. Import Pattern Inconsistencies ⚠️

**Issue:** Mixed quote styles across files

| File | Quote Style |
|------|-------------|
| `alert.tsx`, `badge.tsx`, `avatar.tsx` | Double quotes `"` |
| `button.tsx`, `card.tsx`, `dialog.tsx` | Single quotes `'` |
| `input.tsx`, `label.tsx`, `progress.tsx` | Single quotes `'` |

**Recommendation:** Standardize on single quotes to match project convention.

#### B. Styling Approach Inconsistencies 🔴

**Issue:** Three different styling patterns detected:

1. **Standard shadcn** - Uses Tailwind classes like `bg-popover`, `text-popover-foreground`
   - Files: `alert.tsx`, `badge.tsx`, `avatar.tsx`, `collapsible.tsx`, `dropdown-menu.tsx`, `scroll-area.tsx`, `separator.tsx`, `switch.tsx`, `tabs.tsx`, `textarea.tsx`

2. **Custom warm palette** - Uses custom color names like `bg-warm-100`, `text-warm-500`
   - Files: `card.tsx`, `dialog.tsx`, `GlassCard.tsx`, `input.tsx`, `label.tsx`, `progress.tsx`, `radio-group.tsx`, `select.tsx`, `skeleton.tsx`

3. **Hybrid approach** - Mix of standard and custom
   - Files: `checkbox.tsx`, `button.tsx`

**Example Inconsistency:**
```tsx
// alert.tsx uses standard shadcn
"bg-background text-foreground"

// card.tsx uses custom palette
"rounded-2xl bg-white border border-warm-100"

// dialog.tsx uses mixed
"border border-warm-200 bg-white" + "text-warm-900"
```

**Recommendation:** Define a clear design system and migrate all components to use consistent color tokens.

#### C. Component Implementation Pattern Inconsistencies ⚠️

**Issue:** Different component definition patterns:

**Pattern 1: React.forwardRef with displayName**
```tsx
const Component = React.forwardRef<...>(({ className, ...props }, ref) => (
  ...
));
Component.displayName = ...;
```
Used by: Most shadcn components

**Pattern 2: Function declaration with interface**
```tsx
export interface ButtonProps extends ... {
  variant?: 'primary' | ...;
}
const Button = React.forwardRef<...>(
  ({ className, variant, ... }, ref) => { ... }
);
```
Used by: `button.tsx`

**Pattern 3: Function component**
```tsx
function Skeleton({ className, ...props }: React.HTMLAttributes<...>) { ... }
```
Used by: `skeleton.tsx`

**Recommendation:** Standardize on Pattern 1 for UI components.

#### D. Missing Component Exports ⚠️

Some components don't export individual parts consistently:
- `alert.tsx` - Missing AlertTitle (commonly needed)
- `card.tsx` - ✅ Complete (Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent)
- `dialog.tsx` - ✅ Complete exports

---

## 2. SharedHeader.tsx Analysis

### 2.1 Structure
✅ **Well-organized** navigation component with:
- Desktop and mobile responsive layouts
- Feature-based navigation groups
- User menu with profile editing
- Birth completion modal

### 2.2 Issues Found

#### A. Duplicate Import ⚠️
```tsx
import { cn } from '@/lib/utils';  // Line 29
import { formatDate } from '@/lib/utils';  // Line 30
```
**Should combine:** `import { cn, formatDate } from '@/lib/utils';`

#### B. Duplicate State Data 🔴
The component defines its own full state list:
```tsx
const states = [
  'Alabama','Alaska','Arizona',...  // 51 items
];
```

But `components/ui/select.tsx` also exports a `states` array with abbreviated codes:
```tsx
export const states = [
  { value: '', label: 'Select your state' },
  { value: 'AL', label: 'Alabama' },...
];
```

**Issue:** Two different state data structures - one with full names, one with abbreviations.

#### C. Mixed Button Usage ⚠️
Uses both:
- `import { Button } from '@/components/ui/button';` (custom Button)
- Native `<button>` elements for some actions

**Recommendation:** Standardize on the custom Button component for consistency.

---

## 3. Animations Directory Analysis

### 3.1 Files Audited
- `AnimatedBackground.tsx` - Canvas-based animated backgrounds
- `ScrollReveal.tsx` - Intersection Observer-based reveal animations
- `StaggerContainer.tsx` - Framer Motion stagger animations

### 3.2 Findings

#### A. Inconsistent Animation Libraries 🔴

| File | Library | Pattern |
|------|---------|---------|
| `AnimatedBackground.tsx` | Native CSS + Canvas | Keyframe animations |
| `ScrollReveal.tsx` | Native Intersection Observer | CSS transitions |
| `StaggerContainer.tsx` | Framer Motion | Variants-based |

**Issue:** Three different animation approaches in one project. This increases bundle size (Framer Motion is heavy) and creates inconsistency in animation feel.

#### B. Missing Export Pattern ⚠️
`AnimatedBackground.tsx` exports both a component AND raw styles:
```tsx
export const animatedBackgroundStyles = `...`;
export function AnimatedBackgroundStyles() { ... }
```

This is unconventional. The `SharedHeader.tsx` imports `AnimatedBackgroundStyles` component just to inject styles.

#### C. Unused Animation Components? ⚠️
Based on grep results, only `StaggerContainer` and `AnimatedBackground` are imported in the app. `ScrollReveal.tsx` may be unused.

---

## 4. Duplicate Code Analysis

### 4.1 State Data Duplication 🔴
**Location:** 
- `components/ui/select.tsx` (abbreviated codes)
- `components/SharedHeader.tsx` (full names)
- `app/onboarding/components/StateStep.tsx` (likely)

**Recommendation:** Create a single `lib/states.ts` file with both formats exported.

### 4.2 Animation Pattern Duplication ⚠️
Both `ScrollReveal` and `StaggerContainer` provide stagger animation capabilities but with different APIs:
- `ScrollReveal` uses Intersection Observer + CSS
- `StaggerContainer` uses Framer Motion

**Recommendation:** Consolidate to one approach.

### 4.3 Card Component Duplication ⚠️
- `components/ui/card.tsx` - Standard card
- `components/ui/GlassCard.tsx` - Glass morphism variant

These could potentially be merged with a `variant` prop.

---

## 5. TypeScript Type Analysis

### 5.1 Type Safety Issues ⚠️

**In `button.tsx`:**
```tsx
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'gradient' | 'soft';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  isLoading?: boolean;
}
```
✅ Proper interface export

**In `card.tsx`:**
```tsx
const Card = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>...
```
✅ Uses React.HTMLAttributes

**In `GlassCard.tsx`:**
```tsx
interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  // ... more props
}
```
✅ Well-defined interfaces

### 5.2 Missing Type Exports ⚠️
Some components don't export their prop types:
- `alert.tsx` - AlertProps not exported
- `select.tsx` - Component props not exported (though `states` is)

---

## 6. Recommendations Summary

### High Priority 🔴

1. **Standardize Color Palette**
   - Choose either shadcn default tokens OR custom warm palette
   - Create a design tokens file
   - Audit and migrate all components

2. **Consolidate Animation Approach**
   - Choose one animation library (recommend Framer Motion OR CSS, not both)
   - Remove unused animation components

3. **Extract Shared Data**
   - Move `states` array to `lib/states.ts`
   - Reference from both `select.tsx` and `SharedHeader.tsx`

### Medium Priority ⚠️

4. **Standardize Import Quotes**
   - Use single quotes consistently across all component files

5. **Standardize Component Pattern**
   - Use `React.forwardRef` + `displayName` pattern consistently

6. **Fix Duplicate Imports**
   - Combine imports from same module in `SharedHeader.tsx`

### Low Priority 💡

7. **Consider Merging Card Components**
   - Evaluate if `GlassCard` can be a variant of `Card`

8. **Export Component Types**
   - Export prop interfaces for all components

9. **Add Component Documentation**
   - Document component props with JSDoc comments

---

## 7. Component Usage Summary

**Most Used Components (based on grep):**
1. `Button` - Used in 17+ components
2. `Card` (and variants) - Used in 20+ locations
3. `Input` - Used in 10+ locations
4. `Badge` - Used in 6+ locations

**Animation Usage:**
- `StaggerContainer` - Used in dashboard
- `AnimatedBackground` - Used in SharedHeader
- `ScrollReveal` - Potentially unused

---

## Appendix: File-by-File Status

| File | Pattern | Styling | Types | Issues |
|------|---------|---------|-------|--------|
| alert.tsx | Standard shadcn | Standard tokens | ✅ | None |
| avatar.tsx | Standard shadcn | Standard tokens | ✅ | None |
| badge.tsx | Standard shadcn | Standard tokens | ✅ | None |
| button.tsx | Custom | Custom palette | ✅ | Mixed quotes |
| card.tsx | Custom | Custom palette | ✅ | None |
| checkbox.tsx | Modified | Mixed | ✅ | None |
| collapsible.tsx | Standard | Standard | ✅ | None |
| dialog.tsx | Custom | Custom palette | ✅ | None |
| dropdown-menu.tsx | Standard | Standard | ✅ | None |
| GlassCard.tsx | Custom | Custom palette | ✅ | None |
| input.tsx | Mixed | Custom palette | ✅ | None |
| label.tsx | Mixed | Custom palette | ✅ | None |
| progress.tsx | Custom | Custom palette | ✅ | None |
| radio-group.tsx | Mixed | Custom palette | ✅ | None |
| scroll-area.tsx | Standard | Standard | ✅ | None |
| select.tsx | Custom | Custom palette | ✅ | Contains data |
| separator.tsx | Standard | Standard | ✅ | None |
| skeleton.tsx | Simple | Custom palette | ✅ | None |
| switch.tsx | Standard | Standard | ✅ | None |
| tabs.tsx | Standard | Standard | ✅ | None |
| textarea.tsx | Standard | Standard | ✅ | None |

---

*End of Audit Report*
