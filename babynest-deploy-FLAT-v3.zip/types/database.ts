// Database types for Supabase
// Shape matches what @supabase/postgrest-js expects: each Table must have
// Row/Insert/Update/Relationships, and the schema must include Views/Functions/Enums.

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

// Generic permissive row used for tables we don't fully model yet.
type GenericRow = { [key: string]: any };
type GenericTable = {
  Row: GenericRow;
  Insert: GenericRow;
  Update: GenericRow;
  Relationships: [];
};

export type Database = {
  public: {
    Tables: {
      tasks: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          description: string | null;
          due_date: string | null;
          category: string;
          status: string;
          priority: string;
          priority_weight: number | null;
          state_specific: boolean;
          state: string | null;
          estimated_time: number | null;
          completion_date: string | null;
          icon: string | null;
          order: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          title: string;
          description?: string | null;
          due_date?: string | null;
          category: string;
          status: string;
          priority: string;
          priority_weight?: number | null;
          state_specific?: boolean;
          state?: string | null;
          estimated_time?: number | null;
          completion_date?: string | null;
          icon?: string | null;
          order?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          title?: string;
          description?: string | null;
          due_date?: string | null;
          category?: string;
          status?: string;
          priority?: string;
          priority_weight?: number | null;
          state_specific?: boolean;
          state?: string | null;
          estimated_time?: number | null;
          completion_date?: string | null;
          icon?: string | null;
          order?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          state: string | null;
          due_date: string | null;
          birth_date: string | null;
          income_bracket: string | null;
          family_size: number;
          onboarding_completed: boolean;
          onboarding_completed_at: string | null;
          onboarding_step: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          email: string;
          full_name?: string | null;
          state?: string | null;
          due_date?: string | null;
          birth_date?: string | null;
          income_bracket?: string | null;
          family_size?: number;
          onboarding_completed?: boolean;
          onboarding_completed_at?: string | null;
          onboarding_step?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          state?: string | null;
          due_date?: string | null;
          birth_date?: string | null;
          income_bracket?: string | null;
          family_size?: number;
          onboarding_completed?: boolean;
          onboarding_completed_at?: string | null;
          onboarding_step?: number;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      newsletter_subscribers: {
        Row: {
          id: string;
          email: string;
          subscribed: boolean;
          subscribed_at: string | null;
          unsubscribed_at: string | null;
          source: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          email: string;
          subscribed?: boolean;
          subscribed_at?: string | null;
          unsubscribed_at?: string | null;
          source?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          subscribed?: boolean;
          subscribed_at?: string | null;
          unsubscribed_at?: string | null;
          source?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      waitlist: {
        Row: {
          id: string;
          email: string;
          state: string | null;
          due_date: string | null;
          joined_at: string;
        };
        Insert: {
          id?: string;
          email: string;
          state?: string | null;
          due_date?: string | null;
          joined_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          state?: string | null;
          due_date?: string | null;
          joined_at?: string;
        };
        Relationships: [];
      };
      hospital_bag_items: {
        Row: {
          id: string;
          user_id: string;
          item_key: string | null;
          name: string;
          category: string;
          essential: boolean;
          checked: boolean;
          packed: boolean;
          is_custom: boolean;
          description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          item_key?: string | null;
          name: string;
          category: string;
          essential?: boolean;
          checked?: boolean;
          packed?: boolean;
          is_custom?: boolean;
          description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          item_key?: string | null;
          name?: string;
          category?: string;
          essential?: boolean;
          checked?: boolean;
          packed?: boolean;
          is_custom?: boolean;
          description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      // Tables modeled permissively so TypeScript queries work without
      // an exhaustive schema definition.
      budget_settings: GenericTable;
      expenses: GenericTable;
      registry_items: GenericTable;
      savings_goals: GenericTable;
      benefit_documents: GenericTable;
      action_items: GenericTable;
      birth_plans: GenericTable;
      vaccinations: GenericTable;
      milestones: GenericTable;
      family_members: GenericTable;
      subscriptions: GenericTable;
      insurance_docs: GenericTable;
      documents: GenericTable;
      notification_preferences: GenericTable;
      push_subscriptions: GenericTable;
      admins: GenericTable;
      baby_registry_items: GenericTable;
      budgets: GenericTable;
      baby_metrics: {
        Row: {
          id: string;
          user_id: string;
          date: string;
          weight: number | null;
          height: number | null;
          temperature: number | null;
          feedings: number | null;
          diapers: number | null;
          sleep_minutes: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          date: string;
          weight?: number | null;
          height?: number | null;
          temperature?: number | null;
          feedings?: number | null;
          diapers?: number | null;
          sleep_minutes?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          date?: string;
          weight?: number | null;
          height?: number | null;
          temperature?: number | null;
          feedings?: number | null;
          diapers?: number | null;
          sleep_minutes?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      contractions: {
        Row: {
          id: string;
          user_id: string;
          start_time: string;
          end_time: string | null;
          duration: number;
          intensity: 'mild' | 'moderate' | 'strong';
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          start_time: string;
          end_time?: string | null;
          duration: number;
          intensity: 'mild' | 'moderate' | 'strong';
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          start_time?: string;
          end_time?: string | null;
          duration?: number;
          intensity?: 'mild' | 'moderate' | 'strong';
          notes?: string | null;
          created_at?: string;
        };
        Relationships: [];
      };
      kick_sessions: {
        Row: {
          id: string;
          user_id: string;
          start_time: string;
          end_time: string | null;
          kicks: number;
          duration: number;
          completed: boolean;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          start_time: string;
          end_time?: string | null;
          kicks: number;
          duration: number;
          completed: boolean;
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          start_time?: string;
          end_time?: string | null;
          kicks?: number;
          duration?: number;
          completed?: boolean;
          notes?: string | null;
          created_at?: string;
        };
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
};
