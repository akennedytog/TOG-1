'use client';

import { useMemo, useState } from 'react';
import {
  Search,
  ShieldCheck,
  AlertTriangle,
  Ban,
  Info,
  ChevronDown,
  ChevronUp,
  ExternalLink,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  SAFETY_ITEMS,
  CATEGORY_META,
  VERDICT_META,
  TOTAL_SAFETY_ITEMS,
  type SafetyCategory,
  type SafetyItem,
  type SafetyVerdict,
} from '@/lib/safety-data';

const CATEGORIES: SafetyCategory[] = [
  'food',
  'medications',
  'activities',
  'beauty',
];

function VerdictBadge({ verdict }: { verdict: SafetyVerdict }) {
  const meta = VERDICT_META[verdict];
  const Icon =
    verdict === 'yes' ? ShieldCheck : verdict === 'maybe' ? AlertTriangle : Ban;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${meta.bg} ${meta.color} ${meta.border}`}
    >
      <Icon className="w-3.5 h-3.5" />
      {meta.label}
    </span>
  );
}

function SafetyCard({ item }: { item: SafetyItem }) {
  const [open, setOpen] = useState(false);
  const cat = CATEGORY_META[item.category];

  return (
    <Card className="border-warm-200 shadow-soft hover:shadow-soft-lg transition-shadow">
      <CardContent className="p-5">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="w-full text-left"
          aria-expanded={open}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 text-xs text-warm-500 mb-1">
                <span>
                  {cat.emoji} {cat.label}
                </span>
              </div>
              <h3 className="font-semibold text-warm-900 text-base sm:text-lg leading-snug">
                {item.question}
              </h3>
              <p className="text-sm text-warm-600 mt-1">{item.shortAnswer}</p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <VerdictBadge verdict={item.verdict} />
              {open ? (
                <ChevronUp className="w-4 h-4 text-warm-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-warm-400" />
              )}
            </div>
          </div>
        </button>

        {open && (
          <div className="mt-4 pt-4 border-t border-warm-100 space-y-3 animate-fade-in">
            <p className="text-sm text-warm-700 leading-relaxed">
              {item.explanation}
            </p>
            {item.tip && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-primary-50 border border-primary-200">
                <Info className="w-4 h-4 text-primary-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-primary-800">
                  <span className="font-semibold">Tip:</span> {item.tip}
                </p>
              </div>
            )}
            <div className="text-xs text-warm-500 flex items-center gap-1.5">
              <span>Source: {item.source}</span>
              {item.sourceUrl && (
                <a
                  href={item.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-primary-600 hover:text-primary-700"
                >
                  <ExternalLink className="w-3 h-3" />
                  visit
                </a>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function IsItSafe() {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<SafetyCategory | 'all'>(
    'all'
  );
  const [activeVerdict, setActiveVerdict] = useState<SafetyVerdict | 'all'>(
    'all'
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return SAFETY_ITEMS.filter((item) => {
      if (activeCategory !== 'all' && item.category !== activeCategory)
        return false;
      if (activeVerdict !== 'all' && item.verdict !== activeVerdict)
        return false;
      if (!q) return true;
      const hay = [
        item.name,
        item.question,
        item.shortAnswer,
        item.explanation,
        ...item.aliases,
      ]
        .join(' ')
        .toLowerCase();
      return hay.includes(q);
    });
  }, [query, activeCategory, activeVerdict]);

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="text-center space-y-3 pt-2">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-400 to-accent-400 shadow-soft">
          <ShieldCheck className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-warm-900">
          Is It Safe? 🤰
        </h1>
        <p className="text-warm-600 max-w-xl mx-auto">
          Quick, plain-language answers to {TOTAL_SAFETY_ITEMS}+ of the most
          common &ldquo;can I have this while pregnant?&rdquo; questions.
        </p>
      </div>

      {/* Search */}
      <Card className="border-warm-200 shadow-soft">
        <CardContent className="p-4 sm:p-5 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-warm-400" />
            <Input
              type="search"
              placeholder="Search sushi, coffee, ibuprofen, hot tub…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-9 bg-white"
            />
          </div>

          {/* Category filters */}
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                activeCategory === 'all'
                  ? 'bg-primary-500 text-white border-primary-500'
                  : 'bg-white text-warm-700 border-warm-200 hover:bg-warm-50'
              }`}
            >
              All categories
            </button>
            {CATEGORIES.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setActiveCategory(c)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                  activeCategory === c
                    ? 'bg-primary-500 text-white border-primary-500'
                    : 'bg-white text-warm-700 border-warm-200 hover:bg-warm-50'
                }`}
              >
                {CATEGORY_META[c].emoji} {CATEGORY_META[c].label}
              </button>
            ))}
          </div>

          {/* Verdict filters */}
          <div className="flex flex-wrap gap-2 pt-1 border-t border-warm-100">
            <span className="text-xs text-warm-500 self-center mr-1">
              Filter by verdict:
            </span>
            <button
              type="button"
              onClick={() => setActiveVerdict('all')}
              className={`px-2.5 py-1 rounded-full text-xs border ${
                activeVerdict === 'all'
                  ? 'bg-warm-900 text-white border-warm-900'
                  : 'bg-white text-warm-700 border-warm-200 hover:bg-warm-50'
              }`}
            >
              All
            </button>
            {(['yes', 'maybe', 'no'] as SafetyVerdict[]).map((v) => {
              const meta = VERDICT_META[v];
              const active = activeVerdict === v;
              return (
                <button
                  key={v}
                  type="button"
                  onClick={() => setActiveVerdict(v)}
                  className={`px-2.5 py-1 rounded-full text-xs border transition-all ${
                    active
                      ? `${meta.bg} ${meta.color} ${meta.border} font-semibold`
                      : 'bg-white text-warm-700 border-warm-200 hover:bg-warm-50'
                  }`}
                >
                  {meta.emoji} {meta.label}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Results summary */}
      <div className="flex items-center justify-between text-sm text-warm-600">
        <span>
          Showing <span className="font-semibold">{filtered.length}</span>{' '}
          of {TOTAL_SAFETY_ITEMS} items
        </span>
        {(query || activeCategory !== 'all' || activeVerdict !== 'all') && (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setActiveCategory('all');
              setActiveVerdict('all');
            }}
            className="text-primary-600 hover:text-primary-700 font-medium"
          >
            Clear filters
          </button>
        )}
      </div>

      {/* Results */}
      {filtered.length === 0 ? (
        <Card className="border-warm-200">
          <CardContent className="p-8 text-center space-y-2">
            <Search className="w-8 h-8 text-warm-400 mx-auto" />
            <p className="text-warm-700 font-medium">No matches found</p>
            <p className="text-sm text-warm-500">
              Try a different search term or clear your filters. If you can&apos;t
              find what you&apos;re looking for, ask your healthcare provider.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {filtered.map((item) => (
            <SafetyCard key={item.slug} item={item} />
          ))}
        </div>
      )}

      {/* Disclaimer */}
      <Card className="border-amber-200 bg-amber-50">
        <CardContent className="p-5 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
          <div className="space-y-1 text-sm text-amber-900">
            <p className="font-semibold">A quick note from us 💛</p>
            <p>
              BabyNest&apos;s safety database is for general information only — it
              is <span className="font-semibold">not</span> medical advice. Every
              pregnancy is different, and guidance can change based on your
              health history. Always talk with your OB/GYN, midwife, or
              pharmacist before starting, stopping, or changing anything.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
