import type { Metadata } from 'next';
import { IsItSafe } from './IsItSafe';

export const metadata: Metadata = {
  title: 'Is It Safe During Pregnancy? — BabyNest',
  description:
    'Searchable database of common pregnancy safety questions. Sushi, coffee, ibuprofen, hot tubs, hair dye, retinol and more — with sources from ACOG, FDA, and CDC.',
  keywords: [
    'pregnancy safety',
    'is it safe pregnancy',
    'pregnancy foods to avoid',
    'pregnancy medications',
    'pregnancy do and dont',
    'pregnant can I eat',
    'pregnant can I take',
  ],
  openGraph: {
    title: 'Is It Safe During Pregnancy? — BabyNest',
    description:
      'Plain-language, sourced answers to the most common pregnancy safety questions.',
    type: 'website',
  },
};

export default function IsItSafePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-cream-50 via-white to-cream-100">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <IsItSafe />
      </div>
    </main>
  );
}
