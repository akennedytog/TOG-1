import type { Metadata } from 'next';
import { DueDateCalculator } from './DueDateCalculator';
import { LegalDisclaimer } from '@/components/LegalDisclaimer';

export const metadata: Metadata = {
  title: 'Due Date Calculator — BabyNest',
  description:
    'Free pregnancy due date calculator. Estimate your due date, conception date, current trimester, and how far along you are based on your last period.',
  keywords: [
    'due date calculator',
    'pregnancy calculator',
    'when is my baby due',
    'conception date',
    'trimester calculator',
    'pregnancy week calculator',
  ],
  openGraph: {
    title: 'Due Date Calculator — BabyNest',
    description:
      'Find out your due date, conception date, and current trimester in seconds.',
    type: 'website',
  },
};

export default function DueDateCalculatorPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-cream-50 via-white to-cream-100">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <DueDateCalculator />
      </div>
      <LegalDisclaimer type="medical" message="Estimates only. Confirm with your healthcare provider." />
    </main>
  );
}
