'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Baby,
  Calendar,
  Heart,
  Sparkles,
  Mail,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';

type CycleMethod = 'lmp' | 'cycle';

interface Calculation {
  lmpDate: Date;
  dueDate: Date;
  conceptionDate: Date;
  weeksPregnant: number;
  daysPregnant: number;
  trimester: 1 | 2 | 3;
  daysRemaining: number;
}

// Naegele's rule: due date = LMP + 280 days (40 weeks)
// Adjusted for custom cycle length: + (cycleLength - 28) days
function calculate(lmp: Date, cycleLength: number = 28): Calculation {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const lmpStart = new Date(lmp);
  lmpStart.setHours(0, 0, 0, 0);

  const adjustment = cycleLength - 28;

  const dueDate = new Date(lmpStart);
  dueDate.setDate(dueDate.getDate() + 280 + adjustment);

  // Conception typically ~14 days after LMP (adjusted for cycle length)
  const conceptionDate = new Date(lmpStart);
  conceptionDate.setDate(conceptionDate.getDate() + 14 + adjustment);

  const msPerDay = 1000 * 60 * 60 * 24;
  const daysPregnant = Math.floor(
    (today.getTime() - lmpStart.getTime()) / msPerDay
  );
  const weeksPregnant = Math.floor(daysPregnant / 7);
  const remainderDays = daysPregnant % 7;

  const daysRemaining = Math.max(
    0,
    Math.ceil((dueDate.getTime() - today.getTime()) / msPerDay)
  );

  const trimester: 1 | 2 | 3 =
    weeksPregnant <= 12 ? 1 : weeksPregnant <= 27 ? 2 : 3;

  return {
    lmpDate: lmpStart,
    dueDate,
    conceptionDate,
    weeksPregnant,
    daysPregnant: remainderDays,
    trimester,
    daysRemaining,
  };
}

function formatDate(d: Date): string {
  return d.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

function trimesterDescription(trimester: 1 | 2 | 3): string {
  switch (trimester) {
    case 1:
      return 'First trimester (weeks 1–12) — Your baby is developing rapidly. Most major organs are forming.';
    case 2:
      return 'Second trimester (weeks 13–27) — The "honeymoon" trimester. You may start feeling little kicks soon.';
    case 3:
      return 'Third trimester (weeks 28–40) — The home stretch. Time to finish up nursery prep and pack a hospital bag.';
  }
}

export function DueDateCalculator() {
  const [method, setMethod] = useState<CycleMethod>('lmp');
  const [lmpDate, setLmpDate] = useState('');
  const [cycleLength, setCycleLength] = useState(28);
  const [calculated, setCalculated] = useState<Calculation | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [email, setEmail] = useState('');
  const [subscribeStatus, setSubscribeStatus] = useState<
    'idle' | 'loading' | 'success' | 'error'
  >('idle');
  const [subscribeMessage, setSubscribeMessage] = useState('');

  const todayString = useMemo(() => {
    const d = new Date();
    return d.toISOString().slice(0, 10);
  }, []);

  const handleCalculate = (e?: React.FormEvent) => {
    e?.preventDefault();
    setError(null);

    if (!lmpDate) {
      setError('Please enter the first day of your last period.');
      return;
    }

    const lmp = new Date(lmpDate + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (isNaN(lmp.getTime())) {
      setError('That date doesn\'t look valid.');
      return;
    }
    if (lmp > today) {
      setError('Your last period date is in the future. Please re-check.');
      return;
    }

    const diffDays = Math.floor(
      (today.getTime() - lmp.getTime()) / (1000 * 60 * 60 * 24)
    );
    if (diffDays > 300) {
      setError(
        'That date is more than 300 days ago — likely outside a typical pregnancy window.'
      );
      return;
    }

    const safeCycle =
      method === 'cycle' ? Math.min(45, Math.max(20, cycleLength)) : 28;
    setCalculated(calculate(lmp, safeCycle));
  };

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setSubscribeStatus('error');
      setSubscribeMessage('Please enter your email.');
      return;
    }

    setSubscribeStatus('loading');
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source: 'due_date_calculator' }),
      });
      const data = await res.json();
      if (res.ok) {
        setSubscribeStatus('success');
        setSubscribeMessage(
          data.message || 'You\'re in! Weekly pregnancy updates on the way.'
        );
        setEmail('');
      } else {
        setSubscribeStatus('error');
        setSubscribeMessage(
          data.message || 'Something went wrong. Please try again.'
        );
      }
    } catch {
      setSubscribeStatus('error');
      setSubscribeMessage('Failed to subscribe. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="text-center space-y-3 pt-2">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-400 to-primary-500 shadow-soft">
          <Baby className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-warm-900">
          Due Date Calculator 👶
        </h1>
        <p className="text-warm-600 max-w-xl mx-auto">
          Find out when your little one is expected, how far along you are
          right now, and which trimester you&apos;re in.
        </p>
      </div>

      {/* Calculator card */}
      <Card className="border-warm-200 shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-warm-900">
            <Calendar className="w-5 h-5 text-primary-600" />
            Tell us a little about your cycle
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCalculate} className="space-y-5">
            {/* Method toggle */}
            <div className="flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={() => setMethod('lmp')}
                className={`flex-1 px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                  method === 'lmp'
                    ? 'bg-primary-50 border-primary-300 text-primary-700 shadow-sm'
                    : 'bg-white border-warm-200 text-warm-600 hover:bg-warm-50'
                }`}
              >
                Standard 28-day cycle
              </button>
              <button
                type="button"
                onClick={() => setMethod('cycle')}
                className={`flex-1 px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                  method === 'cycle'
                    ? 'bg-primary-50 border-primary-300 text-primary-700 shadow-sm'
                    : 'bg-white border-warm-200 text-warm-600 hover:bg-warm-50'
                }`}
              >
                Custom cycle length
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="lmp" className="text-warm-700">
                  First day of last period (LMP)
                </Label>
                <Input
                  id="lmp"
                  type="date"
                  value={lmpDate}
                  max={todayString}
                  onChange={(e) => setLmpDate(e.target.value)}
                  required
                />
              </div>

              {method === 'cycle' && (
                <div className="space-y-2">
                  <Label htmlFor="cycle" className="text-warm-700">
                    Average cycle length (days)
                  </Label>
                  <Input
                    id="cycle"
                    type="number"
                    min={20}
                    max={45}
                    value={cycleLength}
                    onChange={(e) =>
                      setCycleLength(Number(e.target.value) || 28)
                    }
                  />
                  <p className="text-xs text-warm-500">
                    Most cycles fall between 24 and 35 days.
                  </p>
                </div>
              )}
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-accent-50 border border-accent-200 text-accent-700 text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Button
              type="submit"
              size="lg"
              className="w-full bg-primary-500 hover:bg-primary-600 text-white"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Calculate My Due Date
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Results */}
      {calculated && (
        <div className="space-y-4 animate-fade-in">
          <Card className="bg-gradient-to-br from-primary-50 via-cream-50 to-accent-50 border-primary-200 shadow-soft">
            <CardContent className="p-6 sm:p-8 text-center space-y-2">
              <p className="text-sm font-medium text-warm-600 uppercase tracking-wide">
                Your estimated due date
              </p>
              <p className="text-3xl sm:text-4xl font-bold text-primary-700">
                {formatDate(calculated.dueDate)} 🎉
              </p>
              {calculated.daysRemaining > 0 ? (
                <p className="text-warm-700">
                  That&apos;s{' '}
                  <span className="font-semibold">
                    {calculated.daysRemaining} days
                  </span>{' '}
                  from today.
                </p>
              ) : (
                <p className="text-warm-700">
                  Your due date has arrived — any day now! 👶
                </p>
              )}
            </CardContent>
          </Card>

          <div className="grid sm:grid-cols-3 gap-4">
            <Card className="border-warm-200 shadow-soft">
              <CardContent className="p-5 space-y-1">
                <div className="flex items-center gap-2 text-warm-600 text-xs uppercase font-medium">
                  <TrendingUp className="w-3.5 h-3.5" />
                  How far along
                </div>
                <p className="text-2xl font-bold text-warm-900">
                  {calculated.weeksPregnant}w {calculated.daysPregnant}d
                </p>
                <p className="text-sm text-warm-600">
                  Week {calculated.weeksPregnant} of 40
                </p>
              </CardContent>
            </Card>

            <Card className="border-warm-200 shadow-soft">
              <CardContent className="p-5 space-y-1">
                <div className="flex items-center gap-2 text-warm-600 text-xs uppercase font-medium">
                  <Heart className="w-3.5 h-3.5" />
                  Trimester
                </div>
                <p className="text-2xl font-bold text-warm-900">
                  {calculated.trimester === 1
                    ? '1st'
                    : calculated.trimester === 2
                    ? '2nd'
                    : '3rd'}
                </p>
                <p className="text-sm text-warm-600">Trimester</p>
              </CardContent>
            </Card>

            <Card className="border-warm-200 shadow-soft">
              <CardContent className="p-5 space-y-1">
                <div className="flex items-center gap-2 text-warm-600 text-xs uppercase font-medium">
                  <Sparkles className="w-3.5 h-3.5" />
                  Conception (est.)
                </div>
                <p className="text-base font-bold text-warm-900 leading-tight">
                  {calculated.conceptionDate.toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </p>
                <p className="text-xs text-warm-500">Estimate ±a few days</p>
              </CardContent>
            </Card>
          </div>

          <Card className="border-primary-200 bg-white shadow-soft">
            <CardContent className="p-5 flex items-start gap-3">
              <Badge className="bg-primary-100 text-primary-700 hover:bg-primary-100">
                Trimester {calculated.trimester}
              </Badge>
              <p className="text-sm text-warm-700 leading-relaxed">
                {trimesterDescription(calculated.trimester)}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Newsletter CTA */}
      <Card className="border-primary-200 bg-gradient-to-br from-primary-50 to-cream-100 shadow-soft">
        <CardContent className="p-6 sm:p-8">
          <div className="text-center space-y-2 mb-5">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-white shadow-sm">
              <Mail className="w-6 h-6 text-primary-600" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-warm-900">
              Get weekly pregnancy updates 📬
            </h2>
            <p className="text-warm-600 text-sm max-w-md mx-auto">
              Week-by-week development, what to expect, and friendly financial
              nudges — straight to your inbox. Free, unsubscribe anytime.
            </p>
          </div>

          <form
            onSubmit={handleSubscribe}
            className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto"
          >
            <Input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={subscribeStatus === 'loading'}
              required
              className="bg-white"
            />
            <Button
              type="submit"
              disabled={subscribeStatus === 'loading'}
              className="bg-primary-500 hover:bg-primary-600 text-white sm:w-auto"
            >
              {subscribeStatus === 'loading' ? 'Subscribing…' : 'Subscribe'}
            </Button>
          </form>

          {subscribeStatus === 'success' && (
            <div className="mt-4 flex items-center justify-center gap-2 text-primary-700 text-sm">
              <CheckCircle2 className="w-4 h-4" />
              <span>{subscribeMessage}</span>
            </div>
          )}
          {subscribeStatus === 'error' && (
            <div className="mt-4 flex items-center justify-center gap-2 text-accent-700 text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{subscribeMessage}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <p className="text-xs text-warm-500 text-center max-w-2xl mx-auto pb-4">
        Due date calculators use Naegele&apos;s rule and are estimates only. Only
        about 4% of babies arrive exactly on their due date. Talk with your
        healthcare provider for an accurate, ultrasound-confirmed date.
      </p>
    </div>
  );
}
