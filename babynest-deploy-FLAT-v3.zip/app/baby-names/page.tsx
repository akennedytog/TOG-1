'use client';

import { useEffect, useMemo, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Search,
  TrendingUp,
  TrendingDown,
  Minus,
  Filter,
  X,
  Loader2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { SharedHeader } from '@/components/SharedHeader';
import {
  BabyName,
  Gender,
  Trend,
  ALL_NAMES,
  BOY_NAMES,
  GIRL_NAMES,
  NEUTRAL_NAMES,
  NAME_ORIGINS,
  filterNames,
  getTrendLabel,
} from '@/lib/baby-names-data';
import {
  useFavoriteNames,
  FavoriteButton,
  MyNamesList,
  FavoritesFloatingButton,
  decodeList,
} from '@/components/MyNamesList';

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

type GenderTab = 'all' | Gender;

function BabyNamesContent() {
  const searchParams = useSearchParams();
  const {
    favorites,
    isFavorite,
    toggleFavorite,
    removeFavorite,
    clearAll,
  } = useFavoriteNames();

  const [gender, setGender] = useState<GenderTab>('all');
  const [search, setSearch] = useState('');
  const [startsWith, setStartsWith] = useState('');
  const [origin, setOrigin] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [sharedNotice, setSharedNotice] = useState<string[] | null>(null);

  useEffect(() => {
    const encoded = searchParams?.get('names');
    if (encoded) {
      const list = decodeList(encoded);
      if (list.length > 0) setSharedNotice(list);
    }
  }, [searchParams]);

  const results = useMemo(
    () =>
      filterNames({
        gender,
        startsWith,
        origin,
        search,
      }),
    [gender, startsWith, origin, search]
  );

  const counts = {
    all: ALL_NAMES.length,
    boy: BOY_NAMES.length,
    girl: GIRL_NAMES.length,
    neutral: NEUTRAL_NAMES.length,
  };

  const clearFilters = () => {
    setStartsWith('');
    setOrigin('all');
    setSearch('');
  };

  const hasActiveFilters =
    Boolean(startsWith) || origin !== 'all' || Boolean(search);

  const mergeSharedList = () => {
    if (!sharedNotice) return;
    sharedNotice.forEach((n) => {
      if (!isFavorite(n)) toggleFavorite(n);
    });
    setSharedNotice(null);
  };

  return (
    <div className="min-h-screen bg-cream-50">
      <SharedHeader />

      <div className="bg-gradient-to-br from-primary-500 to-primary-700 text-white">
        <div className="container mx-auto px-4 py-10 md:py-12 max-w-6xl">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold flex items-center gap-2">
                <span className="text-4xl">👶</span> Baby Names
              </h1>
              <p className="text-primary-50 mt-2 max-w-xl">
                Top 100 boy, girl, and gender-neutral names — with meanings,
                origins, and what&apos;s trending now.
              </p>
            </div>
            <div className="text-right text-sm text-primary-100">
              <div className="text-3xl font-bold text-white">
                {counts.all}
              </div>
              <div>names in our database</div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {sharedNotice && (
          <Card className="mb-6 border-accent-300 bg-accent-50">
            <CardContent className="p-4 flex items-center gap-3 flex-wrap">
              <div className="flex-1 min-w-[200px]">
                <p className="font-semibold text-accent-800">
                  Someone shared {sharedNotice.length}{' '}
                  {sharedNotice.length === 1 ? 'name' : 'names'} with you 💕
                </p>
                <p className="text-sm text-accent-700">
                  {sharedNotice.slice(0, 6).join(', ')}
                  {sharedNotice.length > 6 ? `, +${sharedNotice.length - 6} more` : ''}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSharedNotice(null)}
                >
                  Dismiss
                </Button>
                <Button
                  size="sm"
                  onClick={mergeSharedList}
                  className="bg-accent-600 hover:bg-accent-700 text-white"
                >
                  Add to My Names
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex flex-wrap gap-2 mb-4">
          {(
            [
              { id: 'all' as GenderTab, label: 'All', emoji: '👶' },
              { id: 'boy' as GenderTab, label: 'Boys', emoji: '💙' },
              { id: 'girl' as GenderTab, label: 'Girls', emoji: '💗' },
              { id: 'neutral' as GenderTab, label: 'Gender-Neutral', emoji: '💛' },
            ]
          ).map((g) => (
            <button
              key={g.id}
              onClick={() => setGender(g.id)}
              className={cn(
                'px-4 py-2 rounded-full text-sm font-medium border transition',
                gender === g.id
                  ? 'bg-primary-600 text-white border-primary-600'
                  : 'bg-white text-warm-700 border-warm-300 hover:border-primary-400'
              )}
            >
              <span className="mr-1">{g.emoji}</span>
              {g.label}
              <span className="ml-1 text-xs opacity-75">
                ({g.id === 'all' ? counts.all : counts[g.id as Gender]})
              </span>
            </button>
          ))}
        </div>

        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-warm-500" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, meaning, or origin..."
              className="pl-9"
            />
          </div>
          <Button
            variant="outline"
            onClick={() => setShowFilters((v) => !v)}
            className={cn(
              'border-warm-300',
              showFilters && 'border-primary-400 bg-primary-50'
            )}
          >
            <Filter className="w-4 h-4 mr-1" />
            Filters
            {hasActiveFilters && (
              <Badge
                variant="outline"
                className="ml-1 border-accent-300 text-accent-700 bg-accent-50"
              >
                on
              </Badge>
            )}
          </Button>
        </div>

        {showFilters && (
          <Card className="mb-4 animate-slide-down border-warm-200">
            <CardContent className="p-4 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-warm-700">
                    Starts with
                  </label>
                  {startsWith && (
                    <button
                      onClick={() => setStartsWith('')}
                      className="text-xs text-warm-500 hover:text-warm-700 flex items-center gap-1"
                    >
                      <X className="w-3 h-3" />
                      Clear
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-1">
                  {LETTERS.map((l) => (
                    <button
                      key={l}
                      onClick={() => setStartsWith(l === startsWith ? '' : l)}
                      className={cn(
                        'w-8 h-8 rounded-md border text-sm font-medium transition',
                        startsWith === l
                          ? 'bg-primary-600 text-white border-primary-600'
                          : 'bg-white text-warm-700 border-warm-200 hover:border-primary-400'
                      )}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-warm-700 mb-2 block">
                  Origin
                </label>
                <select
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  className="w-full px-3 py-2 border border-warm-300 rounded-md text-sm bg-white focus:border-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-200"
                >
                  <option value="all">All origins</option>
                  {NAME_ORIGINS.map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              </div>

              {hasActiveFilters && (
                <div className="pt-2">
                  <Button
                    variant="ghost"
                    onClick={clearFilters}
                    size="sm"
                    className="text-warm-600"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Clear all filters
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <div className="flex items-center justify-between mb-3 text-sm text-warm-600">
          <span>
            {results.length} {results.length === 1 ? 'name' : 'names'}
            {favorites.length > 0 && (
              <span className="ml-2">
                · {favorites.length}{' '}
                {favorites.length === 1 ? 'favorite' : 'favorites'}
              </span>
            )}
          </span>
        </div>

        {results.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="text-center py-12 text-warm-500">
              No names match your filters.
              <div className="mt-3">
                <Button variant="outline" onClick={clearFilters}>
                  Clear filters
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {results.map((n) => (
              <NameCard
                key={`${n.gender}-${n.name}-${n.rank}`}
                name={n}
                favorite={isFavorite(n.name)}
                onToggle={toggleFavorite}
              />
            ))}
          </div>
        )}
      </div>

      <FavoritesFloatingButton
        count={favorites.length}
        onClick={() => setShowFavorites(true)}
      />

      <MyNamesList
        open={showFavorites}
        onClose={() => setShowFavorites(false)}
        favorites={favorites}
        onRemove={removeFavorite}
        onClearAll={clearAll}
      />
    </div>
  );
}

function NameCard({
  name,
  favorite,
  onToggle,
}: {
  name: BabyName;
  favorite: boolean;
  onToggle: (n: string) => void;
}) {
  return (
    <Card
      className={cn(
        'transition hover:shadow-soft-lg border-warm-200',
        favorite && 'border-accent-300 bg-accent-50'
      )}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-lg font-bold text-warm-900">{name.name}</h3>
              <span className="text-xs text-warm-500">#{name.rank}</span>
              <TrendIcon trend={name.trend} />
            </div>
            <div className="flex items-center gap-1 mt-1 flex-wrap">
              <Badge
                variant="outline"
                className={cn(
                  'text-xs capitalize',
                  name.gender === 'boy' &&
                    'border-blue-300 text-blue-700 bg-blue-50',
                  name.gender === 'girl' &&
                    'border-pink-300 text-pink-700 bg-pink-50',
                  name.gender === 'neutral' &&
                    'border-amber-300 text-amber-700 bg-amber-50'
                )}
              >
                {name.gender}
              </Badge>
              <Badge variant="outline" className="text-xs border-warm-300 text-warm-700">
                {name.origin}
              </Badge>
            </div>
          </div>
          <FavoriteButton
            name={name.name}
            isFavorite={favorite}
            onToggle={onToggle}
          />
        </div>
        <p className="text-sm text-warm-700 leading-snug">{name.meaning}</p>
      </CardContent>
    </Card>
  );
}

function TrendIcon({ trend }: { trend: Trend }) {
  const label = getTrendLabel(trend);
  if (trend === 'up') {
    return (
      <span
        className="inline-flex items-center text-emerald-600"
        title={label}
        aria-label={label}
      >
        <TrendingUp className="w-3.5 h-3.5" />
      </span>
    );
  }
  if (trend === 'down') {
    return (
      <span
        className="inline-flex items-center text-rose-500"
        title={label}
        aria-label={label}
      >
        <TrendingDown className="w-3.5 h-3.5" />
      </span>
    );
  }
  return (
    <span
      className="inline-flex items-center text-warm-400"
      title={label}
      aria-label={label}
    >
      <Minus className="w-3.5 h-3.5" />
    </span>
  );
}

export default function BabyNamesPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-cream-50">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-primary-600 animate-spin mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-warm-900 mb-2">Loading names...</h1>
        </div>
      </div>
    }>
      <BabyNamesContent />
    </Suspense>
  );
}
