'use client';

import { useState, useEffect, useMemo } from 'react';
import { useRouter, notFound } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import {
  Baby,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
  Sparkles,
  Heart,
  Stethoscope,
  DollarSign,
  CheckCircle2,
  Ruler,
  Weight,
  Calendar,
  ListChecks,
  Target,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';
import {
  getWeekData,
  calculateCurrentWeek,
  TRIMESTER_LABELS,
  type WeekData,
} from '@/lib/pregnancy-weeks';

const TOTAL_WEEKS = 40;

interface WeekDetailClientProps {
  week: string;
}

export default function WeekDetailClient({ week }: WeekDetailClientProps) {
  const router = useRouter();

  const weekNumber = Number(week);
  const isValidWeek = Number.isInteger(weekNumber) && weekNumber >= 1 && weekNumber <= TOTAL_WEEKS;

  const [currentWeek, setCurrentWeek] = useState<number | null>(null);
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  // Local storage key for completion state
  const storageKey = useMemo(
    () => (isValidWeek ? `babynest_week_${weekNumber}_checklist` : null),
    [isValidWeek, weekNumber]
  );

  useEffect(() => {
    if (!storageKey) return;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) setChecked(JSON.parse(saved));
    } catch {}
  }, [storageKey]);

  useEffect(() => {
    const load = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;
        const { data: profile } = await supabase
          .from('profiles')
          .select('due_date')
          .eq('id', user.id)
          .single();
        setCurrentWeek(calculateCurrentWeek(profile?.due_date));
      } catch (err) {
        console.error(err);
      }
    };
    load();
  }, []);

  if (!isValidWeek) {
    notFound();
  }

  const data: WeekData = getWeekData(weekNumber);
  const prevWeek = weekNumber > 1 ? weekNumber - 1 : null;
  const nextWeek = weekNumber < TOTAL_WEEKS ? weekNumber + 1 : null;
  const nextData = nextWeek ? getWeekData(nextWeek) : null;

  const isCurrent = currentWeek === weekNumber;
  const completedCount = data.checklist.filter((_, i) => checked[`${weekNumber}-${i}`]).length;
  const completionPct = Math.round((completedCount / data.checklist.length) * 100);

  const toggleCheck = (key: string) => {
    setChecked((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      if (storageKey) {
        try {
          localStorage.setItem(storageKey, JSON.stringify(next));
        } catch {}
      }
      return next;
    });
  };

  const trimesterColor =
    data.trimester === 1
      ? 'from-primary-50 to-primary-100'
      : data.trimester === 2
      ? 'from-accent-50 to-accent-100'
      : 'from-warm-100 to-warm-200';

  return (
    <div className="min-h-screen bg-gradient-to-br from-warm-50 via-white to-primary-50">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Back link */}
        <Link
          href="/week-by-week"
          className="inline-flex items-center gap-1 text-sm text-warm-600 hover:text-primary-600 mb-4 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          All weeks
        </Link>

        {/* Hero */}
        <Card className={cn('mb-6 overflow-hidden border-primary-200 shadow-soft bg-gradient-to-br', trimesterColor)}>
          <CardContent className="p-6 md:p-8">
            <div className="flex items-start justify-between gap-6 flex-wrap">
              <div className="flex items-start gap-5">
                <div className="w-20 h-20 md:w-24 md:h-24 bg-white rounded-3xl flex items-center justify-center text-5xl md:text-6xl shadow-soft">
                  {data.babyEmoji}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <Badge className="bg-white/80 text-warm-700 hover:bg-white/80 border-warm-200">
                      {TRIMESTER_LABELS[data.trimester]}
                    </Badge>
                    {isCurrent && (
                      <Badge className="bg-primary-500 text-white hover:bg-primary-500">
                        <Sparkles className="w-3 h-3 mr-1" />
                        Your current week
                      </Badge>
                    )}
                    {data.headline && (
                      <Badge className="bg-accent-500 text-white hover:bg-accent-500">
                        Milestone
                      </Badge>
                    )}
                  </div>
                  <h1 className="text-3xl md:text-4xl font-bold text-warm-900 mb-1">
                    Week {data.week}
                  </h1>
                  <p className="text-lg text-warm-700 font-medium">
                    Size of a <span className="text-primary-700">{data.babySize.toLowerCase()}</span>
                  </p>
                  {data.headline && (
                    <p className="text-sm text-warm-600 mt-2 italic">{data.headline}</p>
                  )}
                </div>
              </div>

              {/* Quick stats */}
              <div className="flex gap-3 flex-wrap">
                {data.babyLengthCm != null && (
                  <div className="bg-white/70 rounded-xl px-4 py-2 flex items-center gap-2 shadow-soft">
                    <Ruler className="w-4 h-4 text-primary-600" />
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-warm-500 font-medium">
                        Length
                      </div>
                      <div className="text-sm font-bold text-warm-900">{data.babyLengthCm} cm</div>
                    </div>
                  </div>
                )}
                {data.babyWeightG != null && (
                  <div className="bg-white/70 rounded-xl px-4 py-2 flex items-center gap-2 shadow-soft">
                    <Weight className="w-4 h-4 text-accent-600" />
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-warm-500 font-medium">
                        Weight
                      </div>
                      <div className="text-sm font-bold text-warm-900">
                        {data.babyWeightG >= 1000
                          ? `${(data.babyWeightG / 1000).toFixed(2)} kg`
                          : `${data.babyWeightG} g`}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Progress bar */}
            <div className="mt-6">
              <div className="flex items-center justify-between mb-1.5 text-xs">
                <span className="text-warm-600 font-medium">Pregnancy progress</span>
                <span className="font-semibold text-warm-900">
                  {Math.round((data.week / TOTAL_WEEKS) * 100)}%
                </span>
              </div>
              <Progress value={(data.week / TOTAL_WEEKS) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Main grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Baby development */}
          <Card className="border-warm-100 shadow-soft">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Baby className="w-5 h-5 text-primary-600" />
                Baby&apos;s development
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-warm-700 leading-relaxed">{data.babyDevelopment}</p>
            </CardContent>
          </Card>

          {/* Mom's changes */}
          <Card className="border-warm-100 shadow-soft">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Heart className="w-5 h-5 text-accent-600" />
                What you may feel
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-warm-700 leading-relaxed">{data.momChanges}</p>
              <div>
                <div className="text-xs font-semibold text-warm-500 uppercase tracking-wider mb-2">
                  Common symptoms
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {data.momSymptoms.map((s) => (
                    <Badge
                      key={s}
                      variant="secondary"
                      className="bg-accent-50 text-accent-700 hover:bg-accent-50 border-accent-100"
                    >
                      {s}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Medical milestones */}
          <Card className="border-warm-100 shadow-soft">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Stethoscope className="w-5 h-5 text-primary-600" />
                Medical milestones
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {data.medicalMilestones.map((m, i) => (
                  <li key={i} className="flex gap-3">
                    <div className="flex-shrink-0 mt-0.5 w-2 h-2 rounded-full bg-primary-400" />
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-warm-900">{m.title}</div>
                      <div className="text-xs text-warm-600 mt-0.5">{m.description}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Financial deadlines */}
          <Card className="border-accent-100 shadow-soft bg-gradient-to-br from-accent-50/50 to-white">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="flex items-center gap-2 text-base">
                  <DollarSign className="w-5 h-5 text-accent-600" />
                  Financial deadlines
                </CardTitle>
                <Link
                  href="/financial-timeline"
                  className="text-xs text-accent-700 hover:text-accent-800 font-medium underline-offset-2 hover:underline whitespace-nowrap"
                >
                  Timeline →
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {data.financialDeadlines.map((d, i) => (
                  <li key={i} className="flex gap-3">
                    <div className="flex-shrink-0 mt-0.5 w-2 h-2 rounded-full bg-accent-500" />
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-warm-900">{d.title}</div>
                      <div className="text-xs text-warm-600 mt-0.5">{d.description}</div>
                      {d.estimatedCost && (
                        <div className="text-xs text-accent-700 font-medium mt-1">
                          Est. {d.estimatedCost}
                        </div>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Checklist */}
        <Card className="mt-6 border-warm-100 shadow-soft">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <CardTitle className="flex items-center gap-2 text-base">
                <ListChecks className="w-5 h-5 text-primary-600" />
                This week&apos;s action items
              </CardTitle>
              <Badge className="bg-primary-100 text-primary-700 hover:bg-primary-100">
                {completedCount}/{data.checklist.length} done
              </Badge>
            </div>
            <Progress value={completionPct} className="h-1.5 mt-2" />
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {data.checklist.map((item, i) => {
                const key = `${weekNumber}-${i}`;
                const done = !!checked[key];
                return (
                  <li
                    key={i}
                    className={cn(
                      'flex items-start gap-3 p-3 rounded-lg border transition-colors cursor-pointer',
                      done
                        ? 'bg-primary-50 border-primary-200'
                        : 'bg-white border-warm-100 hover:bg-warm-50'
                    )}
                    onClick={() => toggleCheck(key)}
                  >
                    <Checkbox
                      checked={done}
                      onCheckedChange={() => toggleCheck(key)}
                      className="mt-0.5"
                    />
                    <span
                      className={cn(
                        'text-sm flex-1',
                        done ? 'text-warm-500 line-through' : 'text-warm-800'
                      )}
                    >
                      {item}
                    </span>
                  </li>
                );
              })}
            </ul>
          </CardContent>
        </Card>

        {/* Next week preview */}
        {nextData && (
          <Card className="mt-6 border-primary-100 bg-gradient-to-r from-primary-50/50 to-white">
            <CardContent className="p-5 flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-4">
                <div className="text-3xl">{nextData.babyEmoji}</div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-warm-500 font-medium">
                    Coming up next
                  </div>
                  <div className="text-base font-semibold text-warm-900">
                    Week {nextData.week} · Size of a {nextData.babySize.toLowerCase()}
                  </div>
                  {nextData.headline && (
                    <div className="text-xs text-accent-700 mt-0.5 italic">{nextData.headline}</div>
                  )}
                </div>
              </div>
              <Link href={`/week-by-week/${nextData.week}`}>
                <Button variant="outline" className="border-primary-200 text-primary-700 hover:bg-primary-50">
                  Preview week {nextData.week}
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Prev/Next nav */}
        <div className="mt-6 flex items-center justify-between gap-3">
          {prevWeek ? (
            <Link href={`/week-by-week/${prevWeek}`}>
              <Button variant="outline" className="border-warm-200">
                <ChevronLeft className="w-4 h-4 mr-1" />
                Week {prevWeek}
              </Button>
            </Link>
          ) : (
            <div />
          )}
          <Link href="/week-by-week">
            <Button variant="ghost" className="text-warm-600">
              All weeks
            </Button>
          </Link>
          {nextWeek ? (
            <Link href={`/week-by-week/${nextWeek}`}>
              <Button className="bg-primary-500 hover:bg-primary-600 text-white">
                Week {nextWeek}
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          ) : (
            <div />
          )}
        </div>
      </div>
    </div>
  );
}
