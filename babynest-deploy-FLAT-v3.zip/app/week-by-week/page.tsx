'use client';

import { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Baby,
  Calendar,
  ChevronRight,
  Sparkles,
  Heart,
  DollarSign,
  Activity,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';
import { LegalDisclaimer } from '@/components/LegalDisclaimer';
import {
  getAllWeeks,
  calculateCurrentWeek,
  TRIMESTER_LABELS,
  TRIMESTER_RANGES,
  type Trimester,
  type WeekData,
} from '@/lib/pregnancy-weeks';

type FilterTab = 'all' | '1' | '2' | '3';

export default function WeekByWeekOverviewPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [currentWeek, setCurrentWeek] = useState<number | null>(null);
  const [filter, setFilter] = useState<FilterTab>('all');

  const allWeeks = useMemo(() => getAllWeeks(), []);

  useEffect(() => {
    const load = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          setLoading(false);
          return;
        }
        const { data: profile } = await supabase
          .from('profiles')
          .select('due_date')
          .eq('id', user.id)
          .single();
        const wk = calculateCurrentWeek(profile?.due_date);
        setCurrentWeek(wk);
      } catch (err) {
        console.error('Error loading profile:', err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const visibleWeeks = useMemo(() => {
    if (filter === 'all') return allWeeks;
    const t = Number(filter) as Trimester;
    return allWeeks.filter((w) => w.trimester === t);
  }, [allWeeks, filter]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-warm-50 via-white to-primary-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-400 to-primary-500 rounded-xl flex items-center justify-center shadow-soft">
              <Baby className="w-5 h-5 text-white" />
            </div>
            <Badge className="bg-primary-100 text-primary-700 hover:bg-primary-100">
              40-Week Journey
            </Badge>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-warm-900 mb-2">
            Week-by-Week Pregnancy Guide
          </h1>
          <p className="text-warm-600 max-w-2xl">
            Track your baby&apos;s development, your changing body, medical milestones, and financial
            deadlines — week by week.
          </p>
        </div>

        {/* Current week banner */}
        {!loading && currentWeek !== null && (
          <Card className="mb-8 border-primary-200 bg-gradient-to-r from-primary-50 via-white to-accent-50 shadow-soft">
            <CardContent className="p-6">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-primary-400 to-accent-400 rounded-2xl flex items-center justify-center text-2xl shadow-soft">
                    {allWeeks[currentWeek - 1]?.babyEmoji}
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-warm-500 font-medium">
                      You are currently in
                    </p>
                    <h2 className="text-2xl font-bold text-warm-900">
                      Week {currentWeek} ·{' '}
                      <span className="text-primary-600">
                        Size of a {allWeeks[currentWeek - 1]?.babySize.toLowerCase()}
                      </span>
                    </h2>
                    <p className="text-sm text-warm-600">
                      {TRIMESTER_LABELS[allWeeks[currentWeek - 1]?.trimester || 1]}
                    </p>
                  </div>
                </div>
                <Link href={`/week-by-week/${currentWeek}`}>
                  <Button className="bg-primary-500 hover:bg-primary-600 text-white shadow-soft">
                    Go to this week
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        {loading && (
          <div className="mb-8">
            <Skeleton className="h-32 w-full rounded-lg" />
          </div>
        )}

        {/* No due date prompt */}
        {!loading && currentWeek === null && (
          <Card className="mb-8 border-warm-200 bg-white shadow-soft">
            <CardContent className="p-6 flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-warm-500" />
                <p className="text-warm-700 text-sm">
                  Set your due date to highlight your current week.
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => router.push('/dashboard')}
                className="border-primary-200 text-primary-700 hover:bg-primary-50"
              >
                Set due date
              </Button>
            </CardContent>
          </Card>
        )}

        <LegalDisclaimer type="medical" message="Every pregnancy is different. Consult your doctor for personalized advice." />

        {/* Trimester filter */}
        <Tabs value={filter} onValueChange={(v) => setFilter(v as FilterTab)} className="mb-6">
          <TabsList className="bg-white border border-warm-100 shadow-soft">
            <TabsTrigger value="all">All 40 weeks</TabsTrigger>
            <TabsTrigger value="1">
              T1 · Weeks {TRIMESTER_RANGES[1][0]}–{TRIMESTER_RANGES[1][1]}
            </TabsTrigger>
            <TabsTrigger value="2">
              T2 · Weeks {TRIMESTER_RANGES[2][0]}–{TRIMESTER_RANGES[2][1]}
            </TabsTrigger>
            <TabsTrigger value="3">
              T3 · Weeks {TRIMESTER_RANGES[3][0]}–{TRIMESTER_RANGES[3][1]}
            </TabsTrigger>
          </TabsList>
          <TabsContent value={filter} className="mt-6">
            <WeeksGrid weeks={visibleWeeks} currentWeek={currentWeek} />
          </TabsContent>
        </Tabs>

        {/* Quick-links footer */}
        <Card className="mt-8 bg-gradient-to-r from-accent-50 to-primary-50 border-accent-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <DollarSign className="w-6 h-6 text-accent-600" />
                <div>
                  <h3 className="font-semibold text-warm-900">
                    Track financial deadlines for every week
                  </h3>
                  <p className="text-sm text-warm-600">
                    Your Financial Timeline maps every cost in your pregnancy.
                  </p>
                </div>
              </div>
              <Link href="/financial-timeline">
                <Button variant="outline" className="border-accent-300 text-accent-700 hover:bg-accent-100">
                  Open Financial Timeline
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function WeeksGrid({
  weeks,
  currentWeek,
}: {
  weeks: WeekData[];
  currentWeek: number | null;
}) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
      {weeks.map((w) => (
        <WeekCard key={w.week} week={w} isCurrent={w.week === currentWeek} />
      ))}
    </div>
  );
}

function WeekCard({ week, isCurrent }: { week: WeekData; isCurrent: boolean }) {
  const hasMilestone = !!week.headline;
  const trimesterColor =
    week.trimester === 1
      ? 'from-primary-50 to-primary-100 border-primary-200'
      : week.trimester === 2
      ? 'from-accent-50 to-accent-100 border-accent-200'
      : 'from-warm-50 to-warm-100 border-warm-200';

  return (
    <Link href={`/week-by-week/${week.week}`} className="group">
      <Card
        className={cn(
          'relative h-full transition-all hover:shadow-md hover:-translate-y-0.5 cursor-pointer overflow-hidden bg-gradient-to-br border',
          trimesterColor,
          isCurrent && 'ring-2 ring-primary-500 ring-offset-2 shadow-md'
        )}
      >
        {isCurrent && (
          <Badge className="bg-primary-500 hover:bg-primary-500 text-white text-[10px] absolute top-2 right-2 z-10">
            Now
          </Badge>
        )}
        <CardContent className="p-4 flex flex-col items-center text-center gap-1.5">
          <div className="text-3xl leading-none" aria-hidden>
            {week.babyEmoji}
          </div>
          <div className="text-xs font-bold uppercase tracking-wider text-warm-500">
            Week {week.week}
          </div>
          <div className="text-sm font-semibold text-warm-900 line-clamp-1">{week.babySize}</div>
          {hasMilestone ? (
            <div className="flex items-center gap-1 text-[10px] text-accent-700 font-medium mt-1">
              <Sparkles className="w-3 h-3" />
              <span className="line-clamp-1">Milestone</span>
            </div>
          ) : (
            <div className="text-[10px] text-warm-500 mt-1">T{week.trimester}</div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
