import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Analytics } from '@vercel/analytics/react';
import { SpeedInsights } from '@vercel/speed-insights/next';
import { SharedHeader } from '@/components/SharedHeader';
import { LegalFooter } from '@/components/LegalDisclaimer';

const inter = Inter({ subsets: ['latin'] });

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://babynest.app';
const TITLE = 'BabyNest 👶 Your Financial Guide to Parenthood';
const DESCRIPTION =
  'Plan smarter for baby. Personalized financial timeline, hospital cost estimates, readiness score, milestones, baby name help, and insurance/provider guidance — all in one place.';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: TITLE,
    template: '%s · BabyNest 👶',
  },
  description: DESCRIPTION,
  applicationName: 'BabyNest',
  keywords: [
    'baby financial planning',
    'new parents',
    'pregnancy budget',
    'hospital costs',
    '529 plan',
    'maternity leave calculator',
    'insurance for newborn',
    'baby milestones',
    'baby names',
    'readiness score',
  ],
  authors: [{ name: 'BabyNest' }],
  creator: 'BabyNest',
  publisher: 'BabyNest',
  manifest: '/manifest.json',
  icons: {
    icon: [
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: [
      { url: '/apple-icon.svg', type: 'image/svg+xml' },
    ],
    shortcut: ['/icon.svg'],
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: SITE_URL,
    siteName: 'BabyNest',
    title: TITLE,
    description: DESCRIPTION,
    images: [
      {
        url: '/og-image.svg',
        width: 1200,
        height: 630,
        alt: 'BabyNest 👶 Your Financial Guide to Parenthood',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: TITLE,
    description: DESCRIPTION,
    images: ['/og-image.svg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
};

export const viewport: Viewport = {
  themeColor: '#fef3ec',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="flex flex-col min-h-screen">
          <SharedHeader />
          <main className="flex-1">{children}</main>
          <LegalFooter />
        </div>
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  );
}
